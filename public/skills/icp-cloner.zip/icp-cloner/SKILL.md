---
name: icp-cloner
description: Clone an Ideal Client Profile from a LinkedIn PDF export. Use when the user uploads a LinkedIn profile PDF (exported via "Save to PDF") and wants to create an ICP document with search parameters to find similar people. Triggers include "clone this client", "find more like them", "ICP from LinkedIn", "create ICP from profile", "LinkedIn to ICP", or any request to analyze a LinkedIn profile to find similar prospects.
---

# ICP Cloner

Transform a LinkedIn profile PDF into a structured Ideal Client Profile (ICP) document with actionable search parameters for both LinkedIn Basic Search and Sales Navigator.

## Workflow

### Step 1: Extract Profile Data

Parse the LinkedIn PDF and extract:

| Category | Data Points |
|----------|-------------|
| **Identity** | Name, headline, current title, company |
| **Experience** | Job titles (current + past 2-3), industries, company sizes, tenure patterns |
| **Skills** | Listed skills, endorsements, certifications |
| **Education** | Degrees, institutions, graduation years |
| **Location** | Geographic region |
| **Signals** | Content themes, group memberships, interests |

### Step 2: Identify Clone Patterns

**Title Variations:** Generate 5-10 title synonyms
- Example: "VP Engineering" → VP of Engineering, Head of Engineering, Engineering VP, Vice President of Engineering

**Industry Signals:** Primary industry + 2-3 adjacent industries

**Company Profile:** Size tier, growth stage, funding status

**Seniority Level:** C-Suite / VP / Director / Manager / IC

### Step 3: Generate ICP Document

Output a markdown document following the template in `references/icp-template.md`

The document must include:
1. Profile summary and demographics table
2. Psychographics (pain points, goals, buying triggers)
3. LinkedIn Basic Search parameters with boolean query examples
4. Sales Navigator lead and account filters
5. Outreach personalization hooks

### Step 4: Generate Outreach Strategy

Use the **dm-coach** skill for drafting outreach messages:

1. **Map ICP to Trust Gates** - Identify which gate (G1-G6) cold outreach starts at (typically G1: Credibility)
2. **Extract Trust Signals** - Pull profile data that enables trust-building moves:
   - Shared background → G2 Relevance signals
   - Pain points → G3 Fit & Safety hooks
   - Buying triggers → G5 Timing permission
3. **Generate First-Touch Templates** - Use dm-coach principles for initial outreach:
   - Pattern-breaking openers (G1)
   - Tribe signals from ICP data (G2)
   - Never pitch in first message

After generating the ICP document, prompt user: *"Want me to draft outreach sequences using the dm-coach skill? I can create trust-building message templates based on this ICP's psychology."*

## Output

Save as `icp-[archetype-name].md` in outputs directory.

## Reference Files

- `references/icp-template.md` - Complete output template
- `references/linkedin-filters.md` - All Sales Navigator filter options

## Related Skills

- **dm-coach** - Use for drafting actual outreach messages and coaching through DM conversations with prospects matching this ICP
