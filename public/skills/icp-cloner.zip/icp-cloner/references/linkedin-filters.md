# LinkedIn Search Filters Reference

Complete reference for LinkedIn Basic Search and Sales Navigator filters.

## LinkedIn Basic Search Filters

Available to all LinkedIn users:

| Filter | Options |
|--------|---------|
| **Connections** | 1st, 2nd, 3rd+ |
| **Locations** | Add specific regions/countries |
| **Current Company** | Add specific companies |
| **Past Company** | Add specific companies |
| **Industry** | Select from LinkedIn industries |
| **Profile Language** | Select language |
| **Open To** | Hiring, Providing Services |
| **Service Categories** | Specific service types |
| **Keywords** | Free text (title, company, etc.) |

### Boolean Search Operators (Basic)

```
AND    - Both terms required: marketing AND manager
OR     - Either term: marketing OR sales
NOT    - Exclude term: marketing NOT intern
""     - Exact phrase: "product manager"
()     - Grouping: (marketing OR sales) AND manager
```

---

## Sales Navigator Lead Filters

### Keyword Search
Free text search across profile content.

### Current Job Title
Enter specific titles. Supports:
- Exact match
- Contains match
- Boolean operators

### Past Job Title
Same as current, for historical roles.

### Seniority Level

| Level | Description |
|-------|-------------|
| Owner | Business owners |
| Partner | Partners at firms |
| CXO | C-level executives |
| VP | Vice Presidents |
| Director | Directors |
| Manager | Managers |
| Senior | Senior individual contributors |
| Entry | Entry level |
| Training | Interns, trainees |

### Function

| Function | Examples |
|----------|----------|
| Accounting | CFO, Controller, Accountant |
| Administrative | Admin, Executive Assistant |
| Arts and Design | Designer, Creative Director |
| Business Development | BD, Partnerships |
| Community and Social Services | Social Worker, Counselor |
| Consulting | Consultant, Advisor |
| Education | Teacher, Professor, Trainer |
| Engineering | Software Engineer, DevOps |
| Entrepreneurship | Founder, Entrepreneur |
| Finance | Finance Manager, Analyst |
| Healthcare Services | Doctor, Nurse, Therapist |
| Human Resources | HR Manager, Recruiter |
| Information Technology | IT Manager, Sysadmin |
| Legal | Lawyer, General Counsel |
| Marketing | CMO, Marketing Manager |
| Media and Communication | PR, Communications |
| Military and Protective Services | Security, Military |
| Operations | COO, Operations Manager |
| Product Management | Product Manager, PM |
| Program and Project Management | Program Manager, PMO |
| Purchasing | Procurement, Buyer |
| Quality Assurance | QA Engineer, Tester |
| Real Estate | Broker, Agent |
| Research | Researcher, Scientist |
| Sales | Sales Rep, AE, SDR |
| Support | Customer Support, Success |

### Geography
Regions, countries, states, cities, postal codes.

### Industry

Common technology industries:
- Computer Software
- Information Technology and Services
- Internet
- Computer & Network Security
- Computer Hardware
- Semiconductors

Common business industries:
- Financial Services
- Banking
- Insurance
- Management Consulting
- Marketing and Advertising
- Staffing and Recruiting

### Company Headcount

| Range | Description |
|-------|-------------|
| Self-employed | Solo operators |
| 1-10 | Micro business |
| 11-50 | Small startup |
| 51-200 | Growth stage |
| 201-500 | Mid-market |
| 501-1000 | Upper mid-market |
| 1001-5000 | Enterprise |
| 5001-10000 | Large enterprise |
| 10001+ | Mega enterprise |

### Years in Current Position

| Range |
|-------|
| Less than 1 year |
| 1-2 years |
| 3-5 years |
| 6-10 years |
| More than 10 years |

### Years at Current Company

Same ranges as Years in Current Position.

### Years of Experience (Total)

Same ranges as above.

---

## Sales Navigator Account Filters

### Company Headcount
Same ranges as lead filters.

### Company Type

| Type |
|------|
| Public Company |
| Privately Held |
| Non-Profit |
| Educational Institution |
| Government Agency |
| Self-Employed |
| Partnership |
| Sole Proprietorship |

### Headquarters Location
Geographic filters for company HQ.

### Annual Revenue

| Range |
|-------|
| $0-$1M |
| $1M-$10M |
| $10M-$50M |
| $50M-$100M |
| $100M-$500M |
| $500M-$1B |
| $1B-$10B |
| $10B+ |

### Department Headcount
Filter by specific department size at company.

### Department Headcount Growth
Filter by department growth rate.

### Fortune
Fortune 500, Fortune 1000 filters.

### Technologies Used
Filter by tech stack (requires Sales Navigator Advanced).

---

## Spotlight Filters (Intent Signals)

### Changed Jobs in Past 90 Days
- **Why use:** New roles = new initiatives, budget
- **Best for:** Solution selling, onboarding tools

### Posted on LinkedIn in Past 30 Days
- **Why use:** Active users more responsive
- **Best for:** Any outreach

### Mentioned in News in Past 30 Days
- **Why use:** Company momentum, conversation starter
- **Best for:** Strategic accounts

### Share Experiences With You
- **Why use:** Common ground for personalization
- **Best for:** Warm outreach

### Following Your Company
- **Why use:** Already aware of brand
- **Best for:** Inbound-style outreach

### Viewed Your Profile
- **Why use:** Expressed interest
- **Best for:** Hot follow-up

### Senior Leadership Changes in Past 3 Months
- **Why use:** New leadership = new priorities
- **Best for:** Executive selling

---

## Boolean Operators in Sales Navigator

```
AND     - (VP OR Director) AND Engineering
OR      - Marketing OR Growth
NOT     - Sales NOT SDR
""      - "Chief Technology Officer"
()      - (CEO OR CTO) AND (startup OR "series a")
```

### Advanced Query Examples

**Tech Executives at Growth Companies:**
```
(CTO OR "VP Engineering" OR "Head of Engineering") AND (startup OR "series a" OR "series b")
```

**Sales Leaders in SaaS:**
```
(VP Sales OR "Head of Sales" OR CRO) AND (SaaS OR "software company")
```

**HR Leaders at Mid-Market:**
```
("VP HR" OR "Head of People" OR CHRO) AND ("people operations" OR "human resources")
```

---

## Best Practices

### For Higher Match Quality
1. Use 3-5 title variations, not just one
2. Combine seniority + function filters
3. Add industry to reduce false positives
4. Use company size to match your market

### For Higher Response Rates
1. Enable "Posted in past 30 days"
2. Target "Changed jobs in 90 days"
3. Look for "Following your company"
4. Prioritize 2nd connections for warm intros

### For Larger Result Sets
1. Broaden geography
2. Add more title variations
3. Include adjacent industries
4. Expand company size range
