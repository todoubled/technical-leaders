# ICP Document Template

Use this exact structure when generating ICP documents from LinkedIn profiles.

---

# Ideal Client Profile: [Archetype Name]

*Generated from: [Source Profile Name]*
*Date: [Generation Date]*

## Profile Summary

[2-3 sentence description of this ICP archetype based on the source profile. Describe who they are, what they do, and why they're valuable as a client.]

## Demographics

| Attribute | Value |
|-----------|-------|
| **Primary Title** | [Most likely current title] |
| **Title Variations** | [5-10 equivalent titles, comma-separated] |
| **Seniority** | [C-Suite / VP / Director / Manager / Senior IC / IC] |
| **Primary Industry** | [Main industry] |
| **Adjacent Industries** | [2-3 related industries] |
| **Company Size** | [Employee count range] |
| **Company Type** | [Startup / SMB / Mid-Market / Enterprise] |
| **Geography** | [Regions/countries] |
| **Years Experience** | [Total experience range] |
| **Years in Role** | [Current role tenure pattern] |

## Psychographics

### Pain Points They Likely Have

Based on role, industry, and seniority:
- [Pain point 1 - specific to their responsibilities]
- [Pain point 2 - common industry challenge]
- [Pain point 3 - growth/scale challenge]

### Goals & Motivations

- [Professional goal 1]
- [Career trajectory goal]
- [Business outcome they're measured on]

### Buying Triggers

Events that prompt action:
- [Trigger 1: e.g., "Just raised funding"]
- [Trigger 2: e.g., "Team scaling past X people"]
- [Trigger 3: e.g., "New leadership role"]

---

## LinkedIn Basic Search Parameters

### Recommended Search Query

```
"[Primary Title]" OR "[Title Variation 1]" OR "[Title Variation 2]"
```

### Advanced Boolean Query

```
("[Title 1]" OR "[Title 2]" OR "[Title 3]") AND ("[Industry Term]" OR "[Industry Term 2]")
```

### Filter Settings

| Filter | Recommended Value |
|--------|-------------------|
| **Keywords** | [Terms from their headline/about] |
| **Title** | [Primary title for exact match] |
| **Location** | [Geographic area] |
| **Current Company** | [Leave blank or use industry hint] |
| **Industry** | [Select matching industries] |
| **Connections** | 2nd degree (warm intros) |
| **Profile Language** | English (or relevant) |

### Search URL Template

```
https://www.linkedin.com/search/results/people/?keywords=[ENCODED_QUERY]&origin=GLOBAL_SEARCH_HEADER
```

---

## Sales Navigator Search Parameters

### Lead Filters

#### Identity Filters

| Filter | Value |
|--------|-------|
| **Keywords** | [Role-specific terms] |
| **First Name** | [Leave blank] |
| **Last Name** | [Leave blank] |

#### Current Role Filters

| Filter | Value |
|--------|-------|
| **Current Job Title** | [List 3-5 titles] |
| **Seniority Level** | [Select: Owner, Partner, CXO, VP, Director, Manager, Senior, Entry] |
| **Function** | [Select function category] |
| **Years in Current Position** | [e.g., 1-2 years, 3-5 years] |
| **Years at Current Company** | [Range] |

#### Personal Filters

| Filter | Value |
|--------|-------|
| **Geography** | [Regions to include] |
| **Industry** | [LinkedIn industry selections] |
| **Years of Experience** | [Total experience range] |
| **Groups** | [Relevant LinkedIn groups if known] |
| **School** | [Leave blank unless targeting specific schools] |

### Account Filters

| Filter | Value |
|--------|-------|
| **Company Headcount** | [e.g., 51-200, 201-500] |
| **Company Type** | [Public, Private, Non-Profit, etc.] |
| **Headquarters Location** | [Geographic filter] |
| **Industry** | [Company industry] |
| **Annual Revenue** | [Range if relevant] |
| **Department Headcount** | [Specific department size] |
| **Technologies Used** | [Specific tech stack if relevant] |
| **Company Growth** | [Trending up/stable] |

### Spotlight Filters (High-Intent Signals)

Check these for higher conversion prospects:

- [ ] **Changed jobs in past 90 days** - New role = new initiatives
- [ ] **Posted on LinkedIn in past 30 days** - Active on platform
- [ ] **Mentioned in news in past 30 days** - Company momentum
- [ ] **Share experiences with you** - Common ground for outreach
- [ ] **Following your company** - Already aware of you
- [ ] **Viewed your profile** - Expressed interest

### Recommended Saved Searches

1. **Hot Leads:** [Title filters] + Changed jobs in 90 days + Posted in 30 days
2. **Warm Accounts:** [Account filters] + Following company
3. **Scale-Up Targets:** [Title filters] + Company headcount 51-200 + Funding signals

---

## Outreach Strategy (dm-coach Integration)

Use the **dm-coach** skill to craft trust-building outreach based on this ICP's psychology.

### Trust Gate Mapping for This ICP

| Gate | ICP-Specific Unlock |
|------|---------------------|
| **G1: Credibility** | [Pattern-breaking opener based on their world] |
| **G2: Relevance** | [Tribe signals from shared background/industry] |
| **G3: Fit & Safety** | [Specific scenario proof relevant to their pain points] |
| **G4: Risk Mitigation** | [Objection handling for this persona's concerns] |
| **G5: Inertia Override** | [Timing triggers from buying signals above] |
| **G6: Identity Integration** | [How your solution aligns with who they want to become] |

### First-Touch Message Framework

**Goal:** Pass G1 (Credibility) and plant G2 (Relevance) seed. Never pitch.

**Pattern-Break Opener Options:**
1. [Observation about their specific situation - no flattery]
2. [Contrarian insight relevant to their industry]
3. [Shared experience reference - if genuine connection exists]

**dm-coach Prompt for First Touch:**
> "Help me draft a first DM to a [Primary Title] at a [Company Type] company. Their likely pain points are [Pain Points]. I want to pass G1 and plant a G2 seed. No pitch, no ask."

### Personalization Hooks by Trust Gate

#### G1 Hooks (Credibility - "Are you real?")
- [Specific detail showing you did research]
- [Reference to recent activity/post they made]
- [Pattern break that stands out from spam]

#### G2 Hooks (Relevance - "Are you for me?")
- [Shared background element]
- [Industry-specific language they use]
- [Common connection or tribe signal]

#### G3 Hooks (Fit & Safety - "Is this safe for my specifics?")
- [Case study with similar company profile]
- [Specific outcome achieved for someone like them]
- [Risk reversal relevant to their concerns]

#### G5 Hooks (Timing - "Why now?")
- [Buying trigger signal to reference]
- [Industry timing element]
- [Natural urgency without pressure]

### Follow-Up Sequence Framework

| Touch | Gate Target | Move Type |
|-------|-------------|-----------|
| 1st DM | G1→G2 | Pattern break + relevance plant |
| 2nd DM (3-5 days) | G2→G3 | Tribe signal + specific value hint |
| 3rd DM (5-7 days) | G3 | Proof/case study offer (no pitch) |
| 4th DM (7-10 days) | G4 | Acknowledge likely objection preemptively |
| Call Invite | G4+ only | Permission-based, low-pressure |

### Red Flags to Avoid with This ICP

Based on their seniority and role:
- [Specific pressure pattern to avoid]
- [Language that signals "salesy" to them]
- [Timing mistakes common with this persona]

### dm-coach Prompts for Ongoing Conversations

**When they reply with skepticism (G1 stuck):**
> "They said [quote]. Coach me on passing G1 - they seem skeptical."

**When they ask about specifics (G3):**
> "They asked [question]. They're at G3. How do I build safety without pitching?"

**When they go quiet (any gate):**
> "They haven't replied in [X] days. Last message was at G[X]. What's a trust-building follow-up?"

---

## Search Execution Checklist

### Initial Setup
- [ ] Run LinkedIn Basic Search with boolean query
- [ ] Create Sales Navigator saved search with lead filters
- [ ] Enable relevant Spotlight filters
- [ ] Set up search alerts for new matches

### Ongoing Management
- [ ] Review new results weekly
- [ ] Export qualified leads to CRM
- [ ] Track response rates by search criteria
- [ ] Refine filters based on conversion data

---

## ICP Validation Questions

Before executing outreach, validate this ICP:

1. Does this archetype match your best existing customers?
2. Do they have budget authority for your solution?
3. Is the total addressable market large enough?
4. Can you reach them through available channels?
5. Do your case studies/social proof resonate with them?
