---
name: linkedin-converse
description: Start conversations with new LinkedIn connections matching your ICP. Use when user says "start conversations", "message new connections", "reach out to connections", or wants to engage recently connected prospects. Opens LinkedIn connections page, identifies ICP-matching connections, and sends conversation-starting messages. Triggers include "/start conversations", "message my new connections", "follow up with connections", or any request to send initial messages to recently connected LinkedIn contacts.
---

# LinkedIn Converse

Start conversations with new LinkedIn connections that match your ICP.

## Prerequisites

1. **Claude in Chrome** browser extension enabled
2. **LinkedIn session** - logged into LinkedIn in Chrome
3. **ICP knowledge** - understand user's ideal client profile (from icp-*.md files or conversation context)

## Workflow

### Step 1: Navigate to Connections

Go to: `https://www.linkedin.com/mynetwork/invite-connect/connections/`

Ensure sorted by "Recently added" (default).

### Step 2: Identify ICP Matches

Scan recent connections for ICP signals:

**High-value indicators** (prioritize these):
- VP/Director/C-level titles
- Target industry keywords
- Compliance, Risk, Quality in title (or user's ICP terms)
- Connected today or yesterday

**Connection data visible**:
- Name
- Headline/Title
- Connection date
- "Message" button

### Step 3: Get Conversation Starter Message

Ask user for message or use default:
```
Default: "Thanks for connecting. Looks like you're working on some interesting stuff"
```

Message constraints:
- Casual, non-salesy tone
- Opens dialogue without pitching
- Under 200 characters ideal

### Step 4: Send Messages to Top Matches

For each prioritized connection:

1. **Click "Message"** button next to their name
   - Or navigate to: `/messaging/compose/?profileUrn=...`
2. **Wait** for messaging window to open
3. **Click** in message text area
4. **Type** the conversation starter message
5. **Confirm** with user before sending
6. **Click "Send"** button
7. **Verify** message appears in conversation

### Browser Automation Pattern

```javascript
// Navigate to connections
navigate("https://www.linkedin.com/mynetwork/invite-connect/connections/")

// Read page to identify connections and their titles
// Use read_page tool to get connection list

// Click Message button (use coordinates or find tool)
left_click at message button coordinates

// Type in message box
type "Thanks for connecting. Looks like you're working on some interesting stuff"

// Send message
document.querySelector('button.msg-form__send-button').click();
```

### Step 5: Report Results

```
✅ Conversations Started

ICP Matches Found: [X]
Messages Sent: [N]

Contacts Messaged:
1. [Name] - [Title] ✓
2. [Name] - [Title] ✓

Next: Monitor responses in LinkedIn Messaging
```

## ICP Prioritization Matrix

| Priority | Criteria | Action |
|----------|----------|--------|
| P1: Hot | VP+ title, target industry, connected today | Message immediately |
| P2: Warm | Manager+ title, adjacent industry | Message same session |
| P3: Cool | Other connections | Skip or message later |

## User Commands

| User Says | Action |
|-----------|--------|
| "start conversations" | Full workflow - find & message ICP matches |
| "message [name]" | Message specific connection |
| "show connections" | List recent connections without messaging |

## Safety Controls

- **Confirm before sending** - Show message preview, get approval
- **Batch limit**: Max 10 messages per session
- **No spam**: Only message genuine ICP matches
- **Personalization**: If user wants, customize per prospect

## Error Handling

- **Message window doesn't open**: Refresh and retry
- **Already in conversation**: Show existing thread, ask if should add message
- **Connection not found**: May have disconnected, skip and log
