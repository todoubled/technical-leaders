---
name: linkedin-connect
description: Send LinkedIn connection requests from a prospects spreadsheet. Use when user says "get connections", "send connection requests", "connect with prospects", or has a spreadsheet of LinkedIn profiles to connect with. Requires Claude in Chrome browser automation and a prospects spreadsheet with LinkedIn URLs. Triggers include "/get connections", "send invites to prospects", "connect with my prospect list", or any request to batch send LinkedIn connection requests with personalized notes.
---

# LinkedIn Connect

Automate sending LinkedIn connection requests from a prospects spreadsheet.

## Prerequisites

1. **Prospects spreadsheet** in working directory (xlsx/csv with LinkedIn URL column)
2. **Claude in Chrome** browser extension enabled
3. **LinkedIn session** - logged into LinkedIn in Chrome

## Workflow

### Step 1: Find Prospects File

Look for prospects spreadsheet in the working directory:
- `prospects-*.xlsx` (from linkedin-prospect-builder)
- Any `.xlsx` or `.csv` with "LinkedIn" or "URL" column

### Step 2: Extract LinkedIn URLs

Read the spreadsheet and extract:
- LinkedIn profile URLs
- Names (for verification)
- Target count (user specifies or default to 5 for testing)

### Step 3: Get Connection Message

Ask user for connection note or use default:
```
Default: "LinkedIn keeps suggesting your profile, can we connect?"
```

Note constraint: **300 character LinkedIn limit**

### Step 4: Send Connection Requests

For each prospect URL:

1. **Navigate** to profile URL
2. **Locate Connect button**:
   - If "Connect" is primary button → click directly
   - If "Follow/Message" is primary → click "More actions" (three dots) → "Connect"
3. **Add note dialog**:
   - Click "Add a note" button
   - Type the connection message in textarea
   - Click "Send invitation"
4. **Verify** success message appears
5. **Log** result (success/already connected/error)

### Browser Automation Pattern

```javascript
// Open More actions dropdown (if needed)
document.querySelectorAll('button[aria-label="More actions"]')[1].click();

// Click Connect from dropdown
Array.from(document.querySelectorAll('div[role="button"]'))
  .find(el => el.textContent.trim() === 'Connect')?.click();

// Add note
document.querySelector('button[aria-label="Add a note"]').click();

// Find textarea and input message
// Use find tool: "invitation note textarea"
// Use form_input with ref to set value

// Send invitation
document.querySelector('button[aria-label="Send invitation"]').click();
```

### Step 5: Report Results

```
✅ Connection Requests Sent

Batch: [X] of [Y] prospects
- Sent: [N] requests
- Already connected: [N]
- Errors: [N]

Next: Wait for acceptances, then run "start conversations"
```

## Safety Controls

- **Batch limit**: Process max 20 per session (LinkedIn rate limits)
- **Delay**: 3-5 seconds between requests
- **Test first**: Ask user to confirm after first 5 before continuing
- **Never** auto-send without user approval

## User Commands

| User Says | Action |
|-----------|--------|
| "get connections" | Run full workflow |
| "connect with first 5" | Test batch of 5 |
| "continue" | Process remaining prospects |
| "stop" | Halt and report progress |

## Error Handling

- **No Connect button**: Profile may have restrictions, skip and log
- **Already connected**: Log and continue
- **Rate limited**: Stop, wait, and report to user
- **Profile not found**: Log URL error and continue
