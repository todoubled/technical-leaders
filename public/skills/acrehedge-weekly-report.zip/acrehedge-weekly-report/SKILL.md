---
name: acrehedge-weekly-report
description: Create AcreHedge's Weekly Commodity & Risk Management Report for U.S. row crop farmers. Use when user asks for "weekly report", "AcreHedge report", "commodity report", "market report", "grain markets update", or requests updates on corn, soybeans, wheat, rice, crude oil, diesel, or fertilizer prices. Triggers include "create weekly report", "write the commodity report", "AcreHedge weekly", or any request for agricultural commodity market summaries.
---

# AcreHedge Weekly Commodity & Risk Management Report

Generate a weekly commodity and risk management report for U.S. row crop farmers.

## Workflow

```
1. Search for current week's data (Monday-Friday of last week)
2. Gather commodity prices and news for each section
3. Write report following exact format and style rules
4. Review against writing rules checklist
5. Generate email subject line and intro paragraph
6. Generate social media snippets and caption
```

## Required Research

Use web_search to gather data from these sources (past 7 days only):

| Commodity | Search Terms |
|-----------|--------------|
| Corn | "corn futures CME", "USDA corn report", "corn exports" |
| Soybeans | "soybean futures", "soybean China demand", "soybean basis" |
| Wheat | "wheat futures Chicago", "global wheat supply", "wheat exports" |
| Rice | "rough rice USDA", "Arkansas rice harvest", "rice milling" |
| Fuel | "WTI crude oil", "diesel prices EIA", "retail diesel" |
| Fertilizer | "fertilizer prices DAP MAP urea", "phosphorus prices" |

**Trusted sources:** USDA, CME, ADM, DTN/Progressive Farmer, AgWeb, Reuters, EIA, Ever.Ag, The Western Producer, Investing.com, MarketWatch, Arkansas Row Crops Blog

## Report Format

```markdown
🌾 AcreHedge Weekly Commodity & Risk Management Report
Dateline: [Full date, e.g., December 22, 2025]

**Highlights – Key Market Insights**
[3-5 bullets]

**Commodity Spotlights**

🌽 **Corn**
[3-5 bullets]

🌱 **Soybeans**
[3-5 bullets]

🌾 **Wheat**
[3-5 bullets]

🍚 **Rice**
[3-5 bullets]

**Fuel & Input Cost Watch**
[3-5 bullets]

**Risk Management Quick Take**
[1-2 sentence paragraph with bolded key phrases]

**Major Sources**
[List outlets only, separated by bullets]

**Notes Block**
[Clickable links to source landing pages]
```

## Writing Rules

### Tone
- Neutral, farmer-friendly, confident — like a knowledgeable peer
- Conversational, not jargony
- **Bold** key words or takeaways inside each bullet

### Bullet Style
- Each bullet = one smooth, concise sentence
- NO labels like "price check" or "takeaway"
- Each line carries both info AND a sense of takeaway
- Don't repeat points across commodities

### Price References
- Write out months: "December corn" not "CZ25"
- Use measured verbs: "slipped," "held steady," "eased," "firmed"
- Avoid sweeping claims unless confirmed across multiple sources

### Crude Oil & Fuel
- Avoid directional claims like "crude ticked higher"
- Phrase weekly moves precisely: "crude eased this week, with a small rebound Monday morning"
- Always tie moves back to fuel or drying costs

### Geography
- Use direct geographic terms tied to the commodity
- ✅ "Soybean basis improved in parts of the Midwest"
- ❌ "Soybean basis firmed in the Corn Belt"

### Links Block
- One link per source from Major Sources
- Use landing pages, not deep article links

## Quality Checklist

Before finalizing, verify:
- [ ] All data from past 7 days only
- [ ] No imaginary or placeholder explanations
- [ ] Bold key takeaways in each bullet
- [ ] Months written out (not contract codes)
- [ ] Measured verbs throughout
- [ ] Geographic terms appropriate to commodity
- [ ] Fuel tied to farming costs
- [ ] Links are landing pages

## Email Subject & Intro

After generating the report, create email content for distribution.

### Subject Line Rules
- **6–10 words**
- Engaging but not alarmist
- Capture the **single strongest sentiment or theme** of the week
- Do NOT cover every commodity or fuel — pick one theme
- Examples: "Grains Mixed as Harvest Approaches", "Wheat Slips Under Global Supply Pressure"

### Intro Paragraph Rules
- **Two sentences only**
- **Sentence 1:** Broad recap of grain markets (corn, soybeans, wheat) with quick mention of fuel/inputs. High-level, no numbers.
- **Sentence 2:** Simple closing that introduces the report.

### Email Format

```
Subject: [6-10 word theme-focused subject line]

[Sentence 1: Broad market recap] [Sentence 2: Report intro]
```

### Email Example (style only)

```
Subject: Grains Mixed as Harvest Approaches

Corn held steady while soybeans firmed, but wheat slipped again under global supply pressure. Fuel and inputs were mostly stable. This week's AcreHedge report covers the key trends farmers should be watching.
```

## Social Media Snippets

After generating the email content, create social media snippets for distribution.

### Bullet Snippets Rules
- **Five bullets** covering key takeaways
- **No emojis, no em dashes**
- **Past tense** throughout
- Short, clear statements — as tight as possible
- Cover: corn, soybeans, wheat/rice (if relevant), fuel, fertilizer, or weather

### Caption Rules
- **1–2 sentences** summarizing the week
- Conversational, farmer-friendly tone
- End with CTA: "Sign up for the AcreHedge newsletter at **acrehedge.com**."

### Social Format

```
• [Corn takeaway]
• [Soybeans takeaway]
• [Wheat or rice takeaway]
• [Fuel takeaway]
• [Fertilizer or weather takeaway]

[1-2 sentence summary] Sign up for the AcreHedge newsletter at acrehedge.com.
```

### Social Example (style only)

```
• Corn held steady near $4.18 on large U.S. supply expectations.
• Soybeans eased to $10.43 with weak China demand.
• Chicago wheat fell 2% on heavy global stocks.
• Diesel stayed near $3.71, keeping harvest budgets stable.
• MAP led fertilizer prices at $906/ton.

Grains were mixed this week as harvest approaches and global supplies weigh on prices. Sign up for the AcreHedge newsletter at acrehedge.com.
```

## Reference

See [references/example-report.md](references/example-report.md) for a complete styled example.
