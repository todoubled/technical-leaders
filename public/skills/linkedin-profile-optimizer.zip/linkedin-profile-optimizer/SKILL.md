---
name: linkedin-profile-optimizer
description: LinkedIn personal branding and profile optimization for positioning a specialization in a particular niche. Use when the user wants to optimize their LinkedIn profile, improve their headline, about section, featured section, or experience descriptions. Triggers include requests to review a LinkedIn profile, rewrite profile sections, improve LinkedIn visibility, position for a specific niche or ICP, create a compelling personal brand, or turn a profile into a lead generation funnel.
---

# LinkedIn Profile Optimizer

Transform LinkedIn profiles from generic CV-style listings into conversion-focused funnels that attract ideal opportunities.

## Core Philosophy

Most LinkedIn profiles fail because they:
1. **Focus on features over benefits** - Listing skills instead of outcomes those skills create
2. **Read like a CV/resume** - No narrative, just boring facts that blend in
3. **Optimize for keywords** - Undersells capabilities; should optimize for conversion

The goal: Create an **attraction-based profile** that works while you sleep, bringing opportunities from ideal clients, speaking engagements, and valuable connections.

## Profile Optimization Workflow

### Step 1: Define the ICP and Next Step

Before optimizing any section, clarify:
- **Who is the Ideal Client Profile (ICP)?** What do they already know? What language resonates?
- **What is the ONE next step?** DM, book a call, or sign up for a lead magnet

All profile sections should reinforce this next step and speak to this ICP.

### Step 2: Headline (Most Valuable Real Estate)

**Formula:** Identity | Specialization | Outcome | Personal Brand Traits

| Element | Purpose | Example |
|---------|---------|---------|
| Identity | What you call yourself that resonates with ICP | Fractional CTO, Tech Advisor, Growth Partner |
| Specialization | Industry or domain focus | FinTech, Healthcare, SaaS |
| Outcome | Business result you create | "Taking startups from MVP to scale" |
| Personal Traits | Human connection points | "Dad, Drummer, Mountain Biker" |

**Critical considerations:**
- Use identity language your ICP understands (they may not know "Fractional CTO")
- Personal traits create conversation starters and icebreakers
- Don't list qualifications unless your ICP specifically values them
- Full headline shows in some UI views; don't truncate just for preview

**Avoid:**
- "X Company" pedigree emphasis (implies status-seeking over results)
- Long strings of certifications (unless ICP specifically values them)
- Generic titles that blend in with everyone else

### Step 3: Headshot

- Professional and uncluttered background
- Options: Candid action shot from professional event OR AI-enhanced professional headshot (Seca, ChatGPT image generation)
- Avoid: Messy backgrounds, animals, chaos, barely visible face

### Step 4: Banner

Two strategies (or combine both):

**Authority Positioning:** Bold claim establishing expertise
- Example: "I wrote the AI Playbook"
- Grabs attention, makes people want to verify the claim

**Call-to-Action:** Direct next step
- Example: "Get my free Cloud Security Audit Guide → [link]"
- Reinforces the funnel

**Combine:** Authority statement + CTA ("I wrote the playbook. Get it free → [link]")

Use Canva templates or AI image tools. First impression matters.

### Step 5: About Section (PASTOR Framework)

**Structure:** Hook → Problem → Agitation → Solution → Track Record → Offer → Response (CTA)

| Element | Purpose | Length |
|---------|---------|--------|
| Hook | Grab attention, make them read more | 1-2 punchy sentences |
| Problem | Name the problems you solve | 1-2 sentences |
| Agitation | Describe symptoms/consequences | 1-2 sentences |
| Solution | What you do to solve it | 1-2 sentences |
| Track Record | Where you've done this before | 1-2 sentences with specifics |
| Offer | How you can help them | 1-2 sentences |
| Response | Clear CTA | 1 sentence |

**Hook ideas:**
- Unique personal angle ("Currently in [country X] while helping clients [outcome]")
- Contrarian take
- Specific, impressive result

**Common mistake:** Great about section with NO call-to-action. Always end with the next step.

### Step 6: Featured Section

**Purpose:** Reinforce next step + establish credibility

**Strategy options:**
1. **Next step CTA** - Link directly to booking page or lead magnet (create as link with no description for clean button appearance)
2. **Best content** - Pin 1-3 posts that demonstrate philosophy and results
3. **Credibility** - Content featuring recognizable logos/people/results
4. **Objection handling** - Address biggest barrier in featured post (e.g., "without risking your primary income")

**Keep it focused:** No more than 3 items. Fewer options = better conversion.

**Pro tip:** Links appear as clickable buttons. To create button-style: add link with empty description/no media.

### Step 7: Experience Section

**Philosophy:** This is NOT your resume. It's narrative positioning.

**Guidelines:**
- Frame each role around **business outcomes**, not technical tasks
- Create an **upward arc** showing progression
- Remove terms of engagement (contract, freelance) unless "Remote" is strategic
- Collapse or remove roles that don't serve your positioning
- Keep pedigree roles visible if your ICP values them
- Emphasize results: revenue, exits, scale achieved

**Example framing:**
- Bad: "Managed engineering team of 15, implemented CI/CD pipelines"
- Good: "Built the engineering systems that enabled successful $50M exit"

## Before/After Output Format

When analyzing a profile, provide:

```
## HEADLINE
**Before:** [current headline]
**After:** [optimized headline following Identity | Specialization | Outcome | Personal Traits]
**Why:** [brief explanation of changes]

## ABOUT SECTION
**Before:** [current about or summary of issues]
**After:** [rewritten using PASTOR framework]
**Why:** [brief explanation]

## FEATURED SECTION
**Recommendations:**
- [specific recommendations for featured items]

## EXPERIENCE
**Key Changes:**
- [specific recommendations for positioning experience]

## PRIORITIZED ACTION PLAN
1. [highest impact change]
2. [second priority]
3. [etc.]
```

## Key Principles

1. **ICP-Centric Language:** Every word should resonate with your ideal client, not impress peers
2. **Outcomes Over Features:** Lead with results, not capabilities
3. **One Clear Next Step:** Remove friction, don't overwhelm with options
4. **Personal Connection:** Human traits create trust and conversation starters
5. **Narrative Over Facts:** Tell a story of progression, not a list of jobs
6. **Continuous Optimization:** Update as track record grows and ICP clarity improves

## Questions to Ask Users

- Who is your ideal client/opportunity? (Role, industry, company size)
- What outcome do you help them achieve?
- What's the ONE next step you want profile visitors to take?
- What personal interests/traits could create connection points?
- What results/track record can you highlight?
