---
name: fogg-prototype
description: Spec out functional ux features for feedback from your ICP
---

Read roadmap.md and ultrathink about the best way to create a simple and delightful user experience flow that follows the BJ Fogg Behavior Model of Motivation, Ability, and Prompt to influence and support users in accomplishing the jobs to be done and wedge features in the PRD. Write user stories formatted for linear that describe the user experience flow, screens and components that need to be built to create the full product experience in a new file called ux.md
