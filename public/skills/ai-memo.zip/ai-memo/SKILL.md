---
name: ai-memo
description: Create Tech Leaders' Weekly AI Memo for technical leaders and executives navigating AI transformation. Use when user asks for "AI memo", "weekly AI memo", "Tech Leaders memo", "AI newsletter", "AI update for leaders", or requests a summary of AI developments for executives. Triggers include "create AI memo", "write the weekly memo", "AI news for leaders", or any request for enterprise AI insights without technical jargon.
---

# Tech Leaders Weekly AI Memo

Generate a weekly AI memo for technical leaders and executives navigating AI transformation.

## Workflow

```
1. Search for current week's AI developments (Monday-Friday of last week)
2. Gather significant events from reputable sources
3. Identify actionable tip tied to Literacy, Leverage, or Leadership
4. Find or construct compelling use case with measurable outcomes
5. Write memo following exact format and style rules
6. Review against quality checklist
```

## Required Research

Use web_search to gather data from the past 7 days only:

| Topic | Search Terms |
|-------|--------------|
| AI Products | "Claude Anthropic announcement", "OpenAI release", "Google AI update", "Microsoft Copilot" |
| Enterprise AI | "enterprise AI adoption", "AI implementation Fortune 500", "AI ROI case study" |
| AI Policy | "AI regulation", "EU AI Act", "AI governance", "AI compliance" |
| AI Agents | "AI agents workflow", "autonomous AI", "agentic AI enterprise" |
| AI Revenue | "AI company revenue", "AI market growth", "AI investment" |

**Trusted sources:** TechCrunch, The Verge, Wired, MIT Technology Review, VentureBeat, Anthropic Blog, OpenAI Blog, Google DeepMind Blog, Microsoft AI Blog, Reuters Technology, Bloomberg Technology, Harvard Business Review, McKinsey Insights, Gartner

## Memo Format

```markdown
🤖 Tech Leaders Weekly AI Memo
Dateline: [Full date, e.g., December 22, 2025]

📰 This Week in AI — Significant Events
[3-5 bullets]

💡 AI Leverage Tip of the Week
[One actionable tip, 2-3 sentences, tied to Literacy/Leverage/Leadership]

🎯 Use Case Spotlight
[4-6 sentences: challenge → AI approach → measurable outcome]

🔗 Resources
[2-3 relevant links]
```

## The Three Pillars

Frame all insights through these lenses:

- **Literacy**: Understanding AI capabilities — what it can and cannot do
- **Leverage**: Applying AI to existing workflows with measurable ROI
- **Leadership**: Driving adoption and change management across teams

## Writing Rules

### Tone
- Neutral, leader-friendly, confident — like a knowledgeable peer who's been through AI transformations
- Conversational, not jargony — accessible to non-technical executives
- **Bold** key words or takeaways inside each bullet and use case
- Emojis in section headers only (🤖, 📰, 💡, 🎯, 🔗)

### Event Bullets (📰 Section)
- Each bullet = one smooth, concise sentence
- NO labels like "key point" or "main takeaway"
- Each line carries both info AND clear implication for leaders
- Avoid sweeping claims like "AI is transforming everything"
- Use precise phrasing: specific company names, product updates, policy changes
- Always tie back to practical implications — what should leaders do or consider?

### Leverage Tip (💡 Section)
- One actionable tip in 2-3 sentences
- Immediately implementable without coding
- Explicitly connect to one of the three pillars
- Focus on AI agent workflows or human+AI collaboration patterns

### Use Case Spotlight (🎯 Section)
- Use real company examples when available from published sources
- If composite/anonymized: "A [industry] organization..."
- Structure: before state → AI intervention → measurable after state
- Include specific metrics when available (time saved, cost reduced, quality improved)
- 4-6 sentences total
- **Bold** key outcomes

### Language Guardrails
- **Use:** "announced," "released," "reported," "demonstrated"
- **Avoid:** "revolutionary," "game-changing," "unprecedented" (unless directly quoting)
- Maintain context: 85% of AI initiatives fail — these insights help readers avoid becoming a statistic

### Human + AI Collaboration Focus
Prioritize developments and tips that emphasize:
- AI agents that augment rather than replace human judgment
- Workflow patterns where humans supervise AI outputs
- Collaborative intelligence (human expertise + AI scale)
- Change management approaches for AI adoption

## Quality Checklist

Before finalizing, verify:
- [ ] All data from past 7 days only
- [ ] No imaginary or speculative explanations
- [ ] Bold key takeaways in each bullet
- [ ] No "revolutionary" or hype language
- [ ] Each event has practical implication for leaders
- [ ] Tip is immediately actionable without coding
- [ ] Use case has measurable outcome
- [ ] Resources are 2-3 relevant links

## Reference

See [references/example-memo.md](references/example-memo.md) for a complete styled example.
