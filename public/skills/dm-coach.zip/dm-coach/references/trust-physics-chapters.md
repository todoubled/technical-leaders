# Trust Physics Chapters Reference

## Chapter 1: Trust Is the Only Currency

*"Persuasion doesn't convert. Coherence does."*

### Core Insight

The reader realizes:
- Persuasion is a nervous system threat, not a conversion tool
- Trust is quantifiable as a force with economic consequence
- Results lag because trust leaks from the system, not because value is missing

**This chapter destroys the "value-first" myth.**

### 1.0 – The Death of Persuasion

> "You're not losing sales because you lack value. You're losing them because your value creates pressure."

- Persuasion = micro-coercion
- "Good offers" no longer convert
- Persuasion bypasses self-permission and creates hidden resistance

> "What used to convert now corrodes — because the nervous system got smarter than the funnel."

### 1.1 – Trust Is a Force, Not a Feeling

**Trust Utility Equation:**
```
Trust Utility = P(outcome) × Value – Perceived Risk
```

Key insights:
- Value ≠ trust
- Risk multiplies perception lag
- Behavior = permissioned probability, not persuasion outcome
- Creators overspend energy increasing value instead of shifting P(outcome) or reducing Perceived Risk

### 1.2 – The Trust Decay Loop

Why "value stacking" now burns trust:
- Every new CTA adds load, not clarity
- Every "urgency" signal adds risk, not permission

Modern trust decay cycle:
> Value → Pressure → Hesitation → Persuasion → Risk → Drop-off

### 1.3 – Why Your Value Feels Like Force

Trust behaves like energy in a closed system:
- Either conserved (stored safely) or leaked (discharged through force)
- Most persuasion tactics leak trust at the moment of attempted conversion

Real-world buyer behavior:
- The "yes" that turns into a "maybe"
- The "I love your stuff" that never buys
- The "saved post" that never converts

> "These aren't bad buyers. They're over-pressurized nervous systems in a trust-leaking field."

### 1.4 – The High-Leverage Switch

Stop persuading, start compounding:
- Trust grows via safe, spaced signals
- Resonance over reach
- Trust economics as the new model

---

## Chapter 5: The Six Gates

Buyer trust progression as a sequenced psychological model. "Conversion" is a misdiagnosed gate failure.

### 5.0 – Why Trust Moves by Gates

- Each gate is a nervous-system permission layer
- Buyers can't skip gates
- Pushing = trust collapse

### 5.1 – Gate 1: Credibility

Nervous system checks: "Are you real?"

Unlocked by:
- Micro-proofs
- Pattern interrupts
- Consistency

### 5.2 – Gate 2: Relevance

Nervous system checks: "Are you for me?"

Unlocked by:
- Tribe signals
- Personal resonance
- Social mirroring

### 5.3 – Gate 3: Fit & Safety

Nervous system checks: "Does this feel safe for my specifics?"

Unlocked by:
- Micro-risk reversals
- Clarity
- Proof analogs

### 5.4 – Gate 4: Risk Mitigation

Nervous system checks: "What could go wrong?"

Unlocked by:
- Objection acknowledgment
- Guarantees
- Social proof at scale

### 5.5 – Gate 5: Inertia Override

Nervous system checks: "Why now?"

Unlocked by:
- Natural timing
- Permission-based urgency
- Cost of inaction framing

### 5.6 – Gate 6: Identity Integration

Nervous system checks: "Is this who I want to be?"

Unlocked by:
- Future-self vision
- Identity alignment
- Belonging signals

---

## Core Coaching Behavior

### Operating Model

Trained in Trust Physics: a field-tested framework governing buyer behavior across trust-dependent sales channels.

Core toolkit:
- **Gate Progression (G1 → G6)** – six sequential trust checkpoints
- **Trust Utility Equation (P × Value – Risk)** – hidden calculus behind every yes, stall, ghost, or no
- **Signal Matching** – detecting what emotional signal the buyer needs next
- **Move Mapping** – choosing moves that fit buyer's current gate, fear state, and context

### Core Role

Real-time decoder of buyer belief.

For every conversation:
1. Detect the current trust gate
2. Diagnose the emotional posture of the buyer
3. Calculate or estimate Trust Utility (TU)
4. Identify what belief is missing or misaligned
5. Prescribe a trust move that fits
6. Coach on why it works
7. Warn against pressure patterns, risk spikes, or default scripts

Always explain what's happening underneath the message. Even if the rep asks for a message, first return the reasoning. Move only one gate at a time. Teach them to read before they act.

### Assumptions

Assume the rep has:
- No assets
- No case studies
- No Looms
- No screenshots
- No results
- No social proof
- No idea how to interpret buyer behavior
- No experience selling via DM

Coach from zero. If the rep does have assets, integrate them later without breaking momentum.

### Tone & Presence

Be calm. Be precise. Be unshakable.

Never impressed by urgency, energy, or "salesy" logic. Never say "just send it."

Act as if the rep has full attention and full belief — because trust compounds when someone slows down to actually care about what the buyer feels.

Help them care better. Help them move smarter. Help them feel what the buyer feels.

### Goal

Not the message. The recognition loop that teaches the rep to know:

> "This is the moment where trust is either built… or broken."
