# Trust Physics Frameworks Reference

## Reasoning Mesh Paradigm & Injection Loop

- Turns raw IP into GPT-friendly logic
- Makes sure each trust / TU / gate concept is modular, injectable, repeatable

## Lead Generation Trust OS

Recursive system for trust-compounding on LinkedIn. Memory-driven, not funnel-driven.

Major layers:
- Trust Math Primer
- Trust Memory Layer
- Gate Progression G1-G6
- Trust Signal Lag
- Conversation Trust Model
- Conversion Trust Model
- Offer Campaign Loop
- Recursive Offer Surface Map
- DM Rehydration Sequence

## Paid Workshop Architecture

- How to design G3 → G5 trust events
- Async rehydration after
- TU spikes via temporary intensity, then soft reentry

## Offer Doc Believability Grid

- Ensures final decks/docs align with tone & promise from earlier stages
- Reduces micro-breaches
- Reduces perceived risk

## Trust Decay vs Niche Width

Shows decay curve by market type:
- Narrow = slower decay
- Wide = faster decay
- Explains why wide funnels collapse faster

## DM Rehydration & Memory Models

How to revive old threads:
- Memory traces, parasocial residue
- How to make it feel like "just picking back up"

## Modality Playbook

Each modality has TU impact & trust risk:
- Text
- Voice
- Loom
- Zoom
- IRL

Use risk ladder to decide when to escalate.

## Belief Conversion Map

6 belief shifts before yes:
1. Self-Relevance
2. Problem Realness
3. Solution Believability
4. Self-Efficacy
5. Risk Justifiability
6. Timing Permission

## Storytelling Framework

9 nodes for emotional proof stories. Used inside posts, DMs, Looms.

## Trust Compression & Saturation

- When to compress trust with modality
- When to let it breathe for compounding

## DISC × Cialdini Overlays

Maps DISC type to expected biases. Helps adjust trust vs urgency levers.

## Workshop SOPs

- DM + CRM tagging post workshops
- Weekly boards to track movement
- Prompt templates for GPT

## Scientific Citations

- Mere exposure (Zajonc)
- Spacing effect (Ebbinghaus)
- Affective continuity (Fogg)
- Somatic trust markers (Damasio)

## Design Philosophy

Built to be timeless — frameworks designed to outlast channels.
