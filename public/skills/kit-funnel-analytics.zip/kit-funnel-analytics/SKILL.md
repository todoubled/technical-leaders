---
name: kit-funnel-analytics
description: Marketing funnel and conversion analysis using Kit (ConvertKit) MCP server. Use when user asks for email marketing analytics, open rates, click rates, subscriber engagement, lead scoring, identifying hot leads, sales prioritization, subscriber segmentation, or funnel performance analysis. Triggers include "analyze my Kit subscribers", "find hot leads", "show email performance", "segment my list", "prioritize leads for outreach", "conversion funnel", or any Kit/ConvertKit analytics request.
---

# Kit Funnel Analytics

Analyze marketing funnel performance and identify high-value leads using Kit MCP tools.

## Quick Reference: Key Tools

| Analysis Type | Primary Tool | Secondary Tools |
|--------------|--------------|-----------------|
| Email performance | `kit_list_broadcasts` + `kit_get_broadcast` | - |
| Subscriber health | `kit_list_subscribers` | `kit_get_subscriber` |
| Segmentation | `kit_list_tags` | `kit_list_tag_subscribers` |
| Form conversion | `kit_list_forms` | `kit_get_form` |
| Sequence funnel | `kit_list_sequences` | `kit_get_sequence` |

## Core Workflows

### 1. Email Performance Analysis

```
1. kit_list_broadcasts → get all campaigns
2. For each broadcast: extract subject, open_rate, click_rate, sent_at
3. Calculate: avg_open_rate, avg_click_rate, trend over time
4. Identify: top/bottom performers by engagement
```

**Key metrics from broadcasts:**
- `open_rate` - percentage who opened
- `click_rate` - percentage who clicked  
- `stats.recipients` - total sent
- `stats.open_count` - raw opens
- `stats.click_count` - raw clicks

### 2. Lead Scoring & Hot Lead Identification

Score subscribers by engagement signals. See [references/lead-scoring.md](references/lead-scoring.md) for full methodology.

**Quick scoring heuristic:**
- Tag density: more tags = more engaged
- Recent activity: created_at recency
- Status: active > inactive
- Sequence progress: further = warmer

```
1. kit_list_subscribers (status: "active") → get active base
2. For hot prospects: kit_get_subscriber_tags per subscriber
3. Score by: tag_count × recency_factor × engagement_signals
4. Rank and segment into tiers
```

### 3. Segmentation Analysis

```
1. kit_list_tags → enumerate all segments
2. For key segments: kit_list_tag_subscribers → get counts and members
3. Cross-reference: identify subscribers in multiple high-value tags
4. Output: segment sizes, overlap analysis, growth trends
```

**High-value tag patterns to identify:**
- Purchase/buyer tags
- Engagement tags (clicked, opened, replied)
- Interest tags (topic-specific)
- Stage tags (lead, prospect, customer)

### 4. Funnel Stage Analysis

```
1. kit_list_sequences → get all nurture sequences
2. kit_list_forms → get all capture points  
3. Map: form → sequence → tags flow
4. Calculate: conversion rates between stages
```

## Output Formats

### Sales Prioritization Report

```markdown
## Hot Leads for Outreach

### Tier 1: Immediate Priority (Score 80+)
| Name | Email | Tags | Last Active | Score |
|------|-------|------|-------------|-------|

### Tier 2: Warm Leads (Score 50-79)
...

### Tier 3: Nurture Queue (Score <50)
...
```

### Funnel Performance Dashboard

```markdown
## Email Performance (Last 30 Days)
- Broadcasts sent: X
- Avg open rate: X%
- Avg click rate: X%  
- Top performer: [subject] (X% open)

## List Health
- Total subscribers: X
- Active: X (X%)
- New this month: X

## Segment Breakdown
| Segment | Count | % of List |
|---------|-------|-----------|
```

## Tool Limitations & Workarounds

**No direct open/click tracking per subscriber:** Kit API doesn't expose individual-level email engagement. Workaround: Use tags to track engagement (create automation rules in Kit to tag opens/clicks).

**No revenue data:** Kit API doesn't include purchase data. Workaround: Cross-reference with external purchase tags or custom fields.

**Pagination required:** Large lists need multiple calls with `after` cursor parameter.

## Reference Files

- [references/lead-scoring.md](references/lead-scoring.md) - Full lead scoring methodology and formulas
- [references/kit-tools.md](references/kit-tools.md) - Complete Kit MCP tool reference
