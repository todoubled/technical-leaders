# Kit MCP Tools Reference

Complete reference for Kit (ConvertKit) MCP server tools.

## Account

### kit_get_account
Get account information.
```
Returns: name, plan, billing info
```

## Subscribers

### kit_list_subscribers
List subscribers with filters and pagination.
```
Parameters:
- status: "active" | "inactive" | "bounced" | "complained" | "cancelled"
- created_after: ISO date filter
- created_before: ISO date filter  
- sort_field: "created_at" | "updated_at"
- sort_order: "asc" | "desc"
- per_page: number (max 100)
- after: cursor for pagination

Returns: subscribers[], pagination.next_cursor
```

**Use for:** List building, filtering by status/date, pagination through full list

### kit_get_subscriber
Get single subscriber by ID.
```
Parameters:
- subscriber_id: string

Returns: id, email, first_name, state, created_at, fields{}
```

### kit_create_subscriber
Create new subscriber.
```
Parameters:
- email_address: string (required)
- first_name: string
- state: "active" | "inactive"
- fields: object (custom fields)
```

### kit_update_subscriber
Update existing subscriber.
```
Parameters:
- subscriber_id: string (required)
- email_address: string
- first_name: string
- fields: object
```

## Tags

### kit_list_tags
List all tags with pagination.
```
Parameters:
- per_page: number
- after: cursor

Returns: tags[] with id, name, created_at
```

**Use for:** Enumerate segments, find tag IDs for filtering

### kit_get_tag
Get specific tag by ID.
```
Parameters:
- tag_id: string
```

### kit_create_tag
Create new tag.
```
Parameters:
- name: string
```

### kit_update_tag
Update tag name.
```
Parameters:
- tag_id: string
- name: string
```

### kit_delete_tag
Delete a tag.
```
Parameters:
- tag_id: string
```

### kit_list_tag_subscribers
List subscribers with specific tag.
```
Parameters:
- tag_id: string (required)
- per_page: number
- after: cursor

Returns: subscribers[] in that tag
```

**Use for:** Segment analysis, counting tag membership

### kit_get_subscriber_tags
Get all tags for a subscriber.
```
Parameters:
- subscriber_id: string

Returns: tags[] applied to subscriber
```

**Use for:** Lead scoring, engagement analysis per subscriber

### kit_add_tag_to_subscriber
Apply tag to subscriber.
```
Parameters:
- subscriber_id: string
- tag_id: string
```

### kit_remove_tag_from_subscriber
Remove tag from subscriber.
```
Parameters:
- subscriber_id: string
- tag_id: string
```

## Broadcasts (Email Campaigns)

### kit_list_broadcasts
List all email campaigns.
```
Parameters:
- per_page: number
- after: cursor

Returns: broadcasts[] with id, subject, stats, sent_at
```

**Key stats returned:**
- `open_rate` - open percentage
- `click_rate` - click percentage
- `stats.recipients` - emails sent
- `stats.open_count` - total opens
- `stats.click_count` - total clicks

### kit_get_broadcast
Get specific broadcast details.
```
Parameters:
- broadcast_id: string

Returns: full broadcast with content, stats, preview
```

### kit_create_broadcast
Create email campaign.
```
Parameters:
- subject: string (required)
- content: string (HTML)
- description: string (internal)
- preview_text: string
- public: boolean
- send_at: ISO date
```

### kit_update_broadcast
Update draft broadcast.
```
Parameters:
- broadcast_id: string (required)
- subject, content, description, preview_text, public, send_at
```

### kit_delete_broadcast
Delete broadcast.
```
Parameters:
- broadcast_id: string
```

## Sequences (Automation)

### kit_list_sequences
List email sequences.
```
Parameters:
- per_page: number
- after: cursor

Returns: sequences[] with id, name, created_at
```

### kit_get_sequence
Get sequence details.
```
Parameters:
- sequence_id: string

Returns: sequence with emails, settings
```

### kit_add_subscriber_to_sequence
Add subscriber to sequence.
```
Parameters:
- sequence_id: string
- email: string (subscriber email)
```

## Forms

### kit_list_forms
List signup forms.
```
Parameters:
- status: "active" | "archived" | "trashed" | "all"
- per_page: number
- after: cursor

Returns: forms[] with id, name, type, created_at
```

### kit_get_form
Get form details.
```
Parameters:
- form_id: string

Returns: form settings, fields, stats
```

### kit_add_subscriber_to_form
Subscribe via form (creates if new).
```
Parameters:
- form_id: string
- email: string (required)
- first_name: string
- fields: object
```

## Custom Fields

### kit_list_custom_fields
List custom field definitions.
```
Returns: fields[] with key, label, type
```

**Use for:** Understanding data schema, identifying scorable attributes

## Webhooks

### kit_list_webhooks
List configured webhooks.
```
Parameters:
- per_page: number
- after: cursor
```

### kit_create_webhook
Create webhook endpoint.
```
Parameters:
- target_url: string (required)
- event_name: string (required) e.g. "subscriber.subscriber_activate"
- form_id, sequence_id, tag_id: optional filters
```

### kit_delete_webhook
Remove webhook.
```
Parameters:
- webhook_id: string
```

## Pagination Pattern

All list endpoints use cursor-based pagination:

```
# First call
result = kit_list_subscribers(per_page=100)
process(result.subscribers)

# Subsequent calls if more data
while result.pagination.next_cursor:
    result = kit_list_subscribers(per_page=100, after=result.pagination.next_cursor)
    process(result.subscribers)
```

## Common Workflows

### Full subscriber export with tags
```
1. kit_list_subscribers(status="active", per_page=100)
2. Loop with pagination cursor
3. For each subscriber: kit_get_subscriber_tags
4. Aggregate data
```

### Email performance report
```
1. kit_list_broadcasts(per_page=50)
2. Extract: subject, open_rate, click_rate, sent_at
3. Calculate averages, trends
4. Identify top/bottom performers
```

### Segment size analysis
```
1. kit_list_tags()
2. For each tag: kit_list_tag_subscribers (count results)
3. Output segment sizes
```
