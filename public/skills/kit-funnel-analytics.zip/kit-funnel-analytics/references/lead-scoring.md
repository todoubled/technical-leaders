# Lead Scoring Methodology

Score subscribers 0-100 to prioritize sales outreach.

## Scoring Formula

```
Total Score = Tag Score (40%) + Recency Score (30%) + Engagement Score (30%)
```

## Component Calculations

### Tag Score (0-40 points)

Tags indicate interest depth and funnel progression.

| Tag Category | Points | Examples |
|-------------|--------|----------|
| Purchase/Customer | +15 | `customer`, `buyer`, `purchased` |
| High-Intent | +12 | `demo-requested`, `pricing-viewed`, `trial` |
| Engagement | +8 | `clicked-*`, `opened-*`, `replied` |
| Interest/Topic | +5 | `interested-*`, topic-specific tags |
| Source/Entry | +2 | `webinar`, `lead-magnet`, form-specific |

**Calculation:**
```python
tag_score = min(40, sum(category_points_for_each_tag))
```

### Recency Score (0-30 points)

Recent subscribers are warmer.

| Days Since Created | Points |
|-------------------|--------|
| 0-7 days | 30 |
| 8-14 days | 25 |
| 15-30 days | 20 |
| 31-60 days | 15 |
| 61-90 days | 10 |
| 90+ days | 5 |

**Calculation:**
```python
days_old = (today - created_at).days
if days_old <= 7: recency_score = 30
elif days_old <= 14: recency_score = 25
elif days_old <= 30: recency_score = 20
elif days_old <= 60: recency_score = 15
elif days_old <= 90: recency_score = 10
else: recency_score = 5
```

### Engagement Score (0-30 points)

Proxy engagement via available signals.

| Signal | Points |
|--------|--------|
| Active status | +10 |
| Has custom fields populated | +5 |
| In active sequence | +8 |
| Multiple tags (3+) | +7 |
| Has first_name | +2 |

**Calculation:**
```python
engagement_score = 0
if status == "active": engagement_score += 10
if custom_fields_count > 0: engagement_score += 5
if in_sequence: engagement_score += 8  # requires sequence lookup
if tag_count >= 3: engagement_score += 7
if first_name: engagement_score += 2
engagement_score = min(30, engagement_score)
```

## Lead Tiers

| Tier | Score Range | Action |
|------|-------------|--------|
| **Hot** | 80-100 | Immediate personal outreach |
| **Warm** | 60-79 | Prioritized follow-up within 48hrs |
| **Engaged** | 40-59 | Targeted nurture sequence |
| **Cool** | 20-39 | Standard nurture |
| **Cold** | 0-19 | Re-engagement or archive |

## Implementation Pattern

```
# Step 1: Pull active subscribers
subscribers = kit_list_subscribers(status="active", per_page=100)

# Step 2: For each subscriber, get tags
for sub in subscribers:
    tags = kit_get_subscriber_tags(subscriber_id=sub.id)
    
# Step 3: Calculate scores
    tag_score = calculate_tag_score(tags)
    recency_score = calculate_recency_score(sub.created_at)
    engagement_score = calculate_engagement_score(sub, tags)
    total_score = tag_score + recency_score + engagement_score

# Step 4: Rank and output
sort by total_score descending
group by tier
```

## Tag Pattern Recognition

Identify high-value tags by naming patterns:

**Purchase indicators:** `customer`, `buyer`, `client`, `purchased-*`, `order-*`

**Intent indicators:** `demo`, `trial`, `pricing`, `sales-*`, `contacted-*`

**Engagement indicators:** `clicked-*`, `opened-*`, `engaged-*`, `active-*`

**Negative indicators (reduce score):** `unsubscribed`, `bounced`, `complained`, `cold`

## Custom Field Signals

Check `kit_list_custom_fields` for additional scoring data:
- Company/organization field → B2B lead
- Phone number → Higher intent  
- Budget/timeline fields → Sales qualified

## Output: Hot Leads Report

```markdown
## Hot Leads for Sales Outreach
Generated: [date]

### Tier 1: Immediate Priority (Score 80+)
| Rank | Name | Email | Score | Key Tags | Created |
|------|------|-------|-------|----------|---------|
| 1 | [name] | [email] | 95 | customer, demo-requested | 2 days ago |

### Key Insights
- X hot leads identified
- Top tag correlation: [tag]
- Avg days to hot: X days
```
