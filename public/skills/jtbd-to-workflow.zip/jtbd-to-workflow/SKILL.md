---
name: jtbd-to-workflow
description: Break down a job-to-be-done or task into a step-by-step SOP that can be turned into an AI workflow. Use when the user wants to decompose a process into automatable steps, create AI workflows from existing tasks, identify which steps need human oversight, or prepare SOPs for skill creation. Triggers include "break down my process", "turn this into an AI workflow", "create an SOP for", "automate my workflow", or any request to systematize a repeatable task.
---

# JTBD to AI Workflow Skill

Transform tacit knowledge and informal processes into structured SOPs with clear AI/Human designations, ready for individual skill creation.

## Workflow Overview

1. **Discovery** → Extract the full process through structured interview
2. **Decomposition** → Break into discrete, atomic steps
3. **Classification** → Designate each step as AI or Human-In-Loop (HIL)
4. **SOP Structuring** → Format into actionable SOP document
5. **Skill Planning** → Generate skill specs for each AI step

## Phase 1: Discovery Interview

Never assume the process is fully known. Extract tacit knowledge through progressive questioning.

### Opening Questions
Ask 1-2 at a time, not all at once:

- "Walk me through the last time you did this task from start to finish"
- "What triggers you to start this task? How do you know it's time?"
- "What does 'done' look like? How do you know you're finished?"

### Depth Questions
Once you have the basic flow:

- "What information do you need before you can start?"
- "What tools, files, or systems do you touch during this?"
- "Where do you typically get stuck or slow down?"
- "What decisions do you make along the way? What factors influence them?"
- "What could go wrong? How do you catch and fix errors?"
- "Are there variations? What changes based on the situation?"

### Hidden Knowledge Questions
These surface expertise the user doesn't realize they have:

- "What would someone new to this task get wrong?"
- "What shortcuts have you learned over time?"
- "What do you check that isn't written down anywhere?"
- "When do you know something is 'good enough' vs needs more work?"

## Phase 2: Decomposition

Break the process into atomic steps. Each step should be:

- **Single-action**: One verb, one outcome
- **Observable**: Clear input and output
- **Testable**: You can verify it was done correctly
- **Independent**: Minimal dependencies on other steps

### Decomposition Pattern

```
STEP [N]: [Action Verb] + [Object]
├── Input: What this step receives
├── Action: What happens (be specific)
├── Output: What this step produces
├── Success Criteria: How to verify completion
└── Failure Modes: What could go wrong
```

## Phase 3: AI vs HIL Classification

For each step, apply these decision criteria:

### Designate as AI when:
- Deterministic transformation (data formatting, calculations)
- Pattern matching against known templates
- Information retrieval and synthesis
- Content generation with clear parameters
- Repetitive decisions with consistent rules

### Designate as HIL when:
- Judgment calls with significant consequences
- Subjective quality assessment
- Stakeholder communication requiring nuance
- Decisions involving ambiguous or incomplete information
- Actions that are irreversible or expensive to undo
- Regulatory or compliance sign-offs
- Novel situations outside established patterns

### HIL Types
- **HIL-Approve**: AI does the work, human approves before proceeding
- **HIL-Decide**: Human makes the decision, AI executes
- **HIL-Review**: AI completes, human reviews output quality
- **HIL-Execute**: Human performs the action entirely

## Phase 4: SOP Output Template

Generate the SOP as a markdown file using this structure:

```markdown
# SOP: [Process Name]

## Overview
- **Job-to-be-Done**: [When X, I want to Y, so I can Z]
- **Trigger**: [What initiates this workflow]
- **End State**: [What "done" looks like]
- **Frequency**: [How often this runs]
- **Estimated Duration**: [Total time with/without AI]

## Prerequisites
- [ ] [Required input/access/tool]
- [ ] [Required input/access/tool]

## Workflow Steps

### Step 1: [Step Name] `[AI]` or `[HIL-Type]`
**Input**: [What this step receives]
**Action**: [Specific action to take]
**Output**: [What this step produces]
**Success Criteria**: [How to verify]
**Notes**: [Edge cases, tips, warnings]

---

### Step 2: [Step Name] `[AI]` or `[HIL-Type]`
...

## Error Handling
| Error Condition | Detection | Resolution |
|----------------|-----------|------------|
| [What could go wrong] | [How to detect] | [How to fix] |

## Variations
- **[Variation Name]**: [How workflow differs]

## Metrics
- **Quality**: [How to measure output quality]
- **Efficiency**: [Time/effort benchmarks]
```

## Phase 5: Skill Spec Generation

For each step designated as `[AI]`, generate a skill specification:

```markdown
## Skill Spec: [Step Name]

### Frontmatter
- **name**: [skill-name-kebab-case]
- **description**: [What it does + when to trigger]

### Inputs
- [Input 1]: [type, source, format]
- [Input 2]: [type, source, format]

### Processing Logic
[Pseudocode or plain language description of what the AI does]

### Outputs
- [Output 1]: [type, format, destination]

### Quality Criteria
- [Criterion 1]
- [Criterion 2]

### Example
**Input**: [Sample input]
**Expected Output**: [Sample output]

### Dependencies
- Upstream: [Which step feeds this]
- Downstream: [Which step receives output]
```

## Deliverable

Save output to: `sop-[process-name].md`

Include:
1. Complete SOP with all steps classified
2. Skill specs for each AI step (in a "Skill Specifications" section at the end)
3. Summary table showing step count by designation (AI vs HIL breakdown)
