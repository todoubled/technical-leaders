# Opening Hooks

Proven patterns for book openings that grab readers and don't let go.

---

## The First 3 Pages: Your Only Chance

Bookstore browsers decide in 8 seconds. Online buyers read the sample. Your opening must:
1. Create immediate curiosity
2. Promise a specific transformation
3. Establish your credibility (implicitly)
4. Make continuing irresistible

---

## Pattern 1: The Moment of Crisis

Start with a vivid scene at a turning point.

**Structure**:
```
[Specific moment in time]
[Sensory detail that puts reader in the scene]
[The realization or decision]
[Why this changed everything]
```

**Example (Traction-style)**:
> "It was 2 AM on a Tuesday when I finally admitted the truth: my business was running me.
>
> I sat in my car outside the office—the same office I'd left only six hours earlier—staring at my phone. Seventeen unread messages. Three client emergencies. One resignation letter.
>
> In that moment, I made a decision that would transform everything: I would build a business that could run without me. Not someday. Starting now.
>
> This book is the system I discovered."

---

## Pattern 2: The Shocking Statistic

Lead with data that challenges assumptions.

**Structure**:
```
[The surprising number]
[What it means]
[Why conventional wisdom is wrong]
[What you'll reveal]
```

**Example (Hormozi-style)**:
> "8 out of 10 businesses fail within 18 months.
>
> You know this. But here's what nobody talks about: the 2 that survive aren't working harder. They're not smarter. They don't have better products.
>
> They have better offers.
>
> An irresistible offer can sell a mediocre product. A mediocre offer can't sell a perfect product. This book shows you how to build offers people feel stupid saying no to."

---

## Pattern 3: The Direct Promise

State the transformation plainly and boldly.

**Structure**:
```
[What the reader wants]
[The obstacle in their way]  
[Your unique solution]
[What makes this different]
```

**Example (Carnegie-style)**:
> "This book will change how people respond to you.
>
> Not through manipulation. Not through tricks. Through understanding what every human being craves—and giving it to them genuinely.
>
> In the next 100 pages, you'll learn principles that have worked for 80 years across every culture, industry, and situation. They worked for a shy accountant who became CEO. For a struggling salesman who built an empire. For millions of ordinary people who became extraordinary communicators.
>
> They'll work for you."

---

## Pattern 4: The Myth-Buster

Challenge a widely-held belief.

**Structure**:
```
[The common belief]
[Why everyone believes it]
[The evidence it's wrong]
[The truth that changes everything]
```

**Example**:
> "Hard work doesn't pay off.
>
> I know—that sounds wrong. We've been taught since childhood that effort equals reward. Put in the hours. Grind harder. Success will follow.
>
> But look around. The most successful people you know aren't the hardest workers. The wealthiest aren't the busiest. The most fulfilled aren't the most exhausted.
>
> What do they have instead? A system. This book gives you that system."

---

## Pattern 5: The Question Cascade

Open with questions that create urgency.

**Structure**:
```
[Question about current pain]
[Question about desired state]
[Question about the gap]
[Promise to answer]
```

**Example**:
> "What would change if you had an extra 20 hours every week?
>
> What if you could scale without sacrificing your sanity?
>
> What's the ONE thing keeping you from both?
>
> Most business owners think the answer is hiring more people. Or better tools. Or working harder. They're wrong. The answer is simpler—and more powerful—than any of those.
>
> Keep reading."

---

## Pattern 6: The Origin Story

Begin with your personal "why."

**Structure**:
```
[The moment of frustration or failure]
[What you discovered]
[The results that followed]
[Why you wrote this book]
```

**Example**:
> "I wrote this book because I wish someone had written it for me.
>
> Ten years ago, I was working 80-hour weeks, missing my kids' lives, and making less than my employees. I read every business book. Hired the consultants. Tried all the tactics.
>
> Nothing worked—until I stumbled onto a simple system that changed everything. Within 18 months, I'd cut my hours in half and tripled my revenue.
>
> I've since taught this system to 500+ business owners. It works every time. Now it's your turn."

---

## Pattern 7: The Contrast Open

Show the before and after immediately.

**Structure**:
```
[Life/business BEFORE the transformation]
[Life/business AFTER the transformation]  
[The bridge between them (your book)]
```

**Example**:
> "Two businesses. Same market. Same product. Same price.
>
> One struggles to make $30K/month. The other prints $300K.
>
> What's the difference? It's not the founder's intelligence. Not their funding. Not their luck.
>
> It's a system. A simple, repeatable system that anyone can implement. You're about to learn it."

---

## Opening Don'ts

❌ Don't start with dictionary definitions
❌ Don't start with "In today's fast-paced world..."
❌ Don't start with your biography
❌ Don't start with methodology explanation
❌ Don't start with acknowledgments or setup
❌ Don't start by explaining what the book is about

---

## The First Sentence Test

Your first sentence should make someone want to read the second sentence. Period.

**Weak first sentences**:
- "This book is about..." (boring)
- "Let me start by saying..." (stalling)
- "The topic of X has been..." (academic)
- "Many people struggle with..." (generic)

**Strong first sentences**:
- "I fired my biggest client on a Tuesday." (curiosity)
- "The secret to sales is to stop selling." (paradox)
- "Everything changed with one phone call." (story)
- "Most advice about X is wrong." (challenge)

---

## Template: The Complete Opening (2-3 Pages)

```
[HOOK: First sentence that stops them cold]

[SCENE/STORY: 150-200 words that create emotional connection]

[THE PROBLEM: What readers are struggling with - be specific]

[THE PROMISE: What this book delivers - be bold]

[THE PROOF: Quick credential or result that establishes authority]

[THE PATH: Brief roadmap of what's coming]

[THE INVITATION: Why to keep reading NOW]
```

Total: 500-750 words. No fluff. Every sentence earns its place.
