# World-Class Editor Checklist

The RUTHLESS framework for editing like a professional book editor.

---

## The RUTHLESS Edit Framework

### R - Remove the Redundant
Every idea appears ONCE. If you've said it, don't say it again.

**Check for**:
- Repeated concepts across chapters
- Sentences that say the same thing twice
- Examples that illustrate identical points
- Conclusions that restate introductions

**Editor question**: "Have I already made this point?"

---

### U - Unstuff the Sentences
Maximum 25 words per sentence. Average should be 12-18.

**Before**:
> "The implementation of strategic initiatives requires the coordination of multiple stakeholders across various departments in order to achieve the desired outcomes and objectives."

**After**:
> "Strategic initiatives require stakeholder coordination. Without it, nothing happens."

**Editor question**: "Can I split this sentence in two?"

---

### T - Tighten the Paragraphs
Maximum 4 sentences per paragraph. White space is your friend.

**Before**: Wall of text that readers skip.
**After**: Scannable chunks that readers absorb.

**Editor question**: "Where can I add a line break?"

---

### H - Hack the Hedging
Delete: maybe, perhaps, somewhat, rather, quite, really, very, basically, actually, literally, just, simply

**Before**:
> "This approach can perhaps somewhat help you to basically achieve better results."

**After**:
> "This approach achieves better results."

**Editor question**: "Am I hedging because I'm uncertain or just being polite?"

---

### L - Lead with the Point
First sentence of every paragraph: the main point. Details follow.

**Before**:
> "When we look at the various factors that contribute to success, and we examine the research that has been conducted over the past decade, we find that one element stands above the rest: consistency."

**After**:
> "Consistency beats talent. Here's the research..."

**Editor question**: "What's my point? Say it first."

---

### E - Eliminate Empty Phrases
Delete phrases that add words but not meaning.

**Kill list**:
- "In order to" → "to"
- "Due to the fact that" → "because"
- "At this point in time" → "now"
- "In the event that" → "if"
- "With regard to" → "about"
- "It is important to note that" → [delete entirely]
- "As a matter of fact" → [delete entirely]
- "The thing is" → [delete entirely]

---

### S - Strengthen the Verbs
Replace weak verbs with strong ones. Eliminate passive voice.

**Weak**: is, are, was, were, have, had, make, do, get
**Strong**: [specific action verbs]

**Before**:
> "The team was able to make improvements to the process."

**After**:
> "The team improved the process."

**Editor question**: "What ACTION is happening? Use that word."

---

### S - Show, Don't Tell
Replace adjectives with evidence.

**Telling**: "The results were impressive."
**Showing**: "Revenue jumped 340% in 90 days."

**Telling**: "She was a great leader."
**Showing**: "Her team had the lowest turnover and highest output in the company."

**Editor question**: "How do I KNOW this? Show that instead."

---

## The Three-Pass Edit

### Pass 1: Structural Edit (Big Picture)
- Does every chapter earn its place?
- Is the sequence logical?
- Are there gaps in the argument?
- Does each chapter deliver on its promise?
- Is the framework consistent throughout?

### Pass 2: Line Edit (Sentence Level)
- Apply RUTHLESS framework to every paragraph
- Check sentence variety (length, structure)
- Verify every claim has support
- Ensure transitions flow

### Pass 3: Copy Edit (Word Level)
- Consistency: terms, capitalization, formatting
- Grammar and punctuation
- Fact-check statistics and quotes
- Verify names and attributions

---

## The 30% Rule

Your first draft is 30% too long. Plan to cut.

**What to cut**:
1. Entire sections that don't advance the core argument
2. Examples that duplicate other examples
3. Setup paragraphs that delay the point
4. Conclusions that repeat introductions
5. Anything you included "just in case"

**What to keep**:
1. Stories (if they're the best illustration)
2. Data (if it's surprising or essential)
3. Frameworks (your unique contribution)
4. Action steps (implementation is everything)

---

## Quality Gates

### Gate 1: The Scan Test
Print your chapter. Can a reader get the main points in 60 seconds by scanning bold text, headers, and callout boxes?

### Gate 2: The Stranger Test
Read your chapter aloud. Does it sound like you talking to a smart friend, or like a corporate document?

### Gate 3: The "So What?" Test
After every paragraph, ask: "So what?" If you can't answer, cut it.

### Gate 4: The Implementation Test
Read the action section. Could someone actually do this TODAY? If not, make it more specific.

### Gate 5: The ROI Test
Would readers pay $100 for this chapter alone? If not, it's not done.

---

## Common Manuscript Problems (and Fixes)

| Problem | Symptom | Fix |
|---------|---------|-----|
| Throat-clearing | Chapters start with background | Start with the insight |
| Professor mode | Too much theory, not enough action | Add 2x more examples |
| Burying the lead | Best content in middle/end | Move it to the front |
| Repetition creep | Same point, different words | Pick best version, delete rest |
| Hedge overload | Every claim is qualified | Make claims, then address objections |
| Missing stakes | Reader doesn't know why it matters | Add consequences of inaction |

---

## Final Checklist Before Submission

□ Every chapter passes the 5-Star Test
□ The visual framework is referenced throughout
□ Math/data supports every major claim
□ Each chapter has at least one memorable story
□ Action steps are specific and time-bound
□ No paragraph exceeds 4 sentences
□ No sentence exceeds 25 words (except rare emphasis)
□ Hedging language has been eliminated
□ Passive voice has been converted to active
□ The word count is within 10% of target

---

## The Editor's Mindset

"Your job is not to include everything you know. Your job is to include only what the reader NEEDS to achieve the transformation."

Every word costs the reader time and attention. Spend their currency wisely.
