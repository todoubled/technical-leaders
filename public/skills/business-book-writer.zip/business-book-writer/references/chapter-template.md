# Chapter Template

Detailed structure for writing high-impact chapters. Target: 12-15 pages per chapter.

---

## Complete Chapter Structure

### 1. CHAPTER TITLE
**Format**: Action verb + Outcome OR Bold claim
**Examples**:
- "Stop Managing Time—Start Managing Energy"
- "Fire Your Bottom 10% (And Why You're Afraid To)"
- "The 15-Minute Meeting That Replaces 10 Hours of Work"

---

### 2. OPENING HOOK (200-300 words / 1 page)

Start with ONE of these patterns:

**Pattern A: The Story Drop**
```
"Sarah stared at her screen. Eighteen hours. That's how long she'd worked 
yesterday, and somehow she was further behind than when she started..."
```

**Pattern B: The Shocking Statistic**
```
"87% of strategies fail. Not because they're bad strategies—because nobody 
actually implements them. Here's why, and exactly how to fix it."
```

**Pattern C: The Contrarian Claim**
```
"Everything you've been told about delegation is wrong. The goal isn't to 
offload tasks. It's to eliminate decisions."
```

**Pattern D: The Question**
```
"What would change if you could work half the hours and double your output? 
This isn't hypothetical. It's the result I've seen 137 times in 3 years."
```

---

### 3. THE INSIGHT (400-500 words / 2 pages)

Structure:
1. **The conventional wisdom** (what most people believe)
2. **Why it fails** (the hidden flaw)
3. **The counterintuitive truth** (your bold claim)
4. **Why this matters** (the stakes)

**Example**:
```
Most business owners think growth requires more: more people, more hours, 
more hustle. [conventional wisdom]

But here's what they miss: every addition creates complexity. Every hire 
requires management. Every new initiative fragments focus. [why it fails]

The breakthrough happens when you realize: constraint creates clarity. 
Limitations force innovation. Less IS more—when it's the right less. 
[counterintuitive truth]

Get this wrong, and you'll spend the next decade running faster on the 
same treadmill. Get it right, and you'll 10x your results while working 
half the hours. [stakes]
```

**Formatting**: Bold the key insight. Make it scannable.

---

### 4. THE MATH (300-400 words / 2 pages)

Prove your insight with numbers. Choose ONE approach:

**Approach A: The Calculation**
```
Let's do the math:

Current state:
• 10 clients × 10 hours each = 100 hours/month
• 100 hours × $150/hour = $15,000/month

With [YOUR PRINCIPLE]:
• 10 clients × 3 hours each = 30 hours/month  
• 30 hours × $500/hour = $15,000/month

Same revenue. 70 fewer hours. What would you do with 70 extra hours?
```

**Approach B: The Data Point**
```
We tracked this across 47 companies over 24 months:

│ Metric                │ Before │ After  │ Change  │
│───────────────────────│────────│────────│─────────│
│ Avg. decision time    │ 4.2 hrs│ 18 min │ -93%    │
│ Implementation rate   │ 23%    │ 89%    │ +287%   │
│ Team satisfaction     │ 3.1/10 │ 8.7/10 │ +180%   │
```

**Approach C: The Logic Chain**
```
If A leads to B, and B leads to C, then...

Clarity → Speed → Repetition → Mastery → Results

Each link has a multiplier effect. Miss one, break the chain.
```

---

### 5. THE PARABLE (600-800 words / 3 pages)

A complete story that makes the principle emotionally real.

**Structure**:
```
SETUP (150 words)
Who: Name, role, situation
What: The specific challenge they faced
Stakes: Why this mattered to them

STRUGGLE (200 words)
What they tried first (and why it failed)
The moment of frustration or desperation
The realization that something had to change

SOLUTION (150 words)
How they discovered/applied [YOUR PRINCIPLE]
The specific actions they took
The obstacles they overcame

SUCCESS (200 words)
The measurable result (be specific)
The unexpected benefits
How their life/business changed

LESSON (100 words)
The universal truth this illustrates
Why this matters to the reader
```

**Story Sources**:
- Client transformations (with permission)
- Your own journey
- Historical examples
- Composite characters (clearly labeled)

---

### 6. THE ACTION (500-600 words / 3 pages)

Step-by-step implementation. Be ruthlessly specific.

**Format**:
```
STEP 1: [ACTION VERB + SPECIFIC OUTCOME]
─────────────────────────────────────────
What to do: [Exact action in 1-2 sentences]

How to do it: 
1. [Sub-step with detail]
2. [Sub-step with detail]  
3. [Sub-step with detail]

Time required: [X minutes/hours]

Success indicator: [How they know it's done right]

Common mistake: [What to avoid]


STEP 2: [ACTION VERB + SPECIFIC OUTCOME]
─────────────────────────────────────────
[Same structure...]


STEP 3: [ACTION VERB + SPECIFIC OUTCOME]
─────────────────────────────────────────
[Same structure...]
```

**Rules**:
- Maximum 5 steps per chapter
- Each step must be completable in one sitting
- Include time estimates
- Warn about common mistakes

---

### 7. IMPLEMENTER'S NOTE (100-150 words / callout box)

Real-world wisdom that only comes from experience.

**Format**:
```
┌─────────────────────────────────────────────────────┐
│ 💡 IMPLEMENTER'S NOTE                              │
├─────────────────────────────────────────────────────┤
│ "When we rolled this out at Acme Corp, we learned  │
│ the hard way: don't skip the documentation step.   │
│ Yes, it feels tedious. But teams that documented   │
│ saw 3x better retention after 90 days.             │
│                                                     │
│ If you're tight on time, at minimum capture:       │
│ 1. What you decided                                │
│ 2. Why you decided it                              │
│ 3. What you'll measure                             │
│                                                     │
│ That's 5 minutes that saves 5 hours later."        │
└─────────────────────────────────────────────────────┘
```

---

### 8. CHAPTER CHECKLIST (half page)

**Format**:
```
CHAPTER X CHECKLIST
═══════════════════════════════════════════════════════

Before moving to the next chapter, confirm:

□ I understand [KEY CONCEPT] and can explain it
□ I have completed [STEP 1 ACTION]
□ I have completed [STEP 2 ACTION]  
□ I have completed [STEP 3 ACTION]
□ I have identified my biggest obstacle to implementation
□ I have scheduled time to review this in 7 days

Notes:
_________________________________________________
_________________________________________________
```

---

### 9. TRANSITION (100-150 words)

Bridge to the next chapter.

**Pattern**:
```
Now that you've [ACCOMPLISHED THING FROM THIS CHAPTER], you have the 
foundation for [TOPIC OF NEXT CHAPTER].

But here's the thing: [THIS CHAPTER'S PRINCIPLE] only works when combined 
with [NEXT CHAPTER'S PRINCIPLE]. Get one without the other, and you'll 
[SPECIFIC FAILURE MODE].

In the next chapter, you'll discover [TEASER OF KEY INSIGHT]. This is 
where [TRANSFORMATION ACCELERATES/COMPOUNDS/BECOMES REAL].
```

---

## Page Count Summary

| Section | Target Pages |
|---------|--------------|
| Title + Opening Hook | 1 |
| The Insight | 2 |
| The Math | 2 |
| The Parable | 3 |
| The Action | 3 |
| Implementer's Note | 0.5 |
| Checklist | 0.5 |
| Transition | 0.5 |
| **TOTAL** | **~12-13 pages** |

Buffer 2-3 pages for visual elements and white space.
