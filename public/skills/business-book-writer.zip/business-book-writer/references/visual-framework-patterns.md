# Visual Framework Patterns

Every breakthrough business book has ONE central visual that captures the entire system. This reference provides proven patterns.

## Pattern 1: The Wheel (3-7 Spokes)

**Best for**: Interconnected systems where all elements support each other

```
         [ELEMENT 1]
              │
    [6]───────●───────[2]
         ╱         ╲
      [5]           [3]
           ╲     ╱
            [4]
```

**Examples**:
- EOS Model (Traction): Vision, People, Data, Issues, Process, Traction
- Flywheel (Good to Great): Disciplined People → Thought → Action → Results

**When to use**: Your system has 4-6 components that reinforce each other cyclically.

---

## Pattern 2: The Equation (Hormozi Style)

**Best for**: Value propositions, ROI arguments, cause-effect relationships

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│   VALUE = (Dream Outcome × Likelihood of Success)  │
│           ─────────────────────────────────────    │
│            (Time Delay × Effort Required)          │
│                                                     │
└─────────────────────────────────────────────────────┘
```

**When to use**: You can express your core principle as a formula with 3-5 variables.

**Design tips**:
- Each variable should be independently controllable
- Use multiplication for synergistic elements
- Use division for friction elements
- Variable names should be intuitive

---

## Pattern 3: The Pyramid (Hierarchy)

**Best for**: Priority systems, foundations, levels of mastery

```
           /\
          /  \
         /TOP \
        /──────\
       / MIDDLE \
      /──────────\
     / FOUNDATION \
    ────────────────
```

**Examples**:
- Maslow's Hierarchy
- Priority Pyramid (Most Important → Least)

**When to use**: There's a clear order of operations or dependency chain.

---

## Pattern 4: The Matrix (2×2 Grid)

**Best for**: Decision frameworks, categorization, strategic positioning

```
              HIGH EFFORT
                  │
    ┌─────────────┼─────────────┐
    │             │             │
    │  DELEGATE   │   INVEST    │
LOW │             │             │ HIGH
VALUE─────────────┼─────────────RESULT
    │             │             │
    │  ELIMINATE  │  AUTOMATE   │
    │             │             │
    └─────────────┼─────────────┘
                  │
              LOW EFFORT
```

**When to use**: Two key variables determine optimal action.

---

## Pattern 5: The Sequence (Linear Flow)

**Best for**: Processes, journeys, step-by-step systems

```
[INPUT] → [STEP 1] → [STEP 2] → [STEP 3] → [OUTPUT]
              │          │          │
           Metric     Metric     Metric
```

**Examples**:
- Sales funnel stages
- Implementation roadmap

**When to use**: There's a clear A-to-B transformation with distinct phases.

---

## Pattern 6: The Stack (Building Blocks)

**Best for**: Compound systems, layered value, modular frameworks

```
┌─────────────────────────────┐
│         RESULTS             │  ← What you get
├─────────────────────────────┤
│         ACTIONS             │  ← What you do
├─────────────────────────────┤
│         BELIEFS             │  ← What you think
├─────────────────────────────┤
│        IDENTITY             │  ← Who you are
└─────────────────────────────┘
```

**When to use**: Each level builds upon and requires the previous.

---

## Pattern 7: The Contrast (Before/After)

**Best for**: Transformation narratives, problem-solution frameworks

```
┌──────────────────┐    ┌──────────────────┐
│     BEFORE       │    │      AFTER       │
│                  │    │                  │
│ • Overwhelmed    │ →  │ • Clear          │
│ • Reactive       │    │ • Proactive      │
│ • Scattered      │    │ • Focused        │
│ • Stuck          │    │ • Growing        │
└──────────────────┘    └──────────────────┘
        THE [YOUR SYSTEM NAME]
```

**When to use**: The transformation is the core message.

---

## Framework Design Checklist

□ **Memorable**: Can someone explain it to a friend?
□ **Visual**: Does it actually need to be seen to be understood?
□ **Complete**: Does it capture your ENTIRE system?
□ **Actionable**: Can readers use it to make decisions?
□ **Named**: Does your framework have a distinctive name?

## Naming Your Framework

Strong framework names are:
- **Acronyms**: SMART goals, SWOT analysis
- **Alliterative**: Profit First, Think and Grow Rich
- **Numbered**: The 4-Hour Workweek, 7 Habits
- **Metaphoric**: The Flywheel, The Dip

Weak names: "My approach," "The system," "The method"
