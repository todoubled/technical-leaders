---
name: business-book-writer
description: Write a high-impact business book (100 pages max) with world-class editor guidance. Combines the extreme practical value of Traction, visual illustration style of $100M Offers, and universal appeal of How to Win Friends. Use when someone wants to write a business book, create a book outline, develop book content, or needs book structure guidance.
---

# Business Book Writer

Create concise, high-impact business books that deliver extreme value in 100 pages or less.

## The Three Pillars

This skill synthesizes three best-seller DNA patterns:

| Pillar | Source | Core Principle |
|--------|--------|----------------|
| **EXTREME VALUE** | Traction | One system, fully executable, immediate ROI |
| **VISUAL CLARITY** | $100M Offers | Show the math, illustrate the concept, make it undeniable |
| **UNIVERSAL APPEAL** | How to Win Friends | Timeless principles, story-driven, psychologically grounded |

## Book Architecture (100 Pages Max)

```
STRUCTURE                          PAGES    PURPOSE
─────────────────────────────────────────────────────
Opening Hook                       2-3      Pattern interrupt + promise
The Core Problem                   5-8      Agitate with specificity
Your Central Framework             8-12     The "one thing" visual system
Chapter 1: First Principle         12-15    Foundation concept + stories
Chapter 2: Second Principle        12-15    Build on first + application
Chapter 3: Third Principle         12-15    Compound the system
Chapter 4: Fourth Principle        12-15    Advanced integration
Chapter 5: Fifth Principle         12-15    Mastery and edge cases
Implementation Playbook            8-10     Step-by-step deployment
Quick Reference                    3-5      One-page cheat sheets
Close                              2-3      Call to action + next steps
─────────────────────────────────────────────────────
TOTAL                              ~100 pages
```

## Core Process

### Phase 1: Define the Book DNA

Before writing, answer these questions:

1. **The Transformation**: What specific result does the reader achieve?
2. **The Enemy**: What single obstacle or myth are you defeating?
3. **The Vehicle**: What is your unique system/framework called?
4. **The Proof**: What results demonstrate this works?
5. **The Reader**: Who specifically needs this most?

### Phase 2: Create the Visual Framework

Every great business book has ONE visual that captures the entire system.

Examples:
- **Traction**: The EOS Model wheel (6 components)
- **$100M Offers**: The Value Equation (4 variables)
- **Good to Great**: The Flywheel

Create a 3-7 element visual framework. See `references/visual-framework-patterns.md`.

### Phase 3: Write to the Formula

For each chapter, follow the **IMPACT Structure**:

```
I - INSIGHT      (2 pages)   Bold claim that challenges conventional wisdom
M - MATH         (2 pages)   Numbers, data, or logic that prove the insight
P - PARABLE      (3 pages)   Story that makes it emotionally real
A - ACTION       (3 pages)   Exact steps to implement
C - CHECKLIST    (1 page)    Quick-reference implementation guide
T - TRANSITION   (1 page)    Bridge to next chapter
```

### Phase 4: Edit Like a World-Class Editor

Apply the **RUTHLESS Edit** framework. See `references/editor-checklist.md`.

Key principles:
- Cut 30% of your first draft
- Every sentence must earn its place
- If it doesn't move the reader forward, delete it
- Bold claims need proof; soft claims need cutting

## Writing Style Rules

### DO (Hormozi Clarity)
- Use short sentences. They hit harder.
- Bold the insight. Let readers scan.
- Show the math: "3 clients × $10K = $30K/month"
- Use tables and visual breakdowns
- Write like you're explaining to a smart friend

### DO (Carnegie Warmth)
- Lead with stories before principles
- Use "you" more than "I"
- Acknowledge the reader's intelligence
- Make them feel understood, not lectured

### DO (Wickman Practicality)
- Name everything (frameworks, processes, tools)
- Provide templates, not just theory
- Include "Implementer's Note" sidebars
- End chapters with specific next actions

### DON'T
- Use jargon without defining it
- Write paragraphs longer than 4 sentences
- Include theory without application
- Save the good stuff for later—lead with it

## Visual Element Guidelines

Include these visual elements throughout:

| Element | Frequency | Purpose |
|---------|-----------|---------|
| Framework Diagrams | 1 per chapter | Core concept visualization |
| Comparison Tables | 2-3 per chapter | Before/After, This vs That |
| Callout Boxes | 3-4 per chapter | Key insights, quotes, warnings |
| Checklists | 1 per chapter | Implementation tool |
| Math Examples | As needed | Prove the value numerically |

## Chapter Template

See `references/chapter-template.md` for the detailed chapter structure.

Quick format:
```
[CHAPTER TITLE: ACTION-ORIENTED]

[OPENING HOOK - 100 words]
Story or bold statement that creates tension

[THE INSIGHT - 400 words]
Your counterintuitive claim + why conventional wisdom fails

[THE MATH - 300 words]
Data, examples, or logical proof that makes it undeniable

[THE PARABLE - 600 words]
Full story that brings the principle to life
- Setup: Who, what situation
- Struggle: The problem they faced
- Solution: How they applied the principle
- Success: Specific measurable result

[THE ACTION - 500 words]
Step-by-step implementation
1. First action with explanation
2. Second action with explanation
3. Third action with explanation

[IMPLEMENTER'S NOTE BOX]
Real-world tips from practitioners

[CHAPTER CHECKLIST]
□ Action item 1
□ Action item 2
□ Action item 3

[TRANSITION TO NEXT CHAPTER]
One paragraph linking this principle to the next
```

## Quality Standards

Before finalizing, verify each chapter passes the **5-Star Test**:

★ **Valuable**: Reader could pay $1,000 for this information alone
★ **Visual**: Core concept is illustrated, not just described
★ **Visceral**: Contains a story that creates emotional connection
★ **Verified**: Claims backed by data, results, or logic
★ **Velocitized**: Reader can implement within 48 hours

## Reference Files

- `references/visual-framework-patterns.md` - Visual system templates
- `references/chapter-template.md` - Detailed chapter structure
- `references/editor-checklist.md` - World-class editing framework
- `references/opening-hooks.md` - Proven book opening patterns

## Deliverables Workflow

1. **Book DNA Statement** (1 page)
2. **Visual Framework Design** (1 page)
3. **Chapter Outline** (2-3 pages)
4. **Sample Chapter** (10-12 pages)
5. **Full Draft** (100 pages)
6. **Edited Final** (refined to page targets)

Start with Book DNA, get approval, then proceed sequentially.
