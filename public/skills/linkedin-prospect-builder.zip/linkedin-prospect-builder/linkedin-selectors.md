# LinkedIn Browser Automation Reference

Selectors and navigation patterns for LinkedIn and Sales Navigator prospect extraction.

## URLs

| Page | URL |
|------|-----|
| LinkedIn Home | `https://www.linkedin.com/feed/` |
| People Search | `https://www.linkedin.com/search/results/people/` |
| People Search with Query | `https://www.linkedin.com/search/results/people/?keywords=[ENCODED_QUERY]` |
| Sales Navigator Home | `https://www.linkedin.com/sales/home` |
| Sales Nav Lead Search | `https://www.linkedin.com/sales/search/people` |
| Sales Nav Account Search | `https://www.linkedin.com/sales/search/company` |

## LinkedIn Basic Search

### Search Box
- Find: `search box`, `search`, `keywords`
- Enter boolean query directly

### Filter Panel Elements
- Connection degree: `Connections` filter → `2nd`, `3rd`
- Location: `Locations` filter → type city/region
- Industry: `Industry` filter → multi-select
- Current company: `Current company` filter

### Search Result Cards
Each result contains:
- Profile image
- Name (link to profile)
- Headline text
- Location
- Current position
- Mutual connections ("X mutual connections")

### Pagination
- "Next" button at bottom of results
- URL parameter: `&page=2`, `&page=3`, etc.
- Max 100 pages (1000 results) on Basic

## Sales Navigator Lead Search

### Filter Panel Sections

**Lead Filters (left panel):**
- Keywords
- Current Job Title (multi-select, type to search)
- Past Job Title
- Seniority Level (checkboxes)
- Function (checkboxes)
- Years in Current Position
- Years at Current Company

**Personal Filters:**
- Geography (type to search)
- Industry (multi-select)
- Years of Experience
- Groups
- School

**Account Filters (expandable):**
- Company Headcount (checkboxes: 1-10, 11-50, 51-200, etc.)
- Company Type (Public, Private, etc.)
- Headquarters Location
- Industry

**Spotlight Filters (checkboxes):**
- Changed jobs in past 90 days
- Posted on LinkedIn in past 30 days
- Mentioned in news in past 30 days
- Share experiences with you
- Following your company
- Viewed your profile

### Result Card Data Points

| Field | Location |
|-------|----------|
| Name | Primary heading |
| Title | Below name |
| Company | Company link |
| Location | Geographic indicator |
| Profile URL | Name link href |
| Spotlight badges | Icons/labels near name |
| Connection path | "Via [connection name]" |
| Shared connections | "X shared connections" |

### Save Lead Button
Each result has "Save" button to add to lead list.

### Export Limitations
- Sales Nav doesn't allow bulk export
- Must extract data via browser automation
- Rate limit: ~100 profile views/day

## Data Extraction Patterns

### From LinkedIn Basic

```javascript
// Conceptual - use read_page to get these elements
{
  name: "h3.entity-result__title",
  headline: "div.entity-result__primary-subtitle",
  location: "div.entity-result__secondary-subtitle", 
  profileUrl: "a.entity-result__title-text",
  mutualConnections: "span.entity-result__simple-insight"
}
```

### From Sales Navigator

```javascript
// Conceptual - use read_page to get these elements
{
  name: "dt[data-anonymize='person-name']",
  title: "span[data-anonymize='title']",
  company: "a[data-anonymize='company-name']",
  location: "span.t-black--light",
  spotlightBadge: "span.spotlight-badge"
}
```

## Rate Limit Best Practices

| Action | Recommended Delay |
|--------|-------------------|
| Page navigation | 2-3 seconds |
| Search execution | 3-5 seconds |
| Profile extraction | 1 second |
| Between search sessions | 5 minutes |
| Daily limit | ~100 profile views |

## Login Detection

Check for login state:
- LinkedIn: Look for profile image in nav, "Sign In" button absence
- Sales Nav: Check for "Sales Navigator" logo, dashboard presence

## CAPTCHA Handling

If encountered:
1. Stop automation immediately
2. Take screenshot
3. Alert user to solve manually
4. Wait for user confirmation
5. Resume from last position

## Boolean Query Encoding

URL encode special characters:
- Space → `%20` or `+`
- Quotes → `%22`
- AND → stays as `AND`
- OR → stays as `OR`
- Parentheses → `%28` and `%29`

Example:
```
("VP Engineering" OR "Head of Engineering") AND SaaS
→
%28%22VP%20Engineering%22%20OR%20%22Head%20of%20Engineering%22%29%20AND%20SaaS
```
