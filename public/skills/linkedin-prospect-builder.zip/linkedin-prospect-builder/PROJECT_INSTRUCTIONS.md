# Project Instructions: LinkedIn Prospect Research

These instructions guide Claude Cowork in executing end-to-end prospect research from ICP files.

## Project Purpose

Transform Ideal Client Profile documents into a qualified prospect list ready for outreach, using automated LinkedIn and Sales Navigator searches.

## Required Skills

This project leverages:
1. **linkedin-prospect-builder** - Core skill for browser automation and prospect extraction
2. **icp-cloner** - Source of ICP files with search parameters
3. **xlsx** - Spreadsheet creation with proper formatting
4. **dm-coach** - (Post-workflow) For crafting outreach to prospects

## Execution Flow

### Phase 1: Setup & Validation

1. **Scan for ICP files**
   - Look for `icp-*.md` files in current directory
   - If none found, ask user to provide ICP files or run icp-cloner first
   - List found ICPs for user confirmation

2. **Verify browser state**
   - Check for active browser session
   - Confirm LinkedIn login status
   - Confirm Sales Navigator access (if available)

3. **Confirm parameters**
   - Show user the search queries extracted from each ICP
   - Confirm target prospect count (default: 100)
   - Confirm output filename

### Phase 2: LinkedIn Basic Search

For each ICP file:
1. Navigate to LinkedIn people search
2. Enter the boolean query from ICP
3. Apply filters: 2nd degree connections, location, industry
4. Extract up to 25 results per ICP
5. Capture: name, headline, company, location, profile URL, mutual connections

### Phase 3: Sales Navigator Search (if available)

For each ICP file:
1. Navigate to Sales Nav lead search
2. Apply lead filters from ICP: titles, seniority, function, geography
3. Apply account filters: company size, company type
4. Enable spotlight filters: recent job change, recent posts
5. Extract up to 50 results per ICP
6. Capture all basic fields plus spotlight signals

### Phase 4: Data Processing

1. **Combine results** from all searches
2. **Deduplicate** by profile URL
3. **Filter out**:
   - 1st degree connections (already connected)
   - Incomplete profiles (missing name/company)
   - Duplicates from user's existing contact lists (if provided)
4. **Limit to target count** (100), prioritizing:
   - Spotlight signals (job change, recent activity)
   - Higher mutual connection count
   - Better ICP match

### Phase 5: Spreadsheet Creation

1. Create Excel workbook using xlsx skill patterns
2. Add prospect data with all columns from template
3. Apply formatting: headers, hyperlinks, alternating rows
4. Add data validation for status tracking
5. Freeze header row, enable auto-filter
6. Save with dated filename: `prospects-YYYY-MM-DD.xlsx`

### Phase 6: Delivery

1. Copy spreadsheet to outputs directory
2. Present file to user
3. Provide summary statistics:
   - Total prospects found
   - Breakdown by source (LinkedIn vs Sales Nav)
   - Breakdown by ICP archetype
   - Top signals identified
4. Offer next steps: dm-coach for outreach templates

## Automation Guidelines

### Rate Limiting
- 2-3 second delay between page loads
- 1 second between profile extractions
- 5 minute pause if rate limit detected
- Max 100 profile views per session

### Error Recovery
- If CAPTCHA: pause, screenshot, wait for user
- If session expires: stop, ask user to re-authenticate
- If Sales Nav unavailable: continue with Basic only
- If search returns 0 results: try broader criteria

### Data Quality
- Require: name, headline, company for every prospect
- Prefer: 2nd degree connections (warm intro potential)
- Capture all available signals for personalization

## User Interactions

**Ask before:**
- Starting searches (confirm ICPs and target count)
- Proceeding after rate limit pause
- Overwriting existing prospect file

**Inform during:**
- Progress through each ICP search
- Results count after each search
- Any errors or limitations encountered

**Report after:**
- Total prospects collected
- Deduplication and filtering results
- File saved location
- Suggested next actions

## Example Session

```
User: Build a prospect list from my ICP files

Claude: I found 2 ICP files in your directory:
- icp-vp-engineering.md (VP/Head of Engineering at SaaS companies)
- icp-director-product.md (Director of Product at growth-stage startups)

I'll search both LinkedIn and Sales Navigator for each profile and create a spreadsheet of 100 qualified prospects.

Ready to proceed? [Yes/Adjust parameters]

---

[After execution]

✅ Prospect research complete!

Summary:
- LinkedIn Basic: 47 results
- Sales Navigator: 83 results  
- After deduplication: 112 unique
- Final qualified list: 100 prospects

Breakdown by ICP:
- VP Engineering: 58 prospects
- Director Product: 42 prospects

Top signals found:
- 23 changed jobs in past 90 days
- 31 posted on LinkedIn recently
- Avg 4.2 mutual connections

📊 File saved: prospects-2025-01-22.xlsx

Would you like me to help craft outreach messages using the dm-coach skill?
```

## File Locations

| File | Purpose |
|------|---------|
| `icp-*.md` | Input ICP files (from icp-cloner) |
| `prospects-YYYY-MM-DD.xlsx` | Output prospect spreadsheet |
| `references/linkedin-selectors.md` | Browser automation patterns |
| `references/spreadsheet-template.md` | Excel formatting specs |
