# Prospect Spreadsheet Template

Standard output format for linkedin-prospect-builder skill.

## Column Definitions

| Col | Header | Width | Format | Description |
|-----|--------|-------|--------|-------------|
| A | Name | 25 | Text | Full name of prospect |
| B | Headline | 40 | Text | LinkedIn headline |
| C | Company | 25 | Text | Current company |
| D | Title | 25 | Text | Extracted job title |
| E | Location | 20 | Text | City, State/Country |
| F | Profile URL | 15 | Hyperlink | LinkedIn profile link |
| G | Source | 12 | Text | "LinkedIn" or "Sales Nav" |
| H | ICP Match | 20 | Text | Archetype from ICP file |
| I | Connection | 12 | Text | 2nd, 3rd, Out of Network |
| J | Mutual | 10 | Number | Shared connections count |
| K | Signals | 30 | Text | Spotlight badges, comma-sep |
| L | Status | 15 | Dropdown | Outreach tracking |
| M | Notes | 40 | Text | Personalization notes |

## Status Dropdown Values

- (blank) - Not started
- Requested - Connection sent
- Connected - Connection accepted
- Messaged - DM sent
- Replied - Got response
- Qualified - Ready for call
- Declined - Not interested
- Not a Fit - Disqualified

## Formatting Specifications

### Header Row (Row 1)
```python
from openpyxl.styles import Font, PatternFill, Alignment

header_font = Font(bold=True, color='FFFFFF')
header_fill = PatternFill('solid', fgColor='1F4E79')
header_alignment = Alignment(horizontal='center', vertical='center')
```

### Data Rows
```python
# Alternating row colors
light_fill = PatternFill('solid', fgColor='F2F2F2')
white_fill = PatternFill('solid', fgColor='FFFFFF')

# URL column - hyperlink style
url_font = Font(color='0563C1', underline='single')
```

### Column Widths (in characters)
```python
column_widths = {
    'A': 25, 'B': 40, 'C': 25, 'D': 25, 'E': 20,
    'F': 15, 'G': 12, 'H': 20, 'I': 12, 'J': 10,
    'K': 30, 'L': 15, 'M': 40
}
```

## Sample Creation Code

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

def create_prospect_spreadsheet(prospects, filename):
    wb = Workbook()
    ws = wb.active
    ws.title = "Prospects"
    
    # Headers
    headers = ['Name', 'Headline', 'Company', 'Title', 'Location', 
               'Profile URL', 'Source', 'ICP Match', 'Connection',
               'Mutual', 'Signals', 'Status', 'Notes']
    
    header_font = Font(bold=True, color='FFFFFF')
    header_fill = PatternFill('solid', fgColor='1F4E79')
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    # Data rows
    for row_num, prospect in enumerate(prospects, 2):
        ws.cell(row=row_num, column=1, value=prospect['name'])
        ws.cell(row=row_num, column=2, value=prospect['headline'])
        ws.cell(row=row_num, column=3, value=prospect['company'])
        ws.cell(row=row_num, column=4, value=prospect['title'])
        ws.cell(row=row_num, column=5, value=prospect['location'])
        
        # Hyperlink for profile URL
        url_cell = ws.cell(row=row_num, column=6, value=prospect['profile_url'])
        url_cell.hyperlink = prospect['profile_url']
        url_cell.font = Font(color='0563C1', underline='single')
        
        ws.cell(row=row_num, column=7, value=prospect['source'])
        ws.cell(row=row_num, column=8, value=prospect['icp_match'])
        ws.cell(row=row_num, column=9, value=prospect['connection'])
        ws.cell(row=row_num, column=10, value=prospect['mutual'])
        ws.cell(row=row_num, column=11, value=prospect['signals'])
        # Status and Notes left blank
        
        # Alternating row colors
        if row_num % 2 == 0:
            for col in range(1, 14):
                ws.cell(row=row_num, column=col).fill = PatternFill('solid', fgColor='F2F2F2')
    
    # Column widths
    widths = [25, 40, 25, 25, 20, 15, 12, 20, 12, 10, 30, 15, 40]
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    
    # Freeze header row
    ws.freeze_panes = 'A2'
    
    # Auto-filter
    ws.auto_filter.ref = f"A1:M{len(prospects) + 1}"
    
    wb.save(filename)
    return filename
```

## Data Validation for Status Column

```python
from openpyxl.worksheet.datavalidation import DataValidation

# Add dropdown to Status column (L)
status_options = '"(blank),Requested,Connected,Messaged,Replied,Qualified,Declined,Not a Fit"'
dv = DataValidation(type='list', formula1=status_options, allow_blank=True)
dv.error = 'Select a valid status'
dv.errorTitle = 'Invalid Status'

# Apply to column L, rows 2 onwards
ws.add_data_validation(dv)
dv.add(f'L2:L{len(prospects) + 1}')
```

## Summary Sheet (Optional)

Add a second sheet with summary stats:

| Metric | Formula |
|--------|---------|
| Total Prospects | `=COUNTA(Prospects!A:A)-1` |
| From LinkedIn | `=COUNTIF(Prospects!G:G,"LinkedIn")` |
| From Sales Nav | `=COUNTIF(Prospects!G:G,"Sales Nav")` |
| 2nd Degree | `=COUNTIF(Prospects!I:I,"2nd")` |
| Requested | `=COUNTIF(Prospects!L:L,"Requested")` |
| Connected | `=COUNTIF(Prospects!L:L,"Connected")` |
| Reply Rate | `=COUNTIF(Prospects!L:L,"Replied")/COUNTIF(Prospects!L:L,"Messaged")` |
