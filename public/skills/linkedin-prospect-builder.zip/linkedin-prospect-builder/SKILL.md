---
name: linkedin-prospect-builder
description: Build a prospect list from ICP files using LinkedIn and Sales Navigator. Use when the user has ICP files (from icp-cloner skill) and wants to find prospects matching those profiles. Triggers include "build prospect list", "find prospects from ICP", "search LinkedIn for prospects", "create prospect spreadsheet", "run LinkedIn search from ICP", or any request to turn ICP search parameters into an actual prospect list. Requires browser automation and outputs an Excel spreadsheet.
---

# LinkedIn Prospect Builder

Transform ICP documents into actionable prospect lists by executing searches on LinkedIn and Sales Navigator, then compiling results into a structured spreadsheet **with clickable LinkedIn profile URLs**.

## Prerequisites

- ICP files in current directory (output from `icp-cloner` skill)
- Active LinkedIn session in browser
- Sales Navigator subscription (for Sales Nav searches)
- Browser automation capabilities (Claude in Chrome)

## Workflow

### Step 1: Load and Parse ICP Files

Scan current directory for ICP files matching pattern `icp-*.md`:

```bash
ls -la *.md | grep -i icp
```

For each ICP file, extract:
- **LinkedIn Basic Search**: Boolean query from "Recommended Search Query" section
- **Sales Navigator Filters**: Lead filters table values
- **Spotlight Filters**: High-intent signal checkboxes
- **Archetype Name**: For organizing results

### Step 2: Initialize Browser Session

1. Use `Claude in Chrome:tabs_context_mcp` to get browser context
2. Create new tab with `Claude in Chrome:tabs_create_mcp`
3. Navigate to `https://www.linkedin.com` - verify logged in
4. Navigate to `https://www.linkedin.com/sales/home` - verify Sales Navigator access

If not logged in, stop and inform user to authenticate manually.

### Step 3: Execute LinkedIn Basic Search

For each ICP file:

1. Navigate to LinkedIn search: `https://www.linkedin.com/search/results/people/`
2. Apply filters from ICP:
   - Enter boolean query in search box
   - Set connection degree filter to "2nd" (warm intros)
   - Apply location filter
   - Apply industry filter
3. Take screenshot to verify results
4. Extract up to 25 profiles per ICP:
   - Name
   - Headline
   - Current company
   - Location
   - Profile URL (directly available from search results)
   - Connection degree
   - Mutual connections count

### Step 4: Execute Sales Navigator Search

For each ICP file:

1. Navigate to Sales Navigator lead search: `https://www.linkedin.com/sales/search/people`
2. Apply Lead Filters from ICP:
   - Current Job Title (multi-select)
   - Seniority Level
   - Function
   - Geography
   - Industry
3. Apply Account Filters:
   - Company Headcount
   - Company Type
4. Apply Spotlight Filters (high-intent signals):
   - Changed jobs in past 90 days ✓
   - Posted on LinkedIn in past 30 days ✓
5. Take screenshot to verify results
6. Extract up to 50 profiles per ICP:
   - All Basic Search fields plus:
   - Shared connections
   - Spotlight badges (job change, recent post)
   - Account name and size

### Step 5: Extract LinkedIn Profile URLs (CRITICAL)

**⚠️ IMPORTANT: Sales Navigator does NOT directly expose LinkedIn.com profile URLs.**

Sales Navigator uses internal member IDs in URLs like:
```
/sales/lead/ACwAAAAqJ-0BO6JlVc_f5YEQqGQKXd89Wmhplj0,NAME_SEARCH,...
```

**You MUST resolve these to actual LinkedIn profile URLs using this process:**

#### 5.1: Extract Member IDs from Sales Navigator

Use JavaScript to extract member IDs from the search results page:

```javascript
var profileLinks = document.querySelectorAll('a[href*="/sales/lead/"]');
var prospects = [];
var seen = {};
profileLinks.forEach(function(link) {
    var href = link.href;
    var name = link.innerText.trim();
    if (name && name.length > 2 && href.includes('/sales/lead/ACw')) {
        var match = href.match(/ACw[A-Za-z0-9_-]+/);
        if (match && !seen[match[0]]) {
            seen[match[0]] = true;
            prospects.push({name: name, memberId: match[0]});
        }
    }
});
JSON.stringify(prospects);
```

**Note**: Scroll through results to load more prospects before extracting.

#### 5.2: Resolve Member IDs to Vanity URLs

For EACH extracted member ID, resolve the actual LinkedIn profile URL:

1. Navigate to: `https://www.linkedin.com/in/[memberID]`
   - Example: `https://www.linkedin.com/in/ACwAAAAqJ-0BO6JlVc_f5YEQqGQKXd89Wmhplj0`

2. LinkedIn will redirect to the actual vanity URL
   - Example redirect: `https://www.linkedin.com/in/michaeljboardman/`

3. Capture the final URL using:
   ```javascript
   window.location.href
   ```

4. Store this as the prospect's LinkedIn Profile URL

**Batch Processing Pattern:**
```
For each prospect:
  1. Navigate to linkedin.com/in/[memberID]
  2. Wait for redirect
  3. Extract final URL from window.location.href
  4. Store URL with prospect data
  5. Continue to next prospect
```

**Example Member ID Resolution:**

| Name | Member ID | Resolved URL |
|------|-----------|--------------|
| Mike Boardman | ACwAAAAqJ-0BO6JlVc_f5YEQqGQKXd89Wmhplj0 | linkedin.com/in/michaeljboardman/ |
| David B. | ACwAAAAlDbkBu_dnqiXgrRMl7gErhc2XhaKKM18 | linkedin.com/in/davidbeckmba/ |
| Rachel Sapers | ACwAAAIAIKUBYx1sIm5_21-hcaPUtcX53cLY7Hk | linkedin.com/in/rachel-sapers/ |

### Step 6: Deduplicate and Qualify

Remove duplicates by Profile URL across all searches.

Qualification criteria:
- Not already connected (1st degree)
- Not already in saved leads
- Has complete profile (name + headline + company)
- **Has resolved LinkedIn profile URL**

Target: 100 unique, qualified prospects.

### Step 7: Create Spreadsheet

Use **xlsx skill** patterns to create prospect spreadsheet.

**Spreadsheet Structure:**

| Column | Description | Required |
|--------|-------------|----------|
| A: Name | Full name | ✓ |
| B: Title | Current job title | ✓ |
| C: Company | Current company | ✓ |
| D: Location | Geographic location | ✓ |
| E: Time in Role | Duration at current position | |
| F: Signal | Spotlight badge (Recently hired, etc.) | |
| G: Mutual Connections | Count of shared connections | |
| H: LinkedIn Activity | Recent posts indicator | |
| I: Priority | P1/P2/P3 based on signals | ✓ |
| J: Connection Status | Not Connected/Pending/Connected | |
| K: Outreach Status | Blank (for tracking) | |
| **L: LinkedIn URL** | **Full profile URL (linkedin.com/in/...)** | **✓ CRITICAL** |
| M: Notes | Blank (for personalization) | |

**Formatting:**
- Header row: Bold, frozen, colored background
- **LinkedIn URL column: Hyperlinks with blue underlined text**
- Priority column: Conditional formatting (P1=green, P2=yellow, P3=red)
- Signal column: Light green fill for "Recently hired"
- Alternating row colors for readability
- Auto-filter enabled

**LinkedIn URL Column Requirements:**
- Must contain full URL: `https://www.linkedin.com/in/username/`
- Must be clickable hyperlink
- Must be the RESOLVED vanity URL, NOT the Sales Navigator member ID
- Style as blue, underlined text

### Step 8: Save and Present

Save as: `prospects-[YYYY-MM-DD].xlsx`

Copy to outputs directory and present to user.

## Browser Automation Patterns

### Reading Search Results

Use `Claude in Chrome:read_page` with filter "interactive" to find result cards.

### Pagination

LinkedIn and Sales Nav show ~25 results per page. Use "Next" button to paginate:
```
Claude in Chrome:find query="next page button"
Claude in Chrome:computer action="left_click" ref="[button_ref]"
```

### Extracting Profile Data

For each result card:
1. `find` the card element
2. `read_page` with ref_id to get card contents
3. Parse structured data from accessibility tree

### Member ID URL Resolution Pattern

```
# For each member ID:
Claude in Chrome:navigate url="https://www.linkedin.com/in/[memberID]"
# Wait for redirect
Claude in Chrome:javascript_tool action="javascript_exec" text="window.location.href"
# Capture returned URL as the LinkedIn Profile URL
```

### Rate Limiting

- Wait 2-3 seconds between page navigations
- Wait 1-2 seconds between URL resolutions (to avoid rate limiting)
- If CAPTCHA detected, pause and alert user

## Error Handling

| Error | Response |
|-------|----------|
| Not logged in | Stop, request user to log in manually |
| Sales Nav unavailable | Run LinkedIn Basic only, note limitation |
| CAPTCHA | Pause, screenshot, request user intervention |
| Empty results | Broaden search criteria, try title variations |
| Rate limited | Wait 5 minutes, then resume |
| URL resolution fails | Retry once, then skip prospect with warning |

## Output Example

```
✓ Loaded 2 ICP files: icp-vp-engineering.md, icp-director-product.md
✓ Sales Navigator Search: 83 results across ICPs
✓ Extracted member IDs for 50 prospects
✓ Resolving LinkedIn profile URLs...
  - Resolved 50/50 URLs
✓ After deduplication: 47 unique profiles
✓ After qualification: 45 prospects ready for outreach
✓ Saved: prospects-2025-01-22.xlsx

Spreadsheet includes:
- All prospect details
- ✓ Clickable LinkedIn profile URLs
- Priority rankings (P1/P2/P3)
```

## Quality Checklist

Before delivering the spreadsheet, verify:

- [ ] Every prospect row has a LinkedIn URL in column L
- [ ] LinkedIn URLs are full vanity URLs (linkedin.com/in/username/)
- [ ] LinkedIn URLs are NOT Sales Navigator member IDs
- [ ] URLs are formatted as clickable hyperlinks
- [ ] URLs open to the correct profile when clicked

**⚠️ A spreadsheet without proper LinkedIn URLs is not usable for outreach.**

## Related Skills

- **icp-cloner**: Creates the ICP files this skill consumes
- **dm-coach**: Use for crafting outreach to prospects in this list
- **xlsx**: Spreadsheet creation patterns
