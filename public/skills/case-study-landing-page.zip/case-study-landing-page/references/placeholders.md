# Template Placeholder Reference

Complete reference for all `{{PLACEHOLDER}}` variables in `assets/template.html`.

## Brand & Meta

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{BRAND_NAME}}` | Your company name | Tech Leaders |
| `{{LOGO_ICON}}` | Emoji or text for logo | TL |
| `{{PAGE_TITLE}}` | Browser tab title | Healthcare AI Case Study |
| `{{META_DESCRIPTION}}` | SEO description (150 chars) | How a $75M health tech company became AI-first in just weeks |
| `{{YEAR}}` | Copyright year | 2025 |
| `{{CTA_URL}}` | Booking/contact link | https://calendly.com/yourlink |
| `{{NAV_CTA_TEXT}}` | Navigation button text | Get the AI Prompt Library |

## Hero Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{REVENUE_SCALE}}` | Company size marker | $75M |
| `{{COMPANY_TYPE}}` | Industry descriptor | Health Tech Company |
| `{{HEADLINE_RESULT}}` | Primary achievement | Became AI-First |
| `{{ACCENT_TEXT}}` | Highlighted phrase (teal) | in Just Weeks |
| `{{SUBHEADLINE}}` | One-line summary | From fragmented understanding to unified AI adoption |

## Challenge Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{CHALLENGE_HEADLINE}}` | Problem-focused hook | A Fast-Scaling Company at a Critical Crossroads |
| `{{CHALLENGE_DESCRIPTION}}` | Problem narrative (2-3 sentences) | A fast-scaling health tech company with **$75M in revenue** needed to rapidly build AI literacy... |
| `{{SYMPTOM_1}}` - `{{SYMPTOM_4}}` | Pain indicators | Siloed understanding of AI's capabilities |
| `{{MISSION_STATEMENT}}` | The goal, use **bold** for key numbers | Transform **30 key team members** into an AI-literate, aligned cohort, **fast.** |

## Solution Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{SOLUTION_HEADLINE}}` | Solution summary | A Private, Custom-Built AI Adoption Program |
| `{{SOLUTION_DESCRIPTION}}` | Brief approach description | We delivered a private, custom-built program designed for this company's unique needs |
| `{{SOLUTION_1_TITLE}}` | Feature 1 name | Executive Alignment |
| `{{SOLUTION_1_DESC}}` | Feature 1 description | Align managers through ELT on AI fundamentals |
| `{{SOLUTION_2_TITLE}}` - `{{SOLUTION_4_DESC}}` | Remaining 3 features | (same pattern) |
| `{{SOLUTION_RESULT}}` | Result tagline | One organization. One language. One mission. |

## Deliverables Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{DELIVERED_HEADLINE}}` | Section headline | Practical AI Implementation Across Every Function |
| `{{DELIVERED_DESCRIPTION}}` | Section intro | Beyond training, we delivered hands-on systems... |

### Deliverable Card 1 (Feature Grid)

| Placeholder | Example |
|-------------|---------|
| `{{DELIVERABLE_1_ICON}}` | 🔧 |
| `{{DELIVERABLE_1_TITLE}}` | Custom AI Workflows for Every Department |
| `{{DELIVERABLE_1_DESC}}` | We designed and implemented AI workflows tailored to... |
| `{{DELIVERABLE_1_FEATURE_1}}` - `{{DELIVERABLE_1_FEATURE_6}}` | Lead scoring, content generation, campaign optimization |

### Deliverable Card 2 (Checklist)

| Placeholder | Example |
|-------------|---------|
| `{{DELIVERABLE_2_ICON}}` | 📖 |
| `{{DELIVERABLE_2_TITLE}}` | AI-First Playbook |
| `{{DELIVERABLE_2_DESC}}` | A comprehensive, company-specific playbook... |
| `{{DELIVERABLE_2_ITEM_1}}` - `{{DELIVERABLE_2_ITEM_6}}` | AI usage policies and governance framework |

### Deliverable Card 3 (Feature Grid)

| Placeholder | Example |
|-------------|---------|
| `{{DELIVERABLE_3_ICON}}` | 🎧 |
| `{{DELIVERABLE_3_TITLE}}` | Ongoing Office Hours Support |
| `{{DELIVERABLE_3_DESC}}` | Continuous access to AI experts... |
| `{{DELIVERABLE_3_FEATURE_1}}` - `{{DELIVERABLE_3_FEATURE_4}}` | Weekly live sessions |

## Outcomes Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{OUTCOMES_HEADLINE}}` | Results headline | Measurable Results, Fast |
| `{{OUTCOME_1_ICON}}` | Emoji for stat 1 | 👥 |
| `{{OUTCOME_1_STAT}}` | Metric 1 value | 30 |
| `{{OUTCOME_1_DESC}}` | Metric 1 description | Leaders AI-aligned, from execs to analysts |
| `{{OUTCOME_2_ICON}}` - `{{OUTCOME_4_DESC}}` | Remaining metrics | (same pattern) |

**Icon color mapping:**
- Card 1: Green (default)
- Card 2: Blue (`blue` class)
- Card 3: Purple (`purple` class)
- Card 4: Orange (`orange` class)

## CTA Section

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{CTA_HEADLINE}}` | Question format | Ready to Equip Your Leaders With Real AI Literacy? |
| `{{CTA_DESCRIPTION}}` | Urgency statement | Whether you're at $10M or $100M+, if you're not moving fast... |
| `{{CTA_BUTTON_TEXT}}` | Button label | Book a Strategy Call |

## Footer

| Placeholder | Example |
|-------------|---------|
| `{{FOOTER_COL_1_TITLE}}` | Compare |
| `{{FOOTER_LINK_1_TEXT}}` | Tech Leaders vs. MBA Program |
| `{{FOOTER_LINK_1_URL}}` | /compare/mba |
| `{{FOOTER_COL_2_TITLE}}` | How We Help |
| `{{FOOTER_LINK_3_TEXT}}` | AI-First Training |
| `{{FOOTER_LINK_3_URL}}` | /training |

## HTML Formatting Tips

Use `<strong>` or `**markdown**` in description placeholders for emphasis:
- `A company with <strong>$75M in revenue</strong>` renders bold
- Numbers and key phrases benefit from emphasis

Use `<br>` in headlines for line breaks if needed.
