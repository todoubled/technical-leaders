---
name: case-study-landing-page
description: Transform transcripts, notes, or raw content into high-conversion case study landing pages. Use when user asks to "create a case study", "build a success story page", "make a case study landing page", "turn this into a case study", or provides client success content. Outputs a production-ready HTML landing page with the "Frustration → Fix → Future" narrative framework optimized for lead generation.
---

# Case Study Landing Page Creator

Transform raw content into conversion-focused case study landing pages using the "Frustration → Fix → Future" narrative framework.

## Workflow

1. **Extract** key details from transcript/content
2. **Enhance** vague claims into concrete, quantified statements  
3. **Structure** using the six-section framework below
4. **Generate** production-ready HTML using `assets/template.html`

## Six-Section Page Structure

### 1. HERO
- Badge: "CASE STUDY"
- Headline: "How [Company/Type] [Achieved Result] in [Timeframe]" — key phrase in accent color
- Subheadline: Single-line transformation summary

### 2. THE CHALLENGE (Frustration)
- **Person**: Role, organization type, credibility markers (industry, revenue, scale)
- **Problem**: Core issue articulated for target audience
- **Symptoms**: 4 pain indicators in card format
- **Mission**: Specific goal they needed to achieve

### 3. THE SOLUTION (Fix - Approach)
- Headline: Solution summary
- Description: Framework/methodology applied
- **4 feature cards** (2x2): Key solution components

### 4. WHAT WE DELIVERED (Fix - Implementation)
- **2-3 deliverable cards** each with:
  - Icon, title, description
  - 4-6 sub-features as bullets or mini-cards

### 5. THE OUTCOMES (Results)
- **4 metrics cards** (2x2):
  - Large stat + description
  - Mix quantitative (numbers, %) and qualitative wins

### 6. YOUR TURN (CTA)
- Headline: Question addressing reader's similar need
- Description: Urgency statement
- CTA button: "Book a Strategy Call" or similar

## Enhancement Rules

**Strengthen claims:**
- Soft verbs ("improved") → action verbs ("accelerated", "eliminated")
- Passive → active voice
- "It worked well" → "cut turnaround time by 40%"

**Quantify:**
- Extract metrics; if unclear, use "about", "roughly", "estimated"
- Include: time saved, costs reduced, revenue gained, team size, efficiency %

**Authenticity:**
- Never fabricate; use direct quotes for credibility
- If unquantifiable, emphasize qualitative impact

## Generate Output

Copy `assets/template.html` to working directory, then replace placeholders:

| Placeholder | Content |
|-------------|---------|
| `{{BRAND_NAME}}` | Your company/brand name |
| `{{COMPANY_TYPE}}` | Client industry descriptor |
| `{{REVENUE_SCALE}}` | Size marker (e.g., "$75M", "Series B") |
| `{{HEADLINE_RESULT}}` | Primary transformation achieved |
| `{{ACCENT_TEXT}}` | Highlighted phrase (in teal) |
| `{{SUBHEADLINE}}` | One-line summary |
| `{{CTA_URL}}` | Calendar/contact link |

Then populate each section's content following the HTML structure.

**Design specs (already in template):**
- Dark hero (#0f172a) with subtle gradient
- Alternating light/dark sections
- Feature cards: dark backgrounds (#1e293b)
- Accent: teal (#10b981)
- Typography: Sora (headlines), Inter (body)
- Responsive, mobile-first
- Smooth animations on scroll/hover
