---
name: wedge-roadmap
description: Create a roadmap of features prioritized by what will be most impactful and monetizable
---

Read research.md and ultrathink about creating a competitive product by using the Jobs To Be Done product framework. Prioritize a list of potential wedge features that should be used to go-to-market and scale most effectively into a new file called roadmap.md
