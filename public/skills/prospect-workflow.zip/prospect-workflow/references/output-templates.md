# Output Templates

## connection-invitations.md Format

```markdown
# Connection Invitations
Generated: [DATE]
Source ICPs: [LIST]

## [ICP Archetype Name]

**Profile Pattern:** [Brief description of target]

### Invitation Templates

**Template 1: Mutual Interest**
> [300 char max invitation text]

*Use when:* [Context]
*Trust signal:* [What builds G1]

**Template 2: Shared Context**
> [300 char max invitation text]

*Use when:* [Context]
*Trust signal:* [What builds G1]

**Template 3: Curiosity Hook**
> [300 char max invitation text]

*Use when:* [Context]
*Trust signal:* [What builds G1]

---

## Personalization Variables

Replace brackets when sending:
- [Company] - Prospect's current company
- [Role detail] - Specific from their headline
- [Mutual connection] - Shared connection name
- [Specific thing] - Content they posted or detail from profile
```

---

## conversation-starters.md Format

```markdown
# Conversation Starters
Generated: [DATE]
Prospects: [COUNT]

## Priority 1: Hot Leads

### [Prospect Name] - [Company]
**Signals:** [Job change, recent post, etc.]
**Profile notes:** [Relevant details for personalization]

**Starter A:**
> [Message text]

**Starter B:**
> [Message text]

**Coach note:** Gate G2, focus on [specific relevance hook]

---

### [Next Prospect]
...

## Priority 2: Warm Leads
[Same structure]

## Priority 3: Cool Leads
[Same structure]
```

---

## content-batch.md Format

```markdown
# Content Batch
Generated: [DATE]
Target ICP: [Archetype name]
Topic/Source: [User input or transcript summary]

## Magic Model

**PROBLEM:** [Core pain point]
**SOLUTION:** [Your approach]
**STEPS:** 
1. [Step 1]
2. [Step 2]
3. [Step 3]

---

## Post 1: Philosophy Angle

**IDEA:** [What this post is about]
**HOOK:** [Opening line]
**STACK (Story):**
[3-5 bullet narrative arc]
**PAYOFF:** [Key takeaway]
**INVITATION:** Follow for more [topic]

### Full Post Text
[Complete post ready to copy]

---

## Post 2: Problem Angle
[Same structure, List format]

## Post 3: Proof Angle
[Same structure, Story format]

## Post 4: Plan Angle
[Same structure, Steps format]

## Post 5: Prize Angle
[Same structure, micro magnet offer]

---

## Video Scripts

### Script 1: [Corresponds to Post 1]
**Format:** [Talking head / Walk and talk / etc.]
**Duration:** 60 seconds

**INTRO (0-7 sec):**
[Pattern interrupt + promise]

**BODY (8-45 sec):**
[Main content matching post Stack]

**PAYOFF (46-55 sec):**
[Land the insight]

**INVITATION (56-60 sec):**
[CTA/CTE]

[Repeat for Scripts 2-5]
```
