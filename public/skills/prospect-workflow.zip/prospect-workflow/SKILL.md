---
name: prospect-workflow
description: Unified ICP-to-outreach workflow with three commands. Use when user says "find icp" to discover and build prospect lists from ICP files with connection invitation messages. Use when user says "start conversations" to prioritize connected prospects and craft trust-building conversation starters. Use when user says "create content" to generate ICP-targeted social posts from ideas or transcripts. Triggers include "/find icp", "/start conversations", "/create content", "prospect workflow", "icp outreach", "content for my ICP", or any request combining prospect research with outreach messaging.
---

# Prospect Workflow

Three-command system for ICP-driven prospect engagement: find → connect → attract.

## Commands Overview

| Command | Purpose | Dependencies |
|---------|---------|--------------|
| `find icp` | Build prospect list + connection invitations | linkedin-prospect-builder, dm-coach |
| `start conversations` | Prioritize leads + craft openers | dm-coach, xlsx |
| `create content` | Generate ICP-targeted posts | content-creator, ICP files |

---

## Command 1: `find icp`

Build a prospect list from ICP files and generate trust-building connection invitations.

### Inputs Required

1. ICP files (`icp-*.md`) in working directory
2. Active LinkedIn/Sales Navigator browser session
3. Target prospect count (default: 100)

### Execution Flow

**Phase 1: Prospect Discovery**

Run linkedin-prospect-builder workflow:
1. Parse ICP files for search parameters
2. Execute LinkedIn Basic Search (2nd-degree connections)
3. Execute Sales Navigator Search (with spotlight filters)
4. Deduplicate and qualify results
5. Output: `prospects-YYYY-MM-DD.xlsx`

**Phase 2: Connection Invitation Drafting**

For each ICP archetype, use dm-coach principles to create G1-level invitations:

```
ICP Analysis → Trust Gate Mapping → Invitation Templates
```

Connection invitation constraints:
- 300 character LinkedIn limit
- Must establish G1: Credibility
- Pattern-breaking opener (no "I'd love to connect")
- One clear tribe signal (G2 seed)
- Zero pitch language

**Invitation Formula:**

```
[Pattern break] + [Shared context/signal] + [Soft curiosity hook]
```

**Example Outputs:**

```
ICP: VP Engineering at SaaS
---
Invitation A:
"Your engineering org's growth at [Company] caught my attention. Building 
technical teams at scale is genuinely hard. Would enjoy comparing notes."

Invitation B:
"Saw you're hiring senior engineers - we're solving similar talent 
challenges. Your approach to [specific thing from profile] stood out."

Invitation C:
"[Mutual connection] and I were discussing eng leadership at growth-stage 
companies - your name came up. Curious to connect."
```

### Deliverables

1. `prospects-YYYY-MM-DD.xlsx` - Full prospect spreadsheet
2. `connection-invitations.md` - 3-5 invitation templates per ICP archetype

### Summary Output

```
✅ find icp complete

Prospects Found:
- LinkedIn Basic: [X] results
- Sales Navigator: [Y] results
- Deduplicated: [Z] unique prospects

Connection Invitations Generated:
- [ICP-1 name]: 5 templates (G1 openers)
- [ICP-2 name]: 5 templates (G1 openers)

Files:
📊 prospects-2025-01-22.xlsx
📝 connection-invitations.md

Next: Send connection requests, then run "start conversations" 
when prospects accept.
```

---

## Command 2: `start conversations`

Prioritize accepted connections and craft trust-building conversation starters.

### Inputs Required

1. Prospect spreadsheet from `find icp` command
2. Optional: Updated connection status in spreadsheet
3. Optional: Specific prospect names to prioritize

### Execution Flow

**Phase 1: Prioritization**

Rank connected prospects by signal strength:

| Priority | Signals |
|----------|---------|
| P1: Hot | Changed jobs (90 days), posted recently, 3+ mutual connections |
| P2: Warm | One spotlight signal OR 2+ mutual connections |
| P3: Cool | 2nd degree, no recent activity |

Filter spreadsheet to show:
- Connected prospects only (update Outreach Status column)
- Sorted by priority tier
- Top 10-20 for immediate outreach

**Phase 2: Conversation Starter Drafting**

Use dm-coach framework for post-connection G2 openers:

Gate Position: G1 passed (connected) → Target G2: Relevance

Conversation starter constraints:
- Acknowledge the connection naturally
- Mirror their world (from profile/activity)
- One curiosity question
- Zero pitch, zero ask

**Starter Formula:**

```
[Connection acknowledgment] + [Specific observation] + [Open question]
```

**Personalization Sources:**

Extract from prospect profile for message personalization:
- Recent posts/activity → Comment on specific content
- Headline → Reference their domain
- Company news → Acknowledge momentum
- Mutual connections → Shared context

**Example Outputs:**

```
Prospect: Sarah Chen, VP Engineering at TechCorp
Priority: P1 (job change + recent post)
---
Starter A:
"Appreciate the connect, Sarah. Your post on managing technical debt 
resonated - we're wrestling with similar tradeoffs. What's driven your 
prioritization framework?"

Starter B:
"Thanks for connecting. Noticed you're building out the platform team 
at TechCorp - curious how you're thinking about the first few hires?"

Starter C:
"Good to connect. [Mutual connection] mentioned you've cracked some 
interesting scaling challenges. What's been the hardest part?"
```

### Deliverables

1. Updated spreadsheet with priority rankings
2. `conversation-starters.md` - Personalized openers per prospect

### Summary Output

```
✅ start conversations complete

Prospect Prioritization:
- P1 (Hot): [X] prospects
- P2 (Warm): [Y] prospects  
- P3 (Cool): [Z] prospects

Conversation Starters Generated:
- [X] personalized messages ready
- Focus: Top 10 P1 prospects

Files:
📝 conversation-starters.md

Coach Note:
Gate: G2 (Relevance)
ΔTrust: Positive if genuine curiosity
Avoid: Pitching, asking for calls, generic templates
```

---

## Command 3: `create content`

Generate ICP-targeted social content from ideas or transcripts.

### Inputs Required

1. ICP files (`icp-*.md`) in working directory - for audience targeting
2. One of:
   - Content idea/topic from user
   - Transcript (audio/video content)
   - Article or raw notes
3. Optional: Platform preference (LinkedIn, Twitter/X, Instagram)

### Execution Flow

**Phase 1: ICP Context Extraction**

From ICP files, extract:
- Pain points and frustrations
- Goals and aspirations
- Language patterns (how they describe problems)
- Buying triggers
- Industry context

**Phase 2: Magic Model Alignment**

If user has no Magic Model, generate one from context:

```
PROBLEM: [Core pain point from ICP]
SOLUTION: [User's approach/methodology]
STEPS: [3-step transformation framework]
```

**Phase 3: Content Generation**

Use content-creator Lego Framework:

```
HOOK (Head) + STACK (Body) + PAYOFF (Hands) + INVITATION (Feet)
```

Generate 5 posts rotating angles:
1. **Philosophy** - Contrarian belief that resonates with ICP
2. **Problem** - Agitate specific ICP pain point
3. **Proof** - Transformation story (user's or client's)
4. **Plan** - 3-step framework teach
5. **Prize** - Micro magnet offer

**ICP-Specific Adaptations:**

| ICP Attribute | Content Adaptation |
|---------------|-------------------|
| Pain points | Hook + Problem angle focus |
| Industry | Specific examples, jargon |
| Seniority | Depth of content, strategic vs tactical |
| Goals | Payoff framing |

**Example Output:**

```
ICP: VP Engineering at growth-stage SaaS
Topic: Engineering team scaling
---
POST 1 (Philosophy):
HOOK: Most engineering leaders scale wrong.
STACK: They hire for skills when they should hire for culture fit first...
[Story format]
PAYOFF: Culture scales. Skills can be taught.
INVITATION: Follow for more on building engineering teams.

POST 2 (Problem):
HOOK: 3 signs your engineering org is about to break:
STACK: 
- Cycle times creeping up
- Senior engineers spending 60%+ time in meetings
- New hires taking 90+ days to first meaningful commit
PAYOFF: You don't have a talent problem. You have a system problem.
INVITATION: Comment 🔥 if any of these hit home.
```

### Deliverables

1. `content-batch.md` - 5 social posts + 5 video scripts
2. Platform-specific versions if requested

### Summary Output

```
✅ create content complete

ICP Targeting:
- Primary: [ICP archetype name]
- Pain points addressed: [X]
- Language calibrated to: [Seniority level]

Content Generated:
- 5 social posts (Philosophy, Problem, Proof, Plan, Prize)
- 5 video scripts (60-sec format)
- Estimated read time: [X] min total

Files:
📝 content-batch.md

Suggested posting rhythm:
- Monday: Philosophy post
- Wednesday: Plan post (teaching)
- Friday: Prize post (lead magnet)
```

---

## Cross-Command Integration

Commands work together in a flywheel:

```
find icp          → prospects list
    ↓
start conversations → warm relationships
    ↓
create content    → attract inbound + nurture
    ↓
(repeat)
```

**Optimal Workflow:**

1. Run `find icp` weekly to build pipeline
2. Run `start conversations` 2-3x/week as connections accept
3. Run `create content` daily to attract inbound and stay top-of-mind

---

## Quick Reference

| User Says | Command | Action |
|-----------|---------|--------|
| "find icp" | find icp | Build prospects + connection invites |
| "start conversations" | start conversations | Prioritize leads + craft openers |
| "create content" | create content | Generate ICP-targeted posts |
| "prospect workflow" | Show this overview | Display command options |

## Dependencies

- `linkedin-prospect-builder` - Browser automation for LinkedIn/Sales Nav
- `dm-coach` - Trust Physics messaging framework
- `content-creator` - Lego Framework content generation
- `icp-cloner` - ICP file format source
- `xlsx` - Spreadsheet creation
