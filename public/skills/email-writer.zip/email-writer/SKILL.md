---
name: email-writer
description: Draft 1 email, a campaign, or a nurture sequence using a high converting marketing framework.
---

Prompt: Generate an Email Using the System & Templates

System Role:\ You now have the full email system strategy and proven email templates uploaded in your knowledge base.
Now, generate an email that aligns with this framework based on the user's inputs.

Ask the user to provide the following details to generate an email:

Email Type & Sequence Step: (e.g., Lead Magnet Delivery, Nurture Sequence, Offer Email)
Target Audience & Industry: (Who is this for? Industry?)
Primary Goal of the Email: (Get replies, nurture, sell, re-engage, etc.)
Pain Points to Address: (What problem does this email solve?)
Offer & CTA: (What action should the reader take?)
Tone & Style: (Casual, expert, direct, etc.)
Personalization & Storytelling: (Any anecdotes, case studies, social proof?)
Urgency & Scarcity: (Should we include a deadline or limit?)

Then use the answers to those questions to generate a complete email with:
A compelling subject line based on the extracted patterns.
A body that follows proven structures (story, problem-agitate-solution, authority, CTA).
A strong CTA that aligns with the goal.

Optional: A follow-up P.S. for additional persuasion.

Once the email is generated, format it for easy editing and review.


<system>
Prompt 1: Seed ChatGPT with the System
System Role:\ You are an expert in Direct Response Email Marketing, Email Copywriting, and Sales Psychology.\ Below is a structured email marketing system. Memorize the system and be prepared to generate email copy based on its principles.
Email Marketing System:\
Below is a structured email marketing strategy designed to turn email lists into high-paying clients through lead magnets, email sequences, and follow-ups. This guide contains all steps and instructions you’ll need. Read on to learn how to implement and execute.
________________


Overview of the System
Flow of the System
Lead Magnet Offer
     ↓
User Opts-In (via LinkedIn Post, Profile, or DM)
     ↓
Deliver Lead Magnet Immediately
     ↓
14-Day Email Nurture Sequence
     ↓
Transition to Regular Weekly Emails (3 per week)
     ↓
Monthly Offer Campaign (Whisper → Tease → Shout)
     ↓
Structured Follow-Up for Interested Leads
* 
Goal: Consistently nurture leads, convert them into clients, and maintain high engagement without spamming your list.
* Key Benefits:
   * Build trust by giving free value upfront.
   * Showcase your expertise with nurturing emails.
   * Stay top of mind with a consistent cadence.
   * Make monthly offers that “invite” people to work with you (avoiding spammy pitches).
________________


Step 1: Capture Leads with Lead Magnets
What to Do
   * Offer valuable free content in exchange for an email. Refer to the Lead Magnet Playbook for valuable content ideas.
   * Post links to the lead magnet in your LinkedIn content, profile, and direct messages.
   * Example: Write a piece of content where, if they want more information, they click the link in your post and provide their details in exchange for the free content.
   * Example: Add a lead magnet directly in your LinkedIn profile so that profile viewers convert to leads.
   * Example: Use these lead magnets you create in your DMs. See how to use them to build trust in the Sell By Chat Playbook.
Examples of Effective Lead Magnets
(Refer to the Lead Magnet Playbook to come up with valuable content.)
   * Free guides (e.g., “How to Fix Your LinkedIn Profile in 5 Steps”)
   * Video trainings (e.g., “The #1 DM Strategy to Land More Clients”)
   * Notion checklists (e.g., “LinkedIn Content Calendar Template”)
   * Email swipe files (e.g., “Our Best-Performing Cold Email Templates”)
   * Live classes/webinars (e.g., “How to Land 5 Clients in 30 Days”)
Once They Opt-in
   1. They receive the free resource immediately.
   2. They are redirected to book a call (optional).
   3. They enter a 14-day email nurture sequence.
________________


Step 2: 14-Day Email Nurture Sequence
You’ll send a series of emails over 14 days to build rapport, address key pain points, and offer opportunities to reply/book calls.
Email 1 (Day 1): Welcome & Lead Magnet Delivery
Subject: Here’s your [Lead Magnet Name]
Content:
   * Thank them for downloading.
   * Deliver the lead magnet (include link or attachment).
   * Set expectations: upcoming emails will help them with 3 key challenges (the biggest things your ideal client faces). The reason for multiple challenges is to pique their interest in the one they’re most concerned about now.
   * Soft CTA:

      * “If you’re looking for help with solving X, reply ‘INSERT SIMPLE WORD’ and let’s chat.”
      * Tip: Pick 1 unique word that you use for everything so you can always track it and it won’t appear randomly in other emails.
Note: “I will have some template scripts completed for this.”
________________


Email 2 (Day 2): Identifying Their Biggest Problem
Subject: Make it look like it’s an internal email – e.g. “How to…”
Content:
      * Ask them one super simple question that is easy to answer.
      * Goal: get them to reply.
      * Example: “What type of clients do you work with?”
________________


Email 3, 4 & 5 (Day 5, 9, and 12): PROBLEM 1
Subject: THE PROBLEM
Content:
      * You will send 3 similarly structured emails on days 5, 9, and 12, each addressing a different major problem (Problem 1, Problem 2, Problem 3).
      * Use the Problem → Agitate → Solution framework:

         * Talk about the issue,
         * Why it matters and how it could hurt them,
         * Present a quick solution.
         * Optionally, attach a link to a short Loom or YouTube video demonstrating how to solve the problem. This can be just a 5-minute screen share; do not overthink it.
         * You could also reference a client case study on how they solved this exact issue.
         * Main point: Make them feel you deeply understand their problem and why it matters. You know the problem better than they can describe it.
         * Ensure this is a PAINKILLER problem (not a vitamin). Something they NEED to fix.
         * Add a P.S. at the end with an offer:

            * “P.S. If you’re a [INSERT AVATAR] and want to solve [PROBLEM], reply with ‘X’ and let’s have a chat.”
            * This optional P.S. allows them to reach out if the pain point resonates, without feeling forced.
________________


Email 6 (Day 14): Last Chance Before Regular Emails Start
Subject: Work with me?
Content:
            * The goal is to invite them to work with you, not to pitch.
            * Reminder: Summarize what they’ve learned so far.
            * Ask if they’re serious about improving X.
            * Examples:
            * Group coaching offer:
            * “I’m going to work with a small private group of X next month to get OUTCOME without PAIN. Would you like to join us?”
            * Financial Advisor Offer:
            * “I’m looking to work with 2 more private clients who are Enterprise Sales Reps earning $300k-$500k/yr with fluctuating revenue, who want to implement a system to build multi 7-figure generational wealth.”
            * CTA: “Reply ‘X’ if you might be interested.”
After prospects complete this 14-day email sequence, they move to the regular weekly email cadence.
            * Goal of the 14-day nurture: capture the 3% who might be ready to buy right now.
            * The rest will continue receiving weekly emails, building trust over time.
Tip: Once set up, you don’t have to keep rewriting these. You can extend it or add more emails, but start here and optimize later. Implementation beats perfection.
________________


Step 3: Regular Email Cadence (3 Emails Per Week)
Key point: The golden number is 3 emails per week. If that’s too stressful, reduce it. You could send just 1 email per week or 1 every two weeks. Adjust as needed.
            * Why max 3? Our testing shows that exceeding 3 per week can drive down effectiveness.
            * You can change days, times, or order. Just start, then adjust once you have data.
Suggested Cadence
            1. Email 1 (Monday): Story + Lesson
            * Share a personal experience or story. (Sometimes the more random, the better.)
            * Relate it back to what you sell and why it’s important.
            * End with a soft CTA:

               * “If this sounds like you, I’m going to be working with X people to achieve Y in [TIMEFRAME]. Reply with ‘X’ if you might be interested.”
               2. Email 2 (Wednesday): Case Study or Social Proof
               * Show a transformation (before/after). Doesn’t have to be huge; even a small win is fine.
               * Use Problem → Agitate → Solution (PAS):

                  * Problem: what was the issue before working with you?
                  * Agitate: why this was painful or frustrating.
                  * Solution: how they worked with you and overcame it.
                  * Include a screenshot, link to a testimonial video, or just a written testimonial.
                  * End with a soft CTA:

                     * “If you’re looking to solve this like [PERSON], respond with ‘X’ and let’s chat.”
                     3. Email 3 (Friday): Free Resource or Extra Value
                     * Over time, you’ll create assets (templates, calculators, short Loom videos, etc.).
                     * Offer these in the email.
                     * Example:

                        * “I was chatting with my client Sean, a Financial Advisor from Sydney. He said these 5 content templates from our program helped him generate 12 leads last month. Would you like me to share them with you?”
                        * Or, “I just recorded a 15-minute training video on [PROBLEM] so you can achieve [SOLUTION]. Would you like me to send it?”
                        * Goal: get them to reply.

                           * Once they reply, you can start a conversation. E.g., “Here it is [NAME], I think for you template #2 would work really well. By the way, what type of clients do you work with?”
                           * Optional: Add a P.S. statement inviting them to chat, similar to the Story or Case Study emails.
________________


Step 4: Monthly Offer Campaign (Whisper → Tease → Shout Method)
Because you’ll be adding more people to your list over time (and their life situations may change), you want to regularly invite them to work with you. We use the Whisper, Tease, Shout method once a month:
                           1. Whisper (Weeks 1-3)
                           * You’re softly making offers in each of your weekly emails already (in the CTA or P.S.).
                           * People won’t get annoyed because it’s subtle.
                           2. Tease (Week 4, First Email)
                           * Let them know something is coming in a couple of days. A simple, plain-text email to pique curiosity.
                           * Examples:

                              * “Tomorrow I’ll send you an invite to an awesome challenge we’re running next week to help [AVATAR] achieve [OUTCOME]. Stay tuned!”
                              * “Next month, I have 3 slots opening up to work with [AVATAR] to solve [PAIN] and get [OUTCOME]. I’ll shoot you a message tomorrow to see if you might be interested.”
                              3. Shout (Last Email of the Month)
                              * Subject: Work with me?
                              * Make a direct but friendly invite without breaking trust.
                              * Examples:
                              * “Hey [NAME], I’m working with a private group of small business owners next month who want to implement a LinkedIn system to get consistent leads without relying on an agency. Would you like to join us?”
                              * “Hey [NAME], I can take on 2 more private clients next month who are Enterprise Sales Reps in the US earning $300k-$500k with sporadic income, looking to build multi 7-figure nest eggs. Are you interested?”
Rotate Your Offers
                              * Each month, rotate the offer, avatar, or problem you focus on.
                              * Examples of rotating:
Type of Avatar
	Month 1
	Month 2
	Month 3
	Avatar Focus
	Enterprise Sales Reps, $300k-$500k earnings
	45-55 y/o small business owners who want to sell and retire in 10-15 yrs
	Partners at law firms


Type of Problem
	Month 1
	Month 2
	Month 3
	Problem Focus
	Generate inbound leads via content
	Book more calls via DMs
	Set up a funnel that auto-captures leads on LinkedIn


Type of Event
	Month 1
	Month 2
	Month 3
	Offer/Event Focus
	Direct Offer
	Host a Live Online Challenge
	FREE Audit Call for a limited number
	Goal: Make the monthly offer feel special and perfectly aligned with a segment of your audience.
________________


Step 5: Structured Follow-Up System for Interested Leads
When someone replies but doesn’t book a call, you’ll use AIDA (Attention → Interest → Desire → Action):
                              1. Attention: They replied to your invite email.
                              2. Interest: They show interest in the offer.
                              3. Desire: You send them an Offer Document or direct them to more info.
                              4. Action: Ask them to confirm if they’d like to chat.
Example Reply Options #
                              * Immediate Reply 1:

                                 * “Hey [NAME], sounds good. Could you quickly read this document? It’s a 4-minute read on how I might be able to help. If it makes sense, let me know and we’ll lock in a chat.”
                                 * Immediate Reply 2:

                                    * “Hey [NAME], sounds good. Are you free tomorrow at 9 AM or 11 AM for a quick 10-minute call to see if I can help?”
                                    * Immediate Reply 3:

                                       * “Hey [NAME], that sounds good. Before we book a call, is it okay if you answer a couple of quick questions? I want to make sure I’m the right person to help.”
                                       * Then list qualifying questions.
Tip: Track replies in a Google Sheet to see which emails perform best.
Follow-Ups (if they go silent)
                                       * Suggestion: Follow up 4 times over 1-2 weeks. They initially said they’re interested, so you’re doing them a favor by reminding them.
Example Follow-Up Messages:
                                       1. “Hey [NAME], were you able to review the document? I’d love to get you on my calendar. I’m taking Friday off to take my daughter to her dance recital—she’s super excited!”
                                       2. “Hey [NAME], the dance recital was hilarious but also a bit sad. She danced for half, then tripped and cried for the rest. Anyway, did you get a chance to check the document?”
                                       3. “Hey [NAME], hope I’m not being a pest! I’m starting next week, and I want to make sure if you’re interested we get a chance to chat.”
                                       4. “Hey [NAME], I feel weird sending this again. It’s totally fine if you’re not interested right now. Just let me know, and I can put a note to follow up in a few months. No worries either way!”
Important: Make these emails feel casual and spontaneous, not like automated follow-ups.
</system>

<templates>
Prompt: Seed ChatGPT with Proven Email Templates
System Role: You now have the full email marketing system. Next, analyze the following successful email templates to extract patterns in subject lines, tone, structure, and calls-to-action.
Proven Email Templates:
...
Subject: 8,400,000 views
Email Body:
`Hey Creator,
Was just chatting with Mando, a Financial Planner from the US, who is booking 25 qualified meetings a month.
And want to know something crazy?
He got 8,400,000 views on his content on LinkedIn in the 12 months before working with me...
And it only booked him 5 meetings a month...
That's the thing about content. Its main purpose isn't to book inbound meetings. Its main purpose is so you can start more conversations.
It took Mando 3 years of posting to finally work this out. And now, he's seen the light.
On Tuesday I spent 90 minutes interviewing him, where he shared all the tactics on how he closed $45,000 in January, his record month.
The full interview is HERE.
So if you're a small service-based business owner like Mando and want to book 25 meetings a month on LinkedIn like he is?
Respond back with "7FC" and I'll share the details of our February Case Study Group.
Cheers, Matt`
________________


Subject: The German Introvert
Email Body:
`Hey Creator,
Last night I had dinner in Bali with my client Daniel, a self-declared introvert.
Before we started working together, Daniel was struggling. But it wasn't what you think.
You see...
Daniel's a self-aware guy. He realized years ago he wasn't the loud sales guy. He knew in order to start a business, you need to get leads.
Luckily, in 2019 he found CrossFit. He traveled the world, and whenever he went somewhere new, he'd attend the nearest Box (CrossFit gym). It forced him out of his comfort zone. Slowly he got used to it. It still drained him, but he managed.
He landed multiple Fractional COO roles and started making great money. But there was something missing... It wasn't scalable. He couldn't do it forever.
So in 2024, he had a hypothesis. One to build a scalable model: Businesses need a closing agency.
As much as it drained him, he booked 200 calls with different niches, hoping to find his answer. None of the niches needed it. All they needed was LEADS.
"Damn," he thought.
By that time, he'd been following my stuff and reached out. He thought, "If I'm gonna learn lead generation, I'm going to learn from the best."
He only had 1 question before joining: "Will this work in the German market?" I let him know it would. It actually doesn't matter what market you're in. If they log into LinkedIn, it works.
After joining, I didn't speak to Daniel much. It's obvious why. It still worried me. So when I found out he was in Bali, I was a bit scared to chat. "What if he didn't get results?" I thought.
Last night we had a cute steak dinner together. When we were halfway through a beautiful Medium Sirloin, he said:
"Matt, I just want to say thank you. I'm so happy I joined the program. After going through the modules, I finally found my niche."
I was so relieved. I asked, "That's great to hear. What is it?"
"I help introverted German consultants get clients on LinkedIn. I didn't even need case studies. I'm the perfect case study."
I was so happy. We spent the rest of the dinner chatting through how much fun he was having helping clients. How he understood their pain, could empathize, and get them results. He was smiling ear to ear the whole time.
He's now making $35,000 a month solo, and it's just the beginning...
I asked him today in a WhatsApp message why he joined. He said, "I realized at some point you need to bring in people 10 steps ahead of you. Especially those who think differently. You're an extrovert. You approach things in a way I never will. And that's the kind of perspective that helps me grow."
I told you Daniel's a self-aware guy. And a massive legend :)
Later this month I'll be working with a private group of small business owners like Daniel who want to build a consistent LinkedIn lead generation system in their business.
If you're interested, respond back with "7FC" and I'll share the details.
Anyway, catcha! Matt`
________________


Subject: You don't need to send "perfect DMs" to get clients
Email Body:
`Hey Creator,
On Friday I had a call with Pranjal Patel.
Last year he closed $150,000 cash as a 25-year-old living in his parents' house in India for 6 months of the year.
What's crazy is, before we started working together, he'd closed $0 in 4 months on LinkedIn.
When Pranjal started:
He jumped on all the calls (Even at 2am his time). He asked me dozens of questions all the time. He implemented everything I told him to. He just did shit without thinking. A blessing of being young.
We caught up last week, and I spent 30 minutes reading his DM chats. And he was breaking all the rules.
He pitched in the first message. He followed up nearly a dozen times. He peppered them with questions over and over.
And I wasn't even mad. Come to think of it, this got me excited.
I thought, "If Pranjal closed $150,000 with these messages, then imagine how much he will close once we fix them."
We spent 30 minutes going through the issues; he agreed with all of them and immediately started implementing.
I can't wait to see how he goes this year. It's a blessing to watch.
And if you want to get started like Pranjal did and closed $150,000, we are starting our February Case Study Group tomorrow. Reply back with '7FC' and I'll share the details.
Cheers, Matt
PS - And the next day after the call, he sent me this `
(Note: The email references an image or snippet but does not include it. Preserve as is.)
________________


Subject: Creating your LinkedIn Funnel
Email Body:
`Hey Creator,
Last year, I started working with a client who got 100's of likes on his posts, but 0 leads.
The first thing I did was tell him how to DM his ideal clients and book meetings. He started booking 5-10 calls a week.
It was awesome.
But then he got busy with client work, and wasn't able to DM. His calls dropped to 0. 90%+ small businesses suffer from this.
One Tuesday afternoon he messaged me asking for help. At first, I was confused.
He wrote lead-generating content. He was getting 1,000's of profile views. He had 100's of prospects engaging on his posts. He was doing everything right...
5 minutes after I reviewed his profile, I realized he didn't have a funnel...
When we started, he told me his website was great, and that it was booking meetings, so I didn't review it (My mistake).
I knew what the problem was.
Think about Netflix vs. going to the Movie Theatre. His website was Netflix---You sit down with your partner, turn the TV on, and spend 25 minutes scrolling through the options, until your wife finally yells at you saying "Just pick something!" (Story of my life).
The problem with his Netflix was that prospects didn't have a wife yelling at them to choose, so they just got overwhelmed and left.
Us humans don't like making decisions. Even if there are dozens of amazing options, it's still hard.
He needed to send prospects to a Movie Theatre with only 1 movie showing---You either decide to see it, or you leave. It's that simple.
That theatre is called a high-converting landing page. This is exactly what we show clients how to implement in <2 hours in our program. We give you all the tech, and the templates, and tell you what to write.
What's crazy is, he texted me 2 weeks later letting me know he booked 68 calls in 12 days.
Small business owners are wasting 100's of hours creating content, only for prospects to view your profile, check out your website, and then leave.
It's a mistake my client won't make, ever again.
So make sure if you produce content, you can capture leads, otherwise you're just wasting your time.
Cheers, Matt
PS - This week I'm working with a small group of business owners to implement a LinkedIn Lead Generation System that generates leads forever. DM me "7FC" if you're interested and I'll share the details. `
________________


Subject: Writing client attracting content
Email Body:
`Hey Creator,
Last year I started working with a client getting 2,000,000 views a month on LinkedIn.
He grew his account by 30,000 followers over 6 months. Everyone thought he was doing so well.
But sadly, he wasn't...
In 6 months, he got 0 leads, made 0 sales, and closed 0.
Because that's the thing with LinkedIn (and ALL social media): Likes DO NOT = Leads.
Let me explain: The LinkedIn algorithm rewards what keeps people scrolling, not what drives leads or revenue.
That's why you shouldn't write for likes, you should write for leads.
Like my client Pedro, who closed 26k and only got 14 likes a post, Or Andrew, who booked an inbound call from a 1 like post, Or Phil, who closed 28k from a post with only 298 views.
They prefer a bank account, right? Not a notification, right.
If you're a small business owner who prefers leads over likes, reply back with "7FC" as in February I'm working with a small group to help you implement a LinkedIn system to generate leads yourselves.
Have an epic day legend, Matt`
________________


Subject: Work with me?
Email Body:
`I'm looking to work with a small group of business owners who want to drive an additional $20k-$30k+ a month to their business through LinkedIn.
And because it's the start of the year and the last campaign was so successful, we wanted to continue the offer of 6 months access for the cost of 2 months.
That way you won't have to worry about lead generation in 2025 and ultimately, about the income you bring home to your family.
Would you like to join us?`
________________


Subject: Teddy ran away
Email Body:
`Hey Creator,
This morning my dog Teddy ran away.
One moment I was walking along, listening to a podcast. The next, I looked up and Teddy was gone.
I started to freak out. I half walked, half jogged up and down the park, frantically trying to find him. I thought to myself, "We go on the same walk every single day. How can this happen?"
Nothing.
10 minutes in, a lady yelled out - "Are you looking for a little black dog?"
I said - "Yeah, I am."
She went pale: "Ah... I saw him running that way near the road. I'm so sorry. I didn't know whose dog it was, and it was so fast."
I started to panic, then I started sprinting. I must have looked like such a dipshit, dog leash around my neck, coffee in hand, attempting to run in flip flops.
I ran 2km up and down the backstreets. Still, no sight of him.
I couldn't believe this was happening. My heart sank. I thought the worst.
Another 10 mins went by until I had a thought - "It can't be. That's a long shot."
I started sprinting. I finally got around the corner, and there he was.
The little shit had run home. He was sitting right outside our gate.
I was relieved, angry, and full of tears all at the same time. (Only a dog owner would understand.)
I realized because we've gone on the same walk 1,000 times, the way home for him is automated. He didn't need to think. He just followed his instincts. He found his way home.
And that's exactly what my client Sean did...
Sean needed leads, but January is impossible to reach people in Australia, but that didn't phase him.
We've been working together since Sep 2023, so he knew exactly what to do. It was automatic.
He ran an offer campaign to an event, he sent out 432 emails that got a 65.63% reply rate, and sold 31 tickets making $1,417.94.
I can't wait to see how many deals he closes from the event.
This is what I teach small business owners (and accidentally taught Teddy, thank God).
I teach you how to generate leads online without thinking, through teaching you the skills, so you can do it yourself.
Without thinking.
So if you're a small business owner that wants to learn how to build a LinkedIn system that generates leads for them, reply back with "7FC" and I'll share the details of our February Case Study Group.
Have an epic day legend, Matt
PS - Make sure you have a dog collar with your phone number and address on it. I didn't and I'm off to buy one today.`
________________


Subject: Burning your reputation.
Email Body:
`Hey Creator,
In September last year, I was chatting in the LinkedIn DMs to a consultant from Germany, who worked with legal firms, who had her reputation destroyed.
Here's how:
We were having a chat, great back and forth. Then she stopped replying for 20 minutes. I thought - "She must have had something come up. I'll message her tomorrow."
Then 2 minutes later, I saw what looked like my high school 10,000-word essay on belonging show up in my messages.
She told me that she really liked my vibe, she thought my program looked great, but there was no way we could work together. She explained to me that 6 months ago, she paid an agency $20,000 to "manage" her LinkedIn account for her.
They built a prospect list to reach out to. They set up the automation to message people. They wrote all the messages that would go out.
She trusted them to do the right thing.
A couple of months went by, and she wasn't getting any leads. The agency told her to wait a bit longer. "It can take time for you."
So she trusted them, and she waited.
A couple more months went by, and still no leads. They said the same thing - "It'll take some more time."
So she trusted them, and she waited.
Then a few weeks later, she started getting text messages from people she knew.
"Hey, why are you sending these messages?" "Can you please stop sending us these messages?" "Why did you send 15 people at our firm the same messages on LinkedIn?"
She freaked out and logged into her LinkedIn, and started reading all the messages in detail. Her heart sank...
The agency was sending 4-5 unsolicited direct pitches in a row to the same person, even when they said no. And what made it worse, is they sent the same messages, to everyone at the company.
This destroyed her reputation.
She explained to me that since then, she had LinkedIn PTSD, and swore she would never do it again.
I told her I was so sorry, and that nobody deserved what happened to her, and said if she ever wanted just to chat, to reach out anytime.
Side note - This is why I NEVER recommend using automation unless you understand how the psychology of messaging on LinkedIn works.
Now you're probably wondering - "How could she be so stupid," and "What did the agency get wrong?"
It's because small business owners don't know what they don't know, because they lack the skills to understand what good even looks like.
And that's my mission: to solve.
Helping small business owners to build the skills, so they can generate leads themselves, so they never need to worry about lead generation again. Or their reputation being destroyed. Because your reputation is everything.
Oh, and if you're a small business owner that wants to learn the skills and generate leads yourself with our system, reply back with "7FC" and I'll share the details of our February Case Study Group.
Have an epic Friday legend! Matt`
________________


Subject: From 3 layoffs to 133% growth
Email Body:
`Hey NAME,
In 6 months, Josh grew his revenue from 1.8M - 4.2M/yr.
What's crazy though, is the year before we met, he laid off 3 rounds of employees, and nearly closed his agency after being in business for 12 years.
Here's what happened:
Josh's agency works with established startups with 100-500 employees. He helps them create a new market category through business strategy, positioning, and brand design. He's worked with Uber, Stripe, and Clari (Just to name a few).
A few years back, interest rates were at an all-time low in the US, and VCs were funding companies like a gambling addict at a roulette table. Then when interest rates dried up, Josh lost most of his leads, and started to panic.
He went into full marketing mode. He ran cold email campaigns. He started doing webinars. He reached out to his network. But it didn't work.
Sure, he got some leads, but nothing consistent. He had to lay off 3 rounds of employees and contemplated shutting up shop.
So in May last year, when we started chatting, he was obviously pessimistic. He knew he probably needed to start social media; that's why we started chatting. He just didn't know how.
We got chatting, and went back and forth for a few days, until finally he said, "Let's work together."
Fast forward to today, and Josh has:
* More leads than he can possibly work with
* Has written multiple viral lead-generating posts
* Grew his business from 1.8M to 4.2M a year.
And on Tuesday we had a 60-minute chat where I interviewed him, asking him how he did it. You can check out the full chat HERE.
So if you're an established small business owner, that wants to implement a LinkedIn lead generation system in your business just like Josh has, reply back with "7FC" And I'll send you the details of the same program Josh went through, to see if you want to work together.
Have an epic day legend, Matt`
________________


Subject: 1:1 Privately
Email Body:
`I'm going to work with 2 small business owners next month to work 1:1 with me privately, to implement our LinkedIn lead generation system in their business.
To qualify you must:
* Have a team of 5-30 people who can implement with you
* You want to invest in LinkedIn as a main lead source
* You have at least 1-2 people who want to become key people of influence in your niche
* You are active right now on the platform by posting content and DMing
* You are selling B2B or B2C high ticket
* You are doing at least 500k per year
Together we will roll out the exact system that we used (and still use) to book 2,300 meetings with only organic content and DMs last year.
This is the first time I have ever offered this, and will only be offering very limited slots ongoing.
Also being upfront, it is expensive, because I know it works and have many case studies to prove it.
One client I interviewed yesterday who we helped grow from 1.8M to 4.2M in only 6 months using LinkedIn.
If this sounds like you, please reply back with "INTERESTED" and I'll come back with a few questions before we set up a chat.
Cheers, Matt`
________________


Subject: Last Wednesday
Email Body:
`Hey Creator,
Last Wednesday I jumped on a 90-minute call with Brian Mark, who built a 10M/yr business in 5 yrs using his Instagram account that he grew to 322k followers.
He did it using only organic content and DMs, which is pretty awesome tbh.
I took 38 pages of notes on the call, and shared the learnings in a 16-minute training.
Would you like me to send it through to you?
Cheers, Matt
PS - If you're a small business owner that wants to drive 30k a month to your business using LinkedIn, reply back with "7FC" and I'll share the details of our February Case Study Group.`
________________


Subject: $10M in 5 years on Instagram
Email Body:
`Hey Creator,
This morning I jumped on a 90 min call with Brian Mark, who scaled his online coaching business to $10M/year in 5 years using only organic content and DMs.
I turned my 38 pages of notes into a 45-minute FREE training for you. Click HERE for instant access.
It includes: 👉 His system of sending DMs that get replies 👉 The 3 types of content Brian uses to go viral 👉 How he grew his Instagram to 317k followers 👉 Secret tactic of getting 80% show rates to calls 👉 Exactly how he booked 70-80 sales calls a week 👉 His YT course strategy booking 100's of meetings 👉 He's helped 330 personal trainers hit $10k/month
Oh and I nearly forgot... I paid $54,000 to get on this call.
So I promise, you won't want to miss it.
Enjoy and have an epic day legend
Cheers, Matt
PS - If you're a small business owner that wants to generate $30k+ a month through LinkedIn using organic content and DM's? Reply back with "7FC" and I'll send you the details of our program`
________________


Subject: Broke my 5km run record
Email Body:
`Hey Creator,
Yesterday I broke my 5km run record after 4 years.
Here's how I did it after only 7 days of training:
For years I couldn't break it... → My training felt flat. → I wasn't seeing progress. → And I kept on thinking, "Maybe I'm just getting older?"
It crushed me as I love playing sports. → I played Soccer for 10 years. → I've done CrossFit for 12 years. → I spend summer days playing spike ball.
But most of all, I f*cking love competing.
Then 5 days before NYE, I decided to make a change. I'd found HYROX last year, and fell in love. So I thought, "F*ck it, I'm going to compete." → I like the movements. → I like that injury chance is low. → I love the training I need to do for it.
So I made a goal: This year I'm going to run a sub-65 min race.
After deciding, I went all in. → I DM'd the world's best athletes on Insta. → I offered big $ to get on a 1-1 coaching call. → I got a response and had a call the same day.
I jumped on a 60-min call with Chris (a legit pro). And in the first 20 mins, I realised I'd been making 5 critical mistakes with training:
1) I'd been undereating 800 calories a day. 2) I wasn't training fueled (carbs now my friend). 3) I'd been overtraining at Zone 3 & 4 heart rate. 4) I didn't do Zone 2 training, which was a mistake. 5) I've never had a goal. Now everything feels easy.
You see... I'd heard all this stuff before, but when Chris told me, I listened. Then 7 days later, I broke my 5km run record. And you know what? It felt easy...
That's why getting a coach matters: → I spent 12 years making mistakes. → I spent 12 years not at my potential. → I spent 12 years working on the wrong things.
And you're doing the same thing with lead generation. → You watched YT videos. → You downloaded Sales Nav. → You post content and comment.
Yet you're still not living up to your potential.
So if you're a small business owner: → That wants to build a system. → That generates leads for you. → That can be implemented this week.
I'm hosting a FREE 90-minute event on Friday to show you how to fill your calendar in 2025.
Register here - https://sevenfigurecreators.com/lm/free-event-how-to-implement-a-system-in-your-linkedin-to-fill-your-calendar-in-2025/
I don't want you to make the same mistake I did. You either pay with your time or pay with your money. What do you value more?`
________________


Subject: FREE 90 minute event
Email Body:
`Hey Creator,
On Friday, I'll be hosting a FREE 90-minute event for you. I'll be showing you exactly how to implement a system in your LinkedIn to fill your calendar in 2025.
Click THIS LINK to register.
You'll walk out knowing how you can generate leads on LinkedIn for your business, plus: → How to send DMs that turn into calls. → How to write client-attracting content. → How to create a lead-converting profile.
It's gonna be tons of fun. Can't wait to see you there :)
Cheers, Matt
PS - I'll also be giving away something epic for FREE for anyone who comes along and stays for the event. So I promise, it'll be worth it :)`
________________


Subject: Starting tomorrow
Email Body:
`Hey Creator,
We are getting started tomorrow. I just wanted to double check if you wanted to join us or not? I don't want you to miss out on the 6 months access for the price of 2 months.
If not, it's all good!
Cheers, Matt`
________________


Subject: The Lead Magnet Playbook
Email Body:
`Hey Creator,
I've generated 45,000+ leads using lead magnets. And this week, we released The Lead Magnet Playbook. I wanted to give it to you for FREE. Click here to access.
It will walk you through how to create your own viral lead magnets. It includes: → 4x Templates to create your own → 2x GPTs to write the posts for you → Everything you need to get 1,000's of leads
Click here to access
Have an epic weekend legend Matt
PS - Whenever you're ready, there's a couple of ways I can help you.
1 - Want to start selling in the DMs today? Get a FREE copy of The Sell By Chat Playbook HERE.
2 - Are you a small business owner who wants to implement a LinkedIn lead generation system in your business? If so, reply back with "7FC" and I'll share the details of our January Case Study Group.`
________________


Subject: We are starting the January Case Study Group next week
Email Body:
`We are starting the January Case Study Group next week, and if you're a business owner who wants to drive an additional $20k-$30k+ a month to your business through LinkedIn, I'm looking to work with you.
We are offering 6 months access for the cost of 2 since the last campaign was so successful.
If you don't want to worry about lead generation in 2025 and ultimately, about the income you bring home to your family, let me know and I'll share the details.`
________________


Subject: Work with me?
Email Body:
`I'm looking to work with a small group of business owners who want to drive an additional $20k-$30k+ a month to their business through LinkedIn.
And because the last campaign was so successful, we wanted to continue the offer of 6 months access for the cost of 2 months.
That way you won't have to worry about lead generation in 2025 and ultimately, about the income you bring home to your family.
Would you like to join us?`
________________


Subject: $3.1M a year LinkedIn business
Email Body:
`Hey Creator,
In 2024 I built a $3.1M a year LinkedIn business from only organic content and sending DMs.
And yesterday, Marina from the Six Figure Creators program asked how I did it?
So I recorded a 38-minute training video that walks through the business model I'd build if I started all over again... and wanted to make $100k-$300k a year FAST.
Click here to access immediately.
Have an epic day legend Matt
PS - Whenever you're ready, there's a couple of ways I can help you:
1 - Want to start selling in the DMs today? Get a FREE copy of The Sell By Chat Playbook HERE.
2 - Are you a small business owner who wants to implement a LinkedIn lead generation system in your business? If so, reply back with "7FC" and I'll share the details of our January Case Study Group.`
________________


Subject: Be very afraid
Email Body:
`Hey Creator,
When people say, "I love your content!" you should be very afraid. Here's why:
I started posting on LinkedIn in December 2022, and for six months, I got zero leads. Yet, at the in-person networking group I attended at 6:30 AM every Friday morning, all 38 other small business owners would tell me they "loved my content."
But they actually didn't. They just felt bad for me. They were being polite.
Because if they truly found value in it, they would have asked to work with me.
Here's the thing: The biggest mistake I see on LinkedIn is small business owners writing for likes. Likes ≠ $. LinkedIn is lying to you.
And that warm, fuzzy feeling you get when you wake up to 20+ little red notifications on your phone, buzzing while you sip your double-shot latte? That's a distraction. That's a lie.
This is the exact advice I gave Pedro when he joined our program. Only two weeks after quitting his 9-5, he's already closed $26,200.
He did it because he followed a system that works---a system built to generate leads, not likes.
So if you're a small business owner who wants to implement a LinkedIn lead generation system in your business and make 2025 your best revenue year yet, reply back with "7FC," and I'll send you the details of our January Case Study Group.
In this group, I'll be working with small business owners like you to help implement the exact same system Pedro uses.
Cheers, Matt`
________________


Subject: I sold myself onto a 2.62M subscriber podcast
Email Body:
`I sold myself onto a 2.62M subscriber podcast with 1 cold DM and 1 post. Here's how:
2 weeks ago I watched the Chris Do and Jasmin Alić YouTube video.
→ As I watched I was → Agreeing with some things → But disagreeing with more.
"How can this be the best YT video on LinkedIn? It doesn't even scratch sales. And it won't help people make money..."
I was gutted.
→ But what could I do? → These guys are huge. → I'm tiny compared to them.
I thought for hours, until finally, I worked it out. → I was going to sell myself on → Using 2 tactics that Jasmin → Said you should never do.
1 - "The key to selling in your content is actually not selling." 2 - Cold DMs are not as effective.
I got to work.
→ I researched Chris Do. → Going deep into his content. → To see what he cared about.
(A tactic I teach 629 students.)
→ His biggest priority right now → Is selling his program that helps → Creatives build their businesses and sell... Perfect 😊
First, I Cold DM'd him this:
"Hey Chris, just checked out your send YT with Jasmin. Epic. Also noticed you've been posting tons more about sales. Would love to get in the ring and back up Richard Moore with some more YT sales content on your podcast. Let me know if you might be open to it? Cheers, Matt"
Next, I spent 1 hr on the post. In it, I made sure:
1 - To not disrespect Jasmin (You should never bash the competition). 2 - To clearly articulate my points (Clear communication is key in sales). 3 - To get support from others saying they want me on (200 people commented "Chris"). 4 - To prove that I would help his audience (I added social proof in the post). 5 - To make the next step easy for Chris (I added my email in the post).
On Saturday afternoon, I posted it. And then... Nothing. So I waited...Still nothing. Checked before bed...Still nothing.
Maybe I wasn't as good as I thought I was 🤷‍♂️
→ Sunday morning → I woke up and went → Straight into LinkedIn.
From Chris: "Matt, I'm game."
→ I f*cking did it. → But you know what? → I knew I was going to 😉
All this bs about → "Don't be salesy" → Is a narrative being pushed by → People that don't know how to sell
The right way. And on February 7th, I'll teach you how...
So if you're a small business owner that doesn't have 12 months to wait around for your "content" to work And wants to implement a system to fill your calendar for 2025 in the next few weeks?
Reply back with "7FC" and I'll share the details of our January Case Study Group.
Cheers, Matt
PS - What should I talk about on the podcast?`
________________


Subject: My Xmas Gift To You (It's Epic)
Email Body:
`Hey Legend,
I'm about to head off to my Mum and Dad's house for dinner. But before I do, I wanted to share a present with you.
Because I appreciate each and every one of you who supported me.
I wanted to give you a FREE Gift - The Sell By Chat Playbook.
This book has all my knowledge from 7 years in sales plus spending 1,000's of hours and sending over 50,000 DMs.
I jam-packed it all into a short 45 minute read, so you can fill your calendar in 2025.
Click Here For Instant Access.
Merry Christmas You Absolute Legend.
From my little family to yours ❤️
Cheers, Matt`
________________


Subject: A GPT that writes your LinkedIn DMs
Email Body:
`Hey Creator,
I've closed $1.8M from LinkedIn DMs in 17 months.
I then took my 100's of hours of knowledge and created a GPT that's better than me.
And I wanted to give it to you for FREE.
Click HERE to access.
It's super simple to use too. Simply:
1) Copy and paste your DMs 2) Ask it to write the next message 3) And you'll book dozens of meetings
Without even thinking. Have fun with it!
Cheers, Matt
PS - Whenever you're ready, here's how I can help you:
1 - Are you a small business owner that wants to fill your calendar for 2025? If so, reply back with "7FC" and I'll share the deets of our program.
2 - If you're an established LinkedIn creator earning $30k+ a month and want to get to $100k?
Our Exclusive Private Program might be good for you. Reply back with your LinkedIn profile and "PRIVATE" and I'll share the details.`
________________


(This is going ONLY to people who opted in for the 12 DAYS OF CHRISTMAS OFFER)
Subject: 12 Days of Christmas
Email Body:
`Hey Creator,
I first just wanted to say I'm sorry.
We were going to run a full 12 days of Christmas campaign, but tbh, it didn't do that well so we scrapped it.
However...
I want to reward you for being such a legend and always supporting me.
So instead of 12 lead magnets, here's the library of all my lead magnets of all time 🙂
Click HERE to access.
Have an epic Christmas Legend!
Cheers, Matt`
________________


Subject: Private Chef Wedding
Email Body:
`Last week it was my brother's wedding. I gifted him a private chef for the weekend.
25 people fed for 4 days with 5-star food. They thanked me dozens of times.
But it wasn't the food... I gave them the gift of time. → No one cooked → No one cleaned → No one stressed
We spent hours together. I didn't even flinch at the $6k bill. Why?
→ My LinkedIn's an atm machine → On Friday I sent DMs for 90 mins → And made $6,300 between coffees.
I paid for it. Now...
→ This post isn't to gloat → This post is about priorities. → The one thing you're avoiding
Lead generation. That "icky" word.
→ Stop sticking your head in the sand. → 2025 won't "magically" solve your problems → It's just another "I'll start tomorrow" excuse.
So for 48 more hours ONLY I'm offering: 6 mths access to our program → For the price of only 2 months. So you can join now and: → Fill your calendar for 2025. And still take 2 weeks off for the holidays.
So if you're a small business owner wanting to generate 5+ leads a week using LinkedIn, DM me "7FC" and I'll send you the deets.
Thanks legend, Matt`
________________


Subject: Quick One
Email Body:
`Hey Creator,
Just in case you missed the other messages:
The Christmas Offer where we are providing 6 months access to our program for the price of 2 months ends on the 17th of December.
Would you like to join us?`
________________


Subject: Christmas Sales Ending
Email Body:
`Hey Creator,
The 6 months access for the price of 2 months Christmas Offer is ending shortly.
Let me know if you'd like to join us?
Cheers, Matt
PS - If you've been on the fence about building a LinkedIn lead generation system, now is the perfect time to fill your calendar for 2025 and have your best revenue year yet.`
________________


Subject: Christmas Sale
Email Body:
`I'm looking to work with a small group of business owners who want to drive an additional $20k-$30k+ a month to their business through LinkedIn.
And to celebrate Christmas, I'm offering 6 months access to our program for the price of 2 months.
That way you'll be rewarded for both joining now and you can still take a couple of weeks off to spend time with your family during the holidays.
Would you like to join us?`
________________


Subject: $70,000 in 5 weeks
Email Body:
`Hey Creator,
I just chatted to Tim Keen who closed $70,000 in 5 weeks after joining our program.
Before working together we'd been chatting for a couple of months, and Tim sometimes asked for my advice.
He'd built a solid 38,000-follower audience, and was getting 100's of leads with his lead magnets, but he was struggling to convert them into clients.
He couldn't wrap his head around what was going wrong.
And one day he sent me this message.
We chatted a bit longer, built a plan, then we got to work.
Together we built a new offer, refined his positioning, and set up a DM system to track leads. And 5 weeks after launching his New Offer, Tim closed $70,000
And only yesterday we got on a call in front of everyone in our program to talk about how he did it. Check it out HERE.
So if you're a small business owner that's sick of spending months trying to work LinkedIn, and wants to immediately implement a system to generate an additional $20-$30k a month revenue from LinkedIn, filling your calendar NOW for 2025,
Reply back with "7FC."
Oh, and we have a Christmas Special going on atm.
If you join before the deal expires next week, you'll get 6 months access to our program for the price of 2 months.
Because I want to reward you for investing in yourself. And I want you to take some time off during the break, knowing that you'll still have many months extra time to implement and make 2025 your best revenue year yet.
Cheers, Matt`
________________


Subject: My brother's wedding
Email Body:
`Hey Creator,
On Saturday it was my brother's wedding. I was honored Dan asked me to be the best man, but at the same time, shitting myself about the speech.
120 of our family and friends watching. I had to deliver.
So I got to work. -- I spent hours recalling old stories. -- Asked my friends what makes a good speech. -- Then worked hard getting the format right.
After weeks of work, I finally: -- Chose the 3 stories -- Decided on the format -- Recited so no notes needed
I was ready. 8.30pm I'd be 3 drinks down. Perfect.
Then at 6.20pm (Stone cold sober):
"Alright everyone, get ready for Matt the best man's speech."
Ah shit...
I walked up, and the MC handed me the Mic. I took it from him, composed myself, and got to work.
And... I fucking nailed it.
-- "How did you even come up with that?" -- "Greatest best man speech I've ever heard." -- "I didn't know you were such a good speaker."
I did it. I delivered. Why? Because I didn't leave it until next year...
This is what every small business owner does with their lead generation. You know it. I know it. We all know it.
"I'm gonna leave this till 2025."
But... What if you did the opposite? What if you built systems now? What if 2025 started with a full calendar?
Stop treating your business like the sloppy best man who tried to "Off the cuff" their speech, making an embarrassment of themselves, and even worse, the bride and groom...
If you're a small business owner that wants to start 2025 with a full calendar of appointments?
Respond back with "7FC" and I'll share the details of our Christmas Case Study Offer.
Cheers, Matt
PS - Here's the bride and groom.`
(Note: Reference to an image "Here's the bride and groom.")
________________


Subject: 70 min training
Email Body:
`Hey Creator,
Last Wednesday I presented to a $20k a year Mastermind. I'm giving away the presentation I gave on - How to generate leads forever on LinkedIn, for FREE.
Click Here to access.
The 70-min presentation includes: 👉 How I make $2.5M a year on LinkedIn 👉 The only metric you should track 👉 How to have chats that turn into calls 👉 How to write client-attracting content 👉 How to create a lead-converting profile
It's the exact training I gave to 100 people live. And I can't believe I'm giving it away for FREE...
Hope you get tons of value!
Cheers, Matt
PS - Whenever you're ready, there are 2 ways I can help you:
Are you looking to build a business and make $10-$30k on LinkedIn? If so, our Six Figure Creators program might be a fit. If so, check out the FREE training video HERE.
Are you a small business owner that wants to generate 5+ warm leads a week from LinkedIn to your already established business? If so, check out the video HERE.`
________________


Subject: Cyber Monday Deal
Email Body:
`Hey Creator,
Our Black Friday Offer was such a success, that I've extended the 33% off sale into Cyber Monday (Today).
The offer will be available for another 24 hours before the price increases.
If you want to start 2025 by focusing on generating leads, it's a good time to join.
If interested, reply back with '7FC' and I'll share the details.
Have an awesome day legend, Matt`
________________


Subject: Black Friday sales ends today
Email Body:
`Hey Creator,
The 33% off Black Friday sale ends today.
If you're interested, reply back with '7FC' and I'll share the details.
Cheers, Matt
PS - If you've been on the fence about investing in learning to generate leads on LinkedIn, then now is THE perfect time. We'll spend the next few weeks building the systems so you can hit 2025 HARD, and make it your best revenue year yet.`
________________


Subject: Black Friday Sale
Email Body:
`I'm looking to work with a small group of business owners who want to drive $10k-$30k a month to their business through LinkedIn.
And to celebrate Black Friday, I'm offering an additional 33% off for the next 48 hours.
Would you like to join us?`
________________


Subject: $1.48M from 1 funnel
Email Body:
`Hey Creator,
I made $1.48M from my single LinkedIn funnel without spending $1 on ads.
I recorded a 31-minute training video to walk you through exactly how I did it (So that you can steal everything).
It includes:
* The 2 types of funnels you need
* How I 10x leads with my content funnel
* How I built a 10k email list ↑ revenue 30%
* How I repurpose the same content 6 times
* The biggest profile mistakes you are making
Click to Access HERE
Oh, and near the end, I also audit Justin Welsh's funnel showing you how he made $8M from LinkedIn.
Have an epic Monday, legend. Matt
PS - I'm having a Black Friday sale on our Six Figure Creators program.
If you're a business owner that wants to drive $10k-$30k a month additional to your business through LinkedIn? Reply back with "7FC" and I'll share you the details.`
________________


Subject: Chatted with Bill
Email Body:
`Hey Creator,
Just chatted with Bill who 4 weeks ago closed his first ever non-referral client from LinkedIn.
When we first met, he'd been running his business for 6 years and was struggling. For years he tried all different lead gen strategies, and nothing worked. It crushed him. Especially because he has a young family, and the stress from this and not knowing when the next random referral would come in was crippling.
So when we first met, he was obviously sceptical. I explained to him how our program was different. We don't teach you "engagement tactics" or give you "cold DM templates." These are just band-aids that don't address the core issue: You haven't learned the skills to generate leads yourself.
That's what I teach you. So you can generate leads forever.
He joined, and shortly after this happened...
Bill didn't make 6 figures (yet), but he got something even better. He now has a LinkedIn lead generation and sales system where he can predictably generate non-referral clients forever.
He can now build the dream life he and his wife always dreamed about giving their young kids.
And all it took was a couple of months learning some new skills.
So if you're a small business owner that's sick of waiting for the next random referral to come in, and want to spend a couple of months building a system just like Bill, so you can control the revenue your business generates, without relying on random referrals,
Reply back with "7FC" and I'll share the details of our December Case Study Program, where I'll be working with a group of small business owners who want to implement this system in their business.
Cheers, Matt`
________________


Subject: 90th birthday
Email Body:
`Hey Creator,
It was Pa's 90th birthday yesterday, and at cake time my siblings and I got up to do a speech.
I talked about one of his best qualities -- Listening.
You know when you go to a party and everyone's chatting in a group, and you can tell people are just waiting for their turn to speak?
Everyone I know does it, but not my Pa.
He never talks about himself; he only asks you questions. How's the dogs? How's Tanisha doing? How's that LinkedIn thing?
He's been doing this for decades, and because of it:
You feel seen by him. You feel heard by him. You trust him to your core.
When I mentioned this in my speech, I saw all 60 people in the room nod. They all trust my Pa.
My Pa is the greatest salesperson in the world.
Sales isn't about discounts, manipulation, or pressuring people. You win sales with brutal honesty, childlike curiosity, and genuine empathy.
It's about actually giving a shit and doing the right thing, even if it means losing the sale. You should be helping > selling.
So if you're a small business owner who wants to learn how to sell on LinkedIn without feeling salesy---just like my Pa does---
Respond back with "7FC," and I'll share the details of our December Case Study Group. Where I'll be teaching a small group of small business owners how to build the skills to generate leads and sales themselves on LinkedIn. So you'll never have to worry when the next referral will be coming in again.
Cheers, Matt "helping" Lakajev`
________________


Subject: New Product Is Live!
Email Body:
`We've finally released -- Build Your LinkedIn Profile In 30 Minutes.
Click Here to get immediate access right now.
It includes: -- 20+ template inspired by top creators -- Step by step video walkthrough how to use -- Banner, Featured Section, Company Banner
All you need to do is pick a template, swap out text, change colors and add your logo. And you'll have a top-level creator profile in minutes.
It's so easy, even my 90-year-old grandpa can do it.
LFG legend! Matt
PS - After you get it, we have another special offer that you will not want to miss out on!`
________________


Subject: 1 day late
Email Body:
`Hey Creator,
I'm sorry but we have to push back the release of the Build Your LinkedIn Profile in 30 minutes to tomorrow.
It's taken longer than expected, as we want to make sure it's perfect.
Honestly seeing what Steve (My Co-Founder) has built has floored me.
I promise, you'll have never seen a LinkedIn product this good.
But to be fair, most of the products are a bunch of duct-taped Loom videos a 21-year-old "personal brand" expert is selling as a "course to make money on LinkedIn."
So there's not really much competition...
Meanwhile Safouan signed 2 clients in 2 weeks from my FREE content alone.
Honestly, you just can't make this stuff up lol.
Anyway legend, catcha tomorrow for the release!
Cheers, Matt`
________________


Subject: Your LinkedIn Profile in 30 minutes
Email Body:
`Hey Creator,
Tomorrow we'll be releasing our biggest product drop to date, where you'll be able to build a world-class LinkedIn Profile in 30 minutes.
Insane I know? I can't believe Steve my Co-Founder was able to do it. Actually nah, I knew he could. He's a product beast.
But anyway... we wanted to release this product because everyone's wasting so much time "rebuilding their profile," changing it 5 times when they haven't sold anything yet. Waste of time really.
Rebuilding your profile is simple procrastination from doing the 1 thing you know you should be doing: Which is - selling your stuff in the DM's.
But we get it; you want to look good, feel confident, and hijack trust. So we built this kit to solve it for you.
And it'll be coming out tomorrow, with a 1-time discount for all email subscribers.
Have an epic day legend. Cya tomorrow.
Matt`
________________


Subject: A $15,000 jail
Email Body:
`Hey Creator,
Last week I paid a $15,000 VET bill for our 14-year-old dog Cherry.
3 weeks ago, I noticed she was walking strange. Then she all of a sudden collapsed her front paws. My wife and I rushed her to the VET.
She got an MRI, and it turns out she had some injured discs in her back. Luckily she didn't need to get surgery. She still needed to stay at the VET for 2 weeks so she could heal.
We picked her up last Friday, and while at the front counter, we got the $15,000 bill.
I paid immediately without flinching. All I cared about was that Cherry was safe.
Now she has to spend all day in jail (which she hates).
But she's healthy.
It's crazy to think only a few years ago, that bill would have been all my money. And imagine if she needed surgery.
Makes me sick thinking about it.
That's exactly how I feel after someone lets me know they've been creating content for 6 months and commenting 2 hours a day. But still haven't got any clients.
That's how my client used to feel, owning his business for 6 years, never knowing when the next referral was coming in. No control.
Now he's closed his first ever non-referral deal, and last week closed another. He's now in control of the revenue his business makes, and of the money he has for his family.
And that's what I want for you.
In November, I'll be working with a small group of small business owners that want to get consistent clients on LinkedIn. Just like my client.
Reply back with "7FC" if you're keen. We're getting started shortly.
Thanks, Matt "$13,000" Lakajev`
________________


Subject: Kit to create your LinkedIn profile in 30 mins
Email Body:
`Hey Creator,
This week I paid a designer $4,000 to design a kit that you can use to clone top LinkedIn Profiles in 30 mins.
After seeing way too many people: → Struggling to set up their profile → I made this LinkedIn Profile Kit so → You can design your profile in mins.
It features Lara Acosta, Jasmin Alic, Justin Welsh, Nick Broekema, and many more.
It'll be released next Thursday, and I just wanted to give you a heads up.
Looking forward to sharing it with you.
Have an epic weekend legend!
Matt`
________________


Subject: 4 figure deal in 2 hours
Email Body:
`Hey Creator,
Last week I closed a 4-figure deal in 2 hours in the LinkedIn DMs without a sales call.
Later that day, I went through the chat with my team, and they found it so useful that they suggested I share it with my community.
So I recorded a 32-minute training video for you on:
* How I started the conversation
* How I qualified for budget + timing
* My 3-step persuasion closing sequence
* The signs that I knew they were ready to buy
* How I used mutual connections to increase trust
You can access it here.
Now, I know what you're thinking -- "But Matt, I don't close deals via DM and I need to get onto sales calls to talk to people."
And I totally get you. That's exactly what I did in my 5-year career in sales, where I sold millions of $ from 1000s of sales meetings.
The purpose of this training, however, is to show you the actual real-life tactics I use to build trust and rapport, be strategic with questions, and persuade the person to take the next step. Because for 99.9% of you, the next step will be to get them on a call. Which is MUCH easier than closing a deal in the DMs.
What I'm getting at is this training shows you how to play the game on hard mode and still win. To show you that booking meetings is possible, just like Eduardo who booked 2 calls in 12 hours after joining our program...
Enjoy the training, legend!
Cheers, Matt`
________________


Subject: Solopreneurship is stupid
Email Body:
`Hey Creator,
IMO, Solopreneurship is stupid.
I don't fix my car. I don't cut my hair. I don't repair my fridge.
So why would I do things in my biz that aren't one of my superpowers?
People ask how I scaled so fast. It's simple: Anything that steals my energy, I delegate.
That way I 100% focus on: → Creating content → Coaching my clients → Building our program
This is why my clients win. Like Roy, who made £120k last week after running our offer campaign.
He did it without even posting content for a month...
So who do you want to work with? The 98% profit margin "solopreneur" guru, OR The person who cares about helping clients win?
If the latter, REPLY back with "7FC," and I'll share the details of our November Case Study Group.
Because I need a team to build your dream. And if I cut profit to do it, then I'm ok with it.
Cheers, Matt "Notasolopreneur" Lakajev`
________________


Subject: Deal in 2 hours walking Teddy
Email Body:
`Hey Creator,
I closed a deal in 2 hours while walking Teddy the other morning at 6:32am.
Usually I go for a no-phone walk in the morning, but that day I had a few things to get to.
While walking, the dopamine took over, and I had to check LinkedIn lol. I scanned the messages and saw a lead responded, so I sent them a couple of voice notes replying.
They got back to me, we had a back and forth chat, and 2 hours later they joined our program.
I told a few people in our program, and they couldn't believe it. They said, "How did you close someone literally in 2 hours in the DMs?"
So instead of explaining, I decided to record a 32-minute training video for you walking through exactly how I did it.
Click this link to access it.
I hope you get a ton of value from it, you legend. Have an epic week!
Cheers, Matt`
________________


Subject: My Co-Founder Steve
Email Body:
`Hey Creator,
My Co-Founder Steve closed $100k in 3 months without ever posting content, making one comment, or even having a profile photo.
All he did was: → Build a list of ICP in Sales Nav → Connect with 200 people a week → Have conversations and share this work.
He closed $100k of agency clients doing this.
All the *** you see in your feed about: → Posting for 6 months → Commenting 2 hours → Styling your banner
Is a load of bs.
→ The only people telling you this → Also sell a LinkedIn growth course → That tells you to engage on their posts.
Reminds me a bit of Jordan Belfort...
The likes can't stop, or the charade comes to an end.
But if you'd prefer leads over likes, → You're someone I want to work with.
Reply back with "7FC" and I'll share the details of our November Case Study Group.
Or feel free to stay in the pyramid scheme → And watch the money all go to the top...
Cheers, Matt "pyramid" Lakajev`
________________


Subject: Brokefluencers
Email Body:
`Hey Creator,
Everyone needs to stop listening to brokefluencers.
→ "Post for 6 months" → "Have coffee chats" → "Comment 2 hours day"
These are red flags your guru is full of it.
How do I know? → I chatted with dozens of "20k creators" → Who need my help getting clients, but → They can't even afford 3 figs to start.
Yet they're still: → Selling to biz owners → Saying they can help get → Leads with "personal branding"
What a joke.
→ That's why I created this FREE course → To help you get clients on LinkedIn so → You can then join our paid program.
Click here to access - https://sevenfigurecreators.com/start-selling-on-linkedin/
→ Because my FREE stuff → Will make you 10x the money → Than your "brokefluencers community"
But don't just believe me, believe my clients.
"Made five sales and got over 100 new leads. Leveraging the course has saved our business."
Now click the link to get started, OR
→ Keep listening to your 22-year-old "guru" → And their "LinkedIn growth" pyramid scheme → About how "Commenting" is how you make $.
Lol. What a joke.
Cheers, Matt "not a brokefluencer" Lakajev
PS - Whenever you're ready, there are 2 ways I can help you:
1 - Are you a LinkedIn Creator or Business Owner already doing $25k a month through LinkedIn? If so, you might want to check out our Seven Figure Creators Program. Click HERE to check it out.
2 - Are you a small business owner that wants to generate 5+ warm leads a week from LinkedIn to your already established business? If so, check out the video HERE. `
________________


Subject: Stuck in a wage cage
Email Body:
`Hey Creator,
In 2018 I was stuck in a wage cage earning $42,770 a year.
One day at the office, I felt a sharp pain in my chest. I thought I was having a heart attack.
I rushed outside and spent 45 minutes on the phone with my mum. Turns out it was anxiety, and it stuck with me for 6 months.
It was so bad, at 27, I moved home with my parents. It crippled me.
I didn't know where it came from, but I knew I needed to make a change. I started searching...
After months of looking, I found this weird job called sales. I became obsessed.
I applied for 100's of roles, and 5 months later, Zoom gave me a chance. Finally finding my passion.
Fast forward 4 years, sales gave me the skills I needed to escape the matrix. And in Dec 22 I started my business.
It took me 9 months of disgustingly hard work, countless breakdowns, and burning $180,000 of my savings before I finally worked out my offer.
Since then, we've collected $1M cash, and did $130,000 last month. That's 3X my old salary.
Reflecting back, if I'd had help with my offer, it would have saved me soo much pain.
That's why I built this FREE offer training for you. For all the entrepreneurs who've escaped the wage cage.
You can access it here - https://sevenfigurecreators.com/start-selling-on-linkedin/
It's what I wish I had, when I started.
Cheers, Matt
PS - Whenever you're ready, there are 2 ways I can help you:
1 - Are you a LinkedIn Creator or Business Owner already doing $25k a month through LinkedIn? If so, you might want to check out our Seven Figure Creators Program. Click HERE to check it out.
2 - Are you a small business owner that wants to generate 5+ warm leads a week from LinkedIn, to your already established business? If so, check out the video HERE. `
________________


Subject: 1 hour left
Email Body:
`Hey legend - Ok I swear this will be the last email haha.
I've just been really excited as this is the first digital course product I've ever sold online. And I can't wait to see everyone's new funnels all over LinkedIn that will help you capture so many more leads.
If you're interested, check it out HERE.
If not, all good!
It's Friday evening anyway, and I'm about to head over to the in-laws to celebrate Diwali.
So Happy Diwali and catcha next week, legend!
Cheers, Matt`
________________


Subject: 3 hours left
Email Body:
`Hey legend,
I'm only selling The Complete Funnel System I used to hit $1M+ for another 3 hours.
If you're interested, check it out HERE.
It's the same system my client Bjion used to book 68 meetings in 12 days.
If not, no biggie.
Have an epic Friday, legend.
Cheers, Matt`
________________


Subject: 24 hour sales
Email Body:
`Hey legend - Sorry I totally forgot to let you know in my last email!
I am selling my first ever course, and it will only be available for 24 hours. Click the link here to see more details.
After 24 hours, you won't be able to access this page. So if you are keen, might be a good time.
Have an epic day!
Cheers, Matt`
________________


Subject: I closed $28,776 in 30 minutes last week
Email Body:
`Hey Creator,
Last week I closed $28,776 in 30 minutes over 2 Zoom calls.
This is exactly what happened.
A creator with 30,000 followers DM'd me a few weeks back, and we started chatting. We got along pretty well, and I asked his opinion of our new website. He took a look and said it looked great, and that he might actually want some help. So we organized a Zoom chat for the next day.
That next morning I jumped on the call, spent 15 mins explaining what we do, and he said "I'm in." And paid right after the call --- $1,199 USD a month for 12 months.
The next creator with 120,000 followers reached out to me, and said: "Man... how do I get my program to $100k/mo? That's my #1 goal by Jan 2026. You're already there/past that with half the following/follower count. Bigger niche to play in/go after, but still. It's time for me to turn this thing on. - What does your program cost/look like?"
I responded and we chatted a bit, then locked in a call. We jumped on the call, I explained what we do, and he paid immediately. Another $1,199 USD a month for 12 months.
Now you're probably wondering --- "Matt, how did this happen so quickly?" It's because I spend a lot of time on my Positioning.
Let me explain...
First let's define Positioning with a little help from ChatGPT: "Positioning is a strategic process in marketing that defines how a product, service, or brand is perceived in the minds of target customers relative to competitors. It's about identifying and communicating a distinct and compelling advantage that differentiates you from alternatives in the marketplace."
Just think about it as how clear your message is communicated about how you help your clients.
And it's the first part you need to get right, along with your offer.
But here's the catch --- your Positioning isn't stagnant. It will constantly change the more you work with clients. Sharpening over and over, until you dead set have the Sword of Gryffindor.
When you get Positioning right, it means you play the game of business on easy mode. Because when your ideal clients read your posts, lead magnets, and landing pages, it's crystal clear how you can help them.
But for some reason, everyone on LinkedIn's talking about commenting 2 hours a day, or making your profile look pretty. But without getting your Positioning right, and using it to craft your Offer, then refining it over time speaking to people, you'll play the game of business on Very Hard mode --- and make 10x less money than you could.
So if you're a business owner that's to implement a system, to start generating more clients on LinkedIn on Easy Mode, reply back with "7FC," as I'm looking to work with a small group of business owners this month to show you how to get clients on LinkedIn the right way.
Thanks, Matt "positioning" Lakajev`
________________


Subject: $2M ARR and 50,000 followers in 697 days
Email Body:
`Hey Creator,
I started my business 697 days ago, and last week hit 50,000 followers and $2M ARR.
But getting here was disgustingly hard.
In the first 6 months: → I changed offers 5 times → I burned $180k of my savings → I cried more times than I can count.
Building a business nearly destroyed me. But somehow, I pushed through.
I worked out my offer and launched in July 2023. → Over the next 6 weeks → I worked with 25 biz owners → Showing how to get leads on LinkedIn.
And the results were insane... Finally, I found my mission. My purpose. Helping creators and businesses: → Get more leads → Make more sales → Build businesses they're proud of
Since then, I've worked with 500+ creators → To help them build a life of their dreams.
That's why I created this FREE course, which is part of our first mission: → Helping 10,000 creators make their first sale.
As this will help us complete the second part: → Helping 1,000 creators achieve 6 figures, → Helping 100 creators reach 7 figures.
So, if you want to finally start making money using LinkedIn, Get leads and not likes, and build the life of your dreams,
Check out our programs HERE.
And want to know the best part? We're only just getting started...
Cheers, Matt`
________________


Subject: One time offer
Email Body:
`Hey Legend,
I want to make you a one-time offer.
We are releasing a new Product Tomorrow on Building Your LinkedIn Funnel in the Six Figure Creators program. It's the exact same funnel I used to book 2,007 inbound meetings in 12 months.
For the next 48 hours ONLY, I am selling it separately, so you can get access to it without joining our program. After 48 hours, I will stop selling it.
This video walks you through what will be inside it -- it was an announcement I made to our program last week.
I'm selling it for $197 USD, and it will give you the access to the complete funnel kit, so you can build your LinkedIn funnel to generate leads from your profile.
If you are wanting to purchase it? Only the people who reply back with "LINKEDIN FUNNEL" will be added to the list so you can purchase it. Then you can get access to it tomorrow when it's released.
Cheers, Matt`
________________


Subject: I went to Oktoberfest
Email Body:
`Hey Creator,
Last Saturday, I went to Oktoberfest. I was there to wingman my brother-in-law, who's single.
While we were in the mosh pit, the music suddenly switched from Skrillex to the Titanic theme. We started laughing, and so did a group next to us, so we began chatting.
We quickly became friends and decided to head to another stage, hoping for better music. While waiting in line, I started chatting with one of the girls, who was from the UK. She'd arrived in Australia only three weeks ago.
We started talking about work, and she mentioned she landed a job her first week here. I asked her how, and she explained:
"I just Googled all the best bars in the area and found the ones that looked cool. Then the next day, I went in when they opened, asked to speak to the manager, and told them I was looking for a job. I got 3 offers and took the one I liked best."
That's also how Jeremiah closed six deals last week.
He joined our program four months ago: → We went to the Oktoberfest festival. He filtered his ideal clients in Sales Navigator: → I asked my brother-in-law for his type. He started conversations with them: → We started chats with lots of people. He closed six deals last week alone: → My brother-in-law has a date this week.
So if you want to learn how to get clients on LinkedIn, without having to listen to the Titanic theme, wondering why Leo couldn't fit on the raft...
Reply back with "7FC" and I'll share the details of our November Case Study Group. I might be able to help.
Have an epic week, you legend.
Cheers, Matt "Titanic" Lakajev`
________________


Subject: Got called insane
Email Body:
`Hey Creator,
I got called insane on Wednesday.
On Wednesday, at my brother's birthday dinner in Manly, our friend Luke called me insane. For the past couple of weeks, Luke, my brother, and I have all been getting into running. It started 2 months ago, when we went for a run together through Manly on Sydney's Northern Beaches. (A place you should 100% visit if you come to Australia.)
We did an easy 5km jog at 10am in the morning, dodging people as we ran along the beachfront. Such a nice place for a run.
At the end, we went and got coffee and started chatting about the longest runs we've all done. None of us had done a marathon though.
We talked about how cool it would be to do one --- maybe in a few months after training.
2 weekends later, I woke up on Sunday morning at 6am and had the next 5 hours free. My wife went out the night before, so she wouldn't be up for a few hours haha.
I started thinking about how nice it was running in Manly, and how nice it would be to do it that day. But Manly is quite far from my house. I'd have to run pretty far to get there. Then I thought --- "What if I run a marathon today?"
I thought about it for about 5 seconds, and thought --- "F*ck it. Why not?"
So I ran to Manly, did a few back and forths along the beach, then ran home. I hit 42.195km in 4 hours and 19 minutes. Not a record time by any means, but I completed it, which I was proud of.
My first marathon in the books.
Then on Wednesday night, when I went to dinner at Hugo's in Manly for my brother's birthday, we started chatting about running. And Luke said --- "Matt, I can't believe you actually ran a marathon. You're insane." To which I replied --- "To me, it didn't seem insane at all."
What's funny is it's not the only time I've been called insane.
Dozens of people have called me insane for how many leads I've generated on LinkedIn. 2 days ago I checked, and I've booked 2,003 meetings in 12 months, using only organic content and DMs on LinkedIn. Nobody can comprehend how I've done it, so they just say "Matt's insane."
They can't rationalize it in their brains.
But to me, it's not insane at all... It's a system I've built from my 6 years of experience in sales, and it's the problem I've dedicated my life to solving for over 18 months: Helping creators and business owners get clients on LinkedIn.
I walk the walk, and teach my clients what I do. And it's why we get results: --- Like Bjion, who's booked 350+ meetings since working together --- Or Josh, who gets 5 likes a post, but still books 6 meetings a week, and does $100k a month --- Or Jesse, who closed $69,000 from running our offer campaign 2 times.
It's not insane at all. It's a simple system they implemented over a couple of months --- that's built them a never-ending stream of leads and new clients.
So if you want to start generating leads and getting more clients on LinkedIn, and work with me, the insane LinkedIn guy who walks the walk, Reply with "7FC" --- and I'll send you the details of The November Case Study Group. And if it's a good fit, we can start building your system together.
Matt "insane" Lakajev `
________________


Subject: 42 meetings and 7 deals
Email Body:
`Vidhya's booked 42 meetings with our system, and closed 7 deals in 3 weeks.
I'm giving away how she built her LinkedIn business, for FREE.
The 53-minute interview breaks down: --- DM system she used to book calls --- How she created a viral lead magnet --- Funnel that's booking daily meetings
Plus so much more.
And want to know something crazy? Her first 6 months on LinkedIn, she closed ZERO clients, even with 8k followers.
That's why this is a training you can't miss if you want to make money on LinkedIn.
Click HERE to access.
Have an epic Friday, you legend.
Cheers, Matt
PS - Whenever you're ready, there are 2 ways I can help you:
1 - Are you a LinkedIn Creator or Business Owner already doing $25k a month through LinkedIn? If so, you might want to check out our Seven Figure Creators Program. Click HERE to check it out.
2 - Are you a small business owner that wants to generate 5+ warm leads a week from LinkedIn to your already established business? If so, check out the video HERE.`
________________


Subject: $87,500 in July 2023
Email Body:
`Hey Creator,
I made $87,500 in July 2023 selling 25 people my offer. And I did it without having built a single thing...
The reason you don't build first is: Because you have no idea what people want. Because you haven't worked with anyone yet.
So all the stuff you're "building" is a waste of time --- and you'll throw it all away in 2 months anyway.
The ONLY way to know what to build, is to start working with customers.
But the reason people build is because it "feels" good. But business isn't meant to feel good. It's meant to feel f*cking hard.
And that's why so many people don't make it. They think it takes 3 months to build an offer, when in reality, it should take you 3 hours.
Building is you procrastinating doing the 1 thing you know you should be doing, which is reaching out to strangers, asking them to buy your stuff.
That's exactly why I built this FREE Start Selling on LinkedIn Course.
Click to access - https://sevenfigurecreators.com/start-selling-on-linkedin/
So you can build your offer now, and start selling immediately. And then come work with me and 500 other creators, building the life of their dreams.
And remember... → It's only fear holding you back. → So give it the middle finger and → Start building the life you deserve.
Or be stuck in a wage cage the rest of your life. You decide...
Have an epic day Matt
PS - Whenever you're ready, there are 2 ways I can help you:
1 - Are you a LinkedIn Creator or Business Owner already doing $25k a month through LinkedIn? If so, you might want to check out our Seven Figure Creators Program. Click HERE to check it out.
2 - Are you a small business owner that wants to generate 5+ warm leads a week from LinkedIn, to your already established business? If so, check out the video HERE.`
________________


Subject: We are starting with The October Website Launch Group this week.
Email Body:
We are starting with The October Website Launch Group this week. Would you like to join us?
________________


Subject: Work with me?
Email Body:
`I'm going to work with a small group of business owners next month who've been struggling to generate leads, are sick of relying on referrals, and want to implement a system to drive $10k-$30k+ a month from LinkedIn consistently.
Would you like to join us? If so, just reply back with KEEN.`
________________


Subject: Spent weeks creating
Email Body:
`Hey Creator,
I spent weeks creating this 217-minute course that I'm giving away, for FREE. It walks you through step by step --- How to Start Selling on LinkedIn.
But before you access it...
→ I need you to Pinky Promise me → That if you close a deal using the training, → You'll come work with me in Six Figure Creators.
Where I'll help you build a life of freedom.
Access it HERE now.
Have an epic day legend! Matt`
________________


Subject: My biggest announcement ever
Email Body:
`Hey Creator,
I started my business 697 days ago, and I'm not going to lie---it was brutal.
In the first 6 months: → I changed offers 5 times → I burned $180k of my savings → I cried more times than I can count.
Building a business nearly destroyed me. But somehow, I pushed through.
I worked out my offer and launched in July 2023. → Over the next 6 weeks → I worked with 25 business owners → Showing how to get leads on LinkedIn
And the results were insane... Finally, I found my mission. My purpose:
Helping creators and businesses: → Get more leads → Make more sales → Build businesses they're proud of
Since then, I've worked with 500+ creators → To help them build a life of their dreams
That's why today is so special for me---my biggest announcement ever: The launch of our new brand Seven Figure Creators, with a new mission: → Helping 10,000 creators make their first sale → Helping 1,000 creators achieve 6 figures → Helping 100 creators reach 7 figures
So, if you want to finally start making the money you deserve on LinkedIn, get leads and not likes, and build the life of your dreams,
Check out our programs HERE.
And want to know the best part? We're only just getting started...
Cheers, Matt`
________________


Subject: Be ready for tomorrow
Email Body:
`Hey Legend,
Tomorrow is going to be a big day. We have our biggest announcement ever coming. Stay tuned and have an epic evening.
Wanted to share before I eat some yoghurt and frozen blueberries. Tastes awesome, you should try it.
Peace, Matt`
________________


Subject: 179 meetings in 30 days
Email Body:
`Hey Creator,
I booked 179 meetings in 30 days in the LinkedIn DMs, and I wanted to share one of the dozens of tactics I used.
I've recently shared it with our clients in the Six Figure Creators program, and check this out.
Arthur booked his first ever meeting in the LinkedIn DMs. His post literally made my day!
So here's the tactic (That you should 100% steal):
I use the LVQ framework when DMing + following up.
DMs are like copywriting; every sentence should be a hook that convinces the prospect to keep reading and respond.
When someone answers me, this is the sequence I use:
L = Lube the chat "Hey! You made a good point about X. Are you open to exploring Y together?"
Chris Voss calls it mirroring, where you say what the other person just said back to them, so they feel understood. It makes the prospect feel heard.
V = Value "I recently worked on a project like this where we achieved ABC for a client. I think this could apply to you too. Would you like me to share how?"
By sharing a piece of value that's personalized and relevant to their situation, you trigger the rule of reciprocity, that makes the other person feel they owe you something.
To share the value, I have 2 docs I open at all times: Doc 1 - It has 96 screenshots of client wins. Doc 2 - It has my 51 lead magnets I built.
That way I can always share something they will relate to, which makes them trust me even more.
Q = Question "What do you think of X as a potential direction? Would that align with your goals?"
By asking the question, you are cashing in on the reciprocity credit that you built when you shared the value.
So what do you think? Pretty awesome, right?
To me, it doesn't sound salesy at all.
And if you found this valuable, check out this FREE 97-minute training where I share tons more DM tactics that you can steal and use.
Oh, and just so you know, this was the same presentation that I gave to a $30,000-a-year Mastermind a couple of weeks back, so you know it'll be valuable.
Have an epic weekend, legend!
Cheers, Matt
PS - I'm looking to work with a small group of LinkedIn creators in our private Seven Figure Creators Mastermind.
This is who it's for:
* You are driving at least $25k a month to your business from LinkedIn
* You spend at least 5 hours a week on LinkedIn and create consistent content
* You want to implement the systems to grow to $1M a year
* You are willing to put in the dirty work to get it done
* You want to be part of a private group working with you to get there
* You will be keen to come to our live in-person events next year
If that sounds like something you might be interested in, REPLY with "SEVENFIGURES" and also please share your LinkedIn URL, and I'll get back to you on Monday.`
________________


Subject: 2 weeks procrastinating
Email Body:
`I've spent 2 weeks procrastinating making the videos for our new website.
Like, I'm talking major procrastination. I used every excuse under the sun about why I couldn't record them: "I want to do it in the morning with caffeine." "I want to do it on the days I don't have meetings." "My face is puffy because I had a few drinks last night."
It feels like I'm back in high school, waking up at 4 a.m. to finish my Year 11 English assignment.
What's strange about it is that I make videos every day: I get on 4x live calls a week in our program. I record podcasts and YouTube videos daily. I create new content for our program nearly every week.
But I couldn't figure out why making these videos was so hard---until about 7 minutes ago while running home from CrossFit.
I was thinking about Derek Sivers' (one of my favorite authors) latest book, "Useful Not True." It's about the stories we tell ourselves that create our belief systems, which in reality are just beliefs---they aren't inherently true.
While thinking about it, I finally realized why these videos have been so difficult for me to make: It's simply because I believed they were.
It's all been in my mind. Because I've never made these types of videos before, I assumed they'd be hard without actually thinking it through. And it wasn't until around 12 minutes ago while running (I stopped to walk and type this, lol) that I finally realized all I needed was to reframe the videos from being "something hard" to something that I actually enjoy doing---something easy.
And that's exactly what the successful creators in our program who make $30k+ a month have done when it comes to generating leads.
Most creators see conversations and DMs as the "hard" thing they need to do. And when you believe something is hard, it becomes hard. It's all in our minds.
But the creators I work with who change this belief---who reframe lead generation to be easy---end up building the business and life they've only dreamed of.
If you're a creator who knows you need a reframe and is willing to put in the work to build a multi-six-figure business on LinkedIn---and live a life of freedom---reply back with "FREEDOM" and I'll share details about our Six Figure Creators Program kicking off on October 22nd.
Have an epic day, legends.
Cheers, Matt "Reframe" Lakajev`
________________


Subject: 2 deals in 40 mins getting on a plane
Email Body:
`I closed 3 deals in 40 minutes while getting on a plane to Fiji back in August.
I thought about it when I booked my trip to Los Angeles for this November, which is for the Mastermind Group I'm a part of that meets in person 4 times a year (Preview for what's to come in Seven Figure Creators).
Ok, back to the story haha.
One was while I awkwardly took a Zoom call from my phone, while drinking a 2/10 airport coffee. The other 2 using WhatsApp voice notes, while crossing the tarmac to get on the plane.
Here's how it went down... (Hang around for Act 3 - The Lesson, it's made me $36,000 this month)
Act 1 - The awkward Zoom call Long story short, one of my sales guys has been out of action this week, after a bouncer jumped on his back on Saturday night, where he proceeded to fall, hit his head getting a concussion, and snapping his wrist.
Yep... not a fun night for him. (Story for another day)
So we were down a rep, but there was a juicy call booked with a perfect prospect.
I checked my calendar: --- 8:30 am - Sales Meeting --- 9:25 am - Board Flight
I thought, "F*** it, I can do this."
So I got to the airport café 90 minutes early, ordered my coffee, and got a seat.
That's when it all fell to sh**... --- My laptop wouldn't connect to Wi-Fi --- Then it wouldn't tether to my iPhone --- Then one of my AirPods died And to top it all off, my coffee was a 2/10 at best.
"Well I've been in worse situations, let's see how it goes from the phone."
--- So I took the call --- Barely able to hear anything --- Somehow filled out the doc --- Made him an offer on the call And he enrolled then and there.
But I got it done, only to check the time... 9:18 am --- "My flight!" I grabbed my stuff and raced to the terminal.
Act 2 - The WhatsApp deals (My fave) While running to the plane, I checked my WhatsApp. I had 2 messages from prospects that were 95% of the way there to closed, but needed a helping hand to get them over.
For these ones, I honestly didn't even think, I just did what felt natural. I made them both an offer via voice note.
"Hey NAME, look based on our messages, I think you're a great fit. I'm actually about to get on a plane to Fiji, so I'll be out of action for 6 hours. You seem like you're keen to get started, so what I'll do is CC in Nate from my team who will be able to get you enrolled now, so you can get started + he will set up your game plan call."
I then started 2 group chats in WhatsApp, added Nate and the prospects in, told Nate the situation in the chat, then sent them both the Stripe link.
And when I landed --- 2 more deals closed...
Act 3 - The $36,000 Lesson I know, I know, you're thinking: "But Matt, what the hell was the point of all of this?"
The point is this... I've worked with 500+ creators and the biggest thing holding them back from making 6 figures a year on LinkedIn is they simply don't make enough offers...
They barely say the words --- "Would you like to work together?"
And because of it, they'll never hit 6 figures on LinkedIn.
That's why I'm launching our October Launch Group, to help you: --- Craft a $2-$5k offer so good it'll sell itself --- Build the offer doc + pitch deck using our templates --- Walk you through step by step how to close the deal.
We're getting started on October 22nd. If you'd like to join, reply back "FIJI" and I'll share the details.
Matt "tarmac closer" Lakajev`
________________


Subject: 3 clients in 2 weeks
Email Body:
`Just chatted to Vidhya, who closed her first-ever 3 deals on LinkedIn only 2 weeks after joining our program.
When we first started chatting, Vidhya had already spent hundreds of hours on LinkedIn: --- Growing over 2000% up to 7,000 followers --- She gets over 200 likes per post --- Spends hours every day on the platform
But there was one problem: She hadn't closed any clients...
Even though she was following all the free advice on the regular LinkedIn Newsfeed. And while it does have great advice on how to grow, it doesn't show you how to drive revenue to your business through the platform.
Fast forward 2 weeks into the program, and she's already closed 3 clients. One of them was the largest amount of income she has ever earned.
And want to know the best news of all? She showed her mum the invoice she sent out, and her mum smiled, showing how proud she was of her.
So if you're a business owner or creator that is spending time on LinkedIn trying to generate leads, and you are looking for a step-by-step process to implement to start closing more clients like Vidhya:
Reply back with "DEALS," and I'll send you the details of our program, which is kicking off again later this month. I'll be working with a small group of people to implement this same system.
Cheers, Matt`
________________


Subject: At 27, I was $25,000 in debt and depressed
Email Body:
`Hey Creator,
At 27, I was $25,000 in debt and depressed. Now, I make $150,000 every month and live my dream.
It all changed for me in 2018 when I made this one decision: I decided that everything was my fault and that from now on, I would own all my problems. I call it Extreme Ownership.
Here are the 3 changes I made that changed my life:
1. I quit everything I quit video games. I quit toxic relationships. I quit 2am Saturday nights. Most importantly, I quit blaming others for my problems.
2. I quit comfort I used to live in a constant state of fear: "What will they think of me?" "What if I embarrass myself?" "What happens if it goes wrong?" Fear is the mind killer, and your comfort zone will kill you. 5 years later, I've retrained my brain. Now, when I feel fear, I see it as a signal that I'm doing the right thing.
3. I built skills I believe in the S&ME500 > S&P500. This mindset has 41x'd my salary.
I learned DMing. I learned content. I learned funnel building.
These skills have helped me drive thousands of leads a month to my business on LinkedIn.
That's what I teach in my program. Not "6 LinkedIn hacks to grow" or "Use this AI prompt to go viral." This is for those ready to build real skills to generate leads forever.
Like: Jose, who quit his corporate job to build the life of his dreams for his family. Albano, who closed $8,700 in one week while being a stay-at-home dad. Pranjal, who went from $0 to $20k/month in just five months as a 24-year-old.
This is what freedom looks like.
If you're a business owner who wants to build the skills to generate leads on LinkedIn forever, reply with "FOREVER," and I'll share the details of my program.
Happy Friday, Matt`
________________


Extract Key Patterns & Observations:
1. Identify the most common subject line structures.
2. Identify the most common storytelling techniques.
3. Identify how calls-to-action (CTAs) are framed.
4. Identify the pacing, length, and formatting patterns.
</templates>
