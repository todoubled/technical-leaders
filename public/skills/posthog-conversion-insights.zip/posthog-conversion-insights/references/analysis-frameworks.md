# Strategic Analysis Frameworks

Frameworks for translating PostHog data into actionable strategic and tactical recommendations.

## The Conversion Diagnosis Matrix

Map observations to root causes:

| Symptom | Traffic Problem | Positioning Problem | UX Problem |
|---------|----------------|--------------------:|------------|
| High bounce, low pages/session | Wrong traffic source | Messaging mismatch | Slow load, broken UI |
| Deep engagement, no conversion | Traffic is curious, not buyers | Value prop unclear | CTA invisible, form friction |
| Conversion starts, abandons | - | Price/offer objection | Technical friction |
| Conversions but wrong segment | Wrong targeting | Broad positioning | - |

## Traffic Quality Analysis

### Source Quality Scoring
For each traffic source, calculate:

```
Quality Score = (Conversion Rate × Avg Pages) / Bounce Rate
```

Interpret:
- Score > 1.0: High quality source, invest more
- Score 0.5-1.0: Medium quality, optimize landing pages
- Score < 0.5: Low quality, reconsider spend

### Source Segmentation
| Segment | Characteristics | Strategy |
|---------|----------------|----------|
| High volume, high conversion | Best performers | Double down, find similar |
| High volume, low conversion | Leaky bucket | Fix landing pages or cut |
| Low volume, high conversion | Hidden gems | Scale cautiously |
| Low volume, low conversion | Noise | Ignore or eliminate |

## Funnel Leak Diagnosis

### Where People Drop
| Drop Point | Likely Cause | Fix Category |
|------------|--------------|--------------|
| Landing → Next page | Irrelevant traffic or poor hook | Strategic: positioning |
| Content → CTA | Value not communicated | Tactical: copy/design |
| CTA → Form start | Friction or fear | Tactical: reduce fields |
| Form start → Complete | Form UX issues | Tactical: form optimization |
| Complete → Payment | Price objection | Strategic: offer structure |

### Drop-Off Benchmarks
| Funnel Stage | Acceptable Drop | Concerning Drop |
|--------------|-----------------|-----------------|
| Page → Next page | 40-60% | >70% |
| Page → CTA click | 80-90% | >95% |
| CTA → Form complete | 30-50% | >70% |
| Form → Payment | 20-40% | >60% |

## Strategic Recommendation Categories

### 1. Traffic Optimization
**Signal:** Low conversion across all sources OR one dominant low-quality source

**Questions to answer:**
- Which sources have >1% conversion?
- What % of traffic converts at <0.5%?
- What's the cost per visitor by source?

**Recommendation patterns:**
- "Shift budget from [low performer] to [high performer]"
- "Add [similar channel] based on [high performer] success"
- "Kill [source] - costing [X] with [0%] conversion"

### 2. Positioning Refinement
**Signal:** High engagement (pages, time) but low conversion

**Questions to answer:**
- What content do non-converters consume?
- What's the first page viewed by converters vs non-converters?
- Are people leaving after specific pages?

**Recommendation patterns:**
- "Visitors expecting [X] but finding [Y] - realign messaging"
- "Add qualification earlier in funnel"
- "Test headline variations on [page]"

### 3. Offer Restructuring
**Signal:** High intent signals (CTA clicks, checkout starts) but abandonment

**Questions to answer:**
- Where exactly in checkout do people leave?
- What's conversion by price point (if tracked)?
- Do people who book calls convert at higher rates?

**Recommendation patterns:**
- "Introduce lower-commitment first step"
- "Add social proof at [abandonment point]"
- "Test [alternative offer structure]"

### 4. UX/Friction Removal
**Signal:** Device-specific issues, form abandonment, rage clicks

**Questions to answer:**
- Mobile vs desktop conversion difference?
- Which form fields correlate with abandonment?
- What pages have rage clicks?

**Recommendation patterns:**
- "Simplify form: remove [fields], keep [essentials]"
- "Fix mobile experience on [page]"
- "Address [UI element] causing rage clicks"

## Tactical Priority Scoring

Score each tactical recommendation:

| Factor | Weight | Score (1-5) |
|--------|--------|-------------|
| Impact (potential lift) | 40% | Based on funnel volume at that point |
| Confidence (data support) | 30% | How clear is the evidence? |
| Effort (implementation) | 30% | Inverse: 5=easy, 1=hard |

**Priority = (Impact × 0.4) + (Confidence × 0.3) + (Effort × 0.3)**

- Score ≥4: Immediate action
- Score 3-4: This week
- Score 2-3: Backlog
- Score <2: Reconsider

## Time-Based Analysis Patterns

### Trend Interpretation
| Trend | Duration | Interpretation |
|-------|----------|----------------|
| Declining | 2+ weeks | Real problem, investigate |
| Declining | <1 week | Normal variance, monitor |
| Flat | 4+ weeks | Stagnation, need intervention |
| Improving | 2+ weeks | Something working, identify what |

### Seasonality Considerations
- Compare same period YoY if available
- Account for holidays, industry events
- Note campaign timing vs organic trends

## Output Quality Checklist

Before delivering recommendations:

- [ ] Each strategic recommendation has data evidence
- [ ] Tactical fixes are specific and actionable
- [ ] Priorities are explicitly ranked
- [ ] Expected impact is quantified (even if estimated)
- [ ] Caveats on data quality are noted
- [ ] Next measurement milestone is defined
