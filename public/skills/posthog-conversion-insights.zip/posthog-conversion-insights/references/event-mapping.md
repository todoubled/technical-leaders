# Event Mapping Reference

Common event patterns for identifying conversion types across different PostHog implementations.

## Signup Events

### Direct Indicators
| Event Pattern | Interpretation |
|--------------|----------------|
| `form_submit`, `form_completed` | Generic form completion |
| `signup`, `sign_up`, `registered` | Account creation |
| `lead_captured`, `lead_created` | Lead gen form |
| `Assessment Completed` | Quiz/assessment finish |
| `Workshop Registration Completed` | Event registration |
| `download_*`, `*_downloaded` | Lead magnet download |

### Funnel Precursors
| Event | Funnel Position |
|-------|----------------|
| `$pageview` on form page | Top of funnel |
| `form_started`, `form_focus` | Engagement signal |
| `field_completed` | Progress indicator |
| `validation_error` | Friction signal |

## Call Booking Events

### Calendly Integration
| Event | Meaning |
|-------|---------|
| `Calendly Widget Initialized` | Widget loaded on page |
| `Calendly Widget Loaded` | User can see booking UI |
| `Calendly Viewed` | Calendar visible |
| `Calendly Date Selected` | User picked a date |
| `Calendly Scheduled` | **CONVERSION** - Booking confirmed |

### Page-Based Tracking
| Pattern | Notes |
|---------|-------|
| `$pageview` where `$pathname = '/call'` | Booking page view |
| `$pageview` where `$pathname = '/call-confirmed'` | Post-booking confirmation |
| `$pageview` where `$pathname = '/thank-you'` | Generic thank you |

### CTA Clicks
| Event Pattern | Intent Signal |
|--------------|---------------|
| `Book Strategy Session*` | High intent |
| `Book an Intro Call*` | High intent |
| `Get Started*CTA` | Medium intent |
| `See How It Works*` | Low intent |

## Purchase Events

### Stripe-Related
| Event Pattern | Meaning |
|--------------|---------|
| `Conversion: *Purchase Clicked` | Checkout initiated |
| `checkout_started` | Payment flow began |
| `payment_completed` | **CONVERSION** |
| `purchase`, `purchased` | Generic purchase |

### Product-Specific (Tech Leaders)
| Event | Product |
|-------|---------|
| `Conversion: Ship AI Purchase Clicked` | Ship AI program |
| `Conversion: Launch Kit Purchase Clicked` | Launch Kit |
| `Conversion: AI Program Purchase Clicked` | AI program |

## Engagement Events (Non-Conversion)

### Content Engagement
| Event | What It Measures |
|-------|-----------------|
| `article_scroll_depth` | Content consumption |
| `Scroll Depth Reached` | Page engagement |
| `Page Scroll Summary` | Session engagement |
| `$rageclick` | Frustration signal |

### Page Views by Type
| Pattern | Page Type |
|---------|----------|
| `*Landing Page View` | Entry pages |
| `*Page View` (generic) | Content pages |
| `$pageview` + `$pathname` | All pages |

## Query Patterns

### Find All Conversion Events
```sql
SELECT event, count(*) as occurrences
FROM events
WHERE event LIKE '%Conversion%' 
   OR event LIKE '%Completed%'
   OR event LIKE '%Scheduled%'
   OR event LIKE '%Purchase%'
GROUP BY event
ORDER BY occurrences DESC
```

### Map Traffic to Conversions
```sql
SELECT 
    properties.$referring_domain as source,
    count(DISTINCT CASE WHEN event = '$pageview' THEN distinct_id END) as visitors,
    count(DISTINCT CASE WHEN event = 'YOUR_CONVERSION' THEN distinct_id END) as converters
FROM events
WHERE timestamp >= now() - INTERVAL 30 DAY
GROUP BY source
ORDER BY converters DESC
```
