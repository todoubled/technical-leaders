---
name: posthog-conversion-insights
description: Analyze PostHog data to generate strategic and tactical insights for improving conversion rates. Use when user asks for conversion analysis, funnel optimization, signup improvements, call booking analysis, purchase conversion, growth diagnostics, or any request involving "analyze my PostHog", "conversion insights", "funnel analysis", "what's hurting conversion", "growth opportunities", or strategic recommendations from product analytics data. Covers three conversion types - signups, call bookings, and Stripe purchases.
---

# PostHog Conversion Insights

Generate strategic and tactical recommendations from PostHog analytics data to improve conversion of signups, call bookings, and purchases.

## Quick Reference: PostHog MCP Tools

| Analysis Type | Primary Tool | Purpose |
|--------------|--------------|---------|
| Event inventory | `event-definitions-list` | Discover available conversion events |
| Trend analysis | `query-run` (TrendsQuery) | Volume and rate over time |
| Funnel analysis | `query-run` (FunnelsQuery) | Step-by-step conversion rates |
| Deep queries | `query-run` (HogQLQuery) | Complex multi-table analysis |
| Existing insights | `insights-get-all` + `insight-query` | Review saved analyses |
| Properties | `properties-list` | Available breakdown dimensions |

## Conversion Event Taxonomy

Before analysis, identify which events map to the three conversion types. See [references/event-mapping.md](references/event-mapping.md) for common patterns.

**Signups:**
- Form submissions, assessment completions, lead magnet downloads
- Look for: `*form*`, `*signup*`, `*registration*`, `*assessment*`, `*download*`

**Call Bookings:**
- Calendar scheduling, booking confirmations
- Look for: `Calendly*`, `*call*`, `*booking*`, `*schedule*`, `*confirmed*`

**Purchases:**
- Stripe checkout, purchase clicks, payment confirmations
- Look for: `Conversion*Purchase*`, `*checkout*`, `*payment*`, `*buy*`

## Analysis Workflow

### Phase 1: Discovery (Run First)

```
1. event-definitions-list → inventory all events
2. Categorize into: signups | calls | purchases | engagement | other
3. properties-list (type: "event") → identify breakdown dimensions
4. insights-get-all → review existing conversion insights
```

**Output from Phase 1:** Event map categorized by conversion type + available dimensions

### Phase 2: Funnel Diagnostics

Build funnels for each conversion path:

```
query-run (FunnelsQuery):
  - Signup funnel: pageview → landing → form_start → form_complete
  - Call funnel: pageview → /call page → calendly_load → calendly_scheduled
  - Purchase funnel: pageview → product_page → checkout_click → purchase
```

**Key metrics to extract:**
- Conversion rate per step
- Drop-off points (biggest leaks)
- Time to convert
- Breakdown by: source, device, page

### Phase 3: Trend Analysis

```
query-run (TrendsQuery):
  - Conversion events over time (interval: day/week)
  - Compare periods (compareFilter)
  - Breakdown by traffic source, device, entry page
```

**Questions to answer:**
- Is conversion improving or declining?
- What day/time performs best?
- Which sources convert best?

### Phase 4: Behavioral Patterns

Use HogQL for complex queries:

```sql
-- Conversion path analysis
SELECT 
    properties.$pathname as entry_page,
    count(distinct distinct_id) as visitors,
    count(distinct CASE WHEN event = 'YOUR_CONVERSION' THEN distinct_id END) as converters,
    round(converters * 100.0 / nullif(visitors, 0), 2) as conversion_rate
FROM events
WHERE timestamp >= now() - INTERVAL 30 DAY
GROUP BY entry_page
ORDER BY conversion_rate DESC
```

```sql
-- Time-to-convert analysis
WITH conversions AS (
    SELECT distinct_id, min(timestamp) as convert_time
    FROM events WHERE event = 'YOUR_CONVERSION'
    GROUP BY distinct_id
),
first_touch AS (
    SELECT distinct_id, min(timestamp) as first_seen
    FROM events GROUP BY distinct_id
)
SELECT 
    round(avg(dateDiff('hour', first_seen, convert_time)), 1) as avg_hours_to_convert
FROM conversions c JOIN first_touch f ON c.distinct_id = f.distinct_id
```

## Output: Strategic & Tactical Recommendations

### Strategic Shifts (Big Picture)

Structure recommendations as:

```markdown
## Strategic Recommendation: [Title]

**Observation:** What the data shows
**Implication:** Why this matters for the business  
**Recommendation:** What to change strategically
**Expected Impact:** Projected improvement (with reasoning)
```

Strategic categories:
- Traffic quality issues (high volume, low conversion)
- Positioning problems (wrong visitors attracted)
- Value prop mismatch (interest but no action)
- Friction points (intent but abandonment)

### Tactical Changes (Quick Wins)

Structure as:

```markdown
## Tactical Fix: [Title]

**Problem:** Specific issue identified
**Evidence:** Data supporting this
**Action:** Concrete implementation step
**Priority:** High/Medium/Low (based on impact × effort)
```

Tactical categories:
- Page optimization (specific page underperforming)
- CTA improvements (click-through issues)
- Form friction (drop-off during input)
- Mobile experience (device-specific problems)
- Load time (correlation with bounce)

## Analysis Output Template

```markdown
# Conversion Insights Report

## Executive Summary
- [1-sentence state of conversions]
- [Biggest opportunity identified]
- [Most urgent problem to fix]

## Current Performance

### Signup Conversion
- Rate: X% | Trend: ↑/↓ X% vs prior period
- Primary funnel: [stages with rates]
- Biggest leak: [stage] (X% drop-off)

### Call Booking Conversion  
- Rate: X% | Trend: ↑/↓ X% vs prior period
- Primary funnel: [stages with rates]
- Biggest leak: [stage] (X% drop-off)

### Purchase Conversion
- Rate: X% | Trend: ↑/↓ X% vs prior period
- Primary funnel: [stages with rates]
- Biggest leak: [stage] (X% drop-off)

## Strategic Recommendations
[2-3 strategic shifts with full structure above]

## Tactical Quick Wins
[3-5 tactical changes prioritized by impact]

## Data Appendix
[Key queries used, notable caveats]
```

## Tool Limitations & Workarounds

**No direct revenue data:** PostHog doesn't have Stripe integration. Workaround: Use `Conversion*Purchase*` events or custom properties.

**Session vs user confusion:** Clarify whether analyzing unique users (distinct_id) or sessions.

**Sampling on large datasets:** HogQL may sample. Check `_sample_rate` in results.

## Reference Files

- [references/event-mapping.md](references/event-mapping.md) - Common event patterns for conversion types
- [references/analysis-frameworks.md](references/analysis-frameworks.md) - Strategic analysis frameworks
