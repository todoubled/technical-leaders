---
name: update-positioning
description: Interpret recent marketing data for positioning insights and optimize LinkedIn profile based on findings. Use when user asks to "update positioning", "analyze marketing data for profile optimization", "adjust LinkedIn based on what's working", "optimize profile from analytics", "data-driven positioning", or wants to connect marketing performance insights to profile improvements. Combines analytics interpretation from PostHog, Kit, LinkedIn ads, or other marketing sources with LinkedIn profile optimization to create a data-informed positioning strategy.
---

# Update Positioning

Transform marketing data insights into LinkedIn profile optimizations. This skill bridges analytics interpretation with profile positioning—turning what's actually working in your marketing into how you present yourself.

## Philosophy

Most positioning exercises are theoretical. This approach is empirical:
1. **What's converting?** → What language/offers resonate with real buyers
2. **Who's engaging?** → What profile characteristics match your actual ICP
3. **What's falling flat?** → What positioning isn't landing

The goal: Continuously refine positioning based on market feedback, not assumptions.

## Workflow

### Phase 1: Data Collection

Gather recent marketing performance data from available sources:

**PostHog (if available):**
```
1. event-definitions-list → identify conversion events
2. query-run (TrendsQuery) → conversion trends by source, page, campaign
3. query-run (FunnelsQuery) → where people drop off
4. properties-list → breakdown dimensions
```

**Kit (if available):**
```
1. kit_list_broadcasts → email engagement (opens, clicks)
2. kit_list_tags + kit_list_tag_subscribers → segment engagement
3. kit_list_sequences → nurture performance
```

**LinkedIn (via browser or uploaded reports):**
- Ad campaign performance (CTR, conversions by creative/copy)
- Post engagement (impressions, reactions, comments by topic)
- Profile views and connection requests (by title/industry)
- DM response rates

**Other sources (uploaded or in Drive):**
- Sales call recordings/transcripts → language that resonates
- Won deal summaries → why clients chose you
- Lost deal feedback → positioning gaps
- Client testimonials → words they use

### Phase 2: Extract Positioning Signals

Map data to positioning insights using this framework:

| Data Signal | Positioning Insight | Profile Section Impact |
|-------------|---------------------|------------------------|
| High CTR on specific ad copy | Language that resonates with ICP | Headline, About hook |
| Top converting landing page | Value prop that converts | About problem/solution |
| Email subjects with high opens | Phrases that grab attention | Headline, post hooks |
| High engagement posts by topic | Areas of perceived expertise | Featured section, About |
| Profile views by viewer title | Who your profile attracts | Experience positioning |
| DM topics that start conversations | Personal brand conversation starters | Personal traits in headline |
| Client win language | Outcome language they understand | About track record |
| Drop-off points in funnel | Positioning gaps to address | About objection handling |

**Key questions to answer:**

1. **What language converts?**
   - Which ad headlines get clicks?
   - Which email subjects get opens?
   - Which post hooks get engagement?
   - What words do clients use to describe your value?

2. **What value props resonate?**
   - Which landing pages convert best?
   - Which offers get calendar bookings?
   - What problems do clients say you solved?

3. **Who is actually buying?**
   - What titles/industries convert?
   - What's the profile of your best clients?
   - Does this match your stated ICP?

4. **What's not working?**
   - Where are the funnel leaks?
   - What content falls flat?
   - What positioning creates objections?

### Phase 3: Generate Positioning Recommendations

Output structured recommendations:

```markdown
## Positioning Insight Report

### Data Summary
- Period analyzed: [date range]
- Sources: [PostHog, Kit, LinkedIn, etc.]
- Key metrics: [conversions, engagement rates, etc.]

### What's Working (Double Down)

**Language/Copy:**
- [Specific phrase or framing that converts]
- Evidence: [data supporting this]
- Profile application: [where to use it]

**Value Props:**
- [Offer/positioning that resonates]
- Evidence: [conversion data]
- Profile application: [how to incorporate]

### What's Not Landing (Adjust)

**Positioning Gaps:**
- [Current positioning issue]
- Evidence: [drop-off data, low engagement]
- Recommendation: [what to change]

### ICP Refinement

**Actual buyers vs. stated ICP:**
- [Characteristics of who's actually converting]
- Profile adjustment: [how to better speak to actual buyers]
```

### Phase 4: Update LinkedIn Profile

Apply insights using linkedin-profile-optimizer framework:

**Headline updates:**
- Incorporate high-converting language
- Match identity to what ICP calls you
- Update outcome to proven results

**About section updates:**
- Hook: Use email subject/ad headline language that works
- Problem/Agitation: Mirror language from client conversations
- Solution: Frame as proven through data
- Track Record: Update with recent wins
- CTA: Align with highest-converting offer

**Featured section updates:**
- Pin content that performs
- Feature offers that convert
- Showcase recent credibility markers

**Experience updates:**
- Reframe roles using client-validated language
- Emphasize outcomes that resonate

### Phase 5: Create Update Plan

Prioritize changes by impact:

```markdown
## LinkedIn Profile Update Plan

### Immediate Changes (This Week)
1. [Highest impact change with data backing]
2. [Second priority]

### Test & Iterate (Next 2-4 Weeks)
- [Changes to A/B test through content]
- [Positioning hypotheses to validate]

### Quarterly Review
- [Metrics to track for positioning effectiveness]
- [Data to collect for next positioning update]
```

## Output Format

When running update-positioning, deliver:

1. **Data Summary** - What data was analyzed and key metrics
2. **Insight Report** - What's working, what's not, ICP refinement
3. **Profile Recommendations** - Specific changes to each profile section
4. **Update Plan** - Prioritized action items with timeline

## Integration with Existing Skills

This skill orchestrates:
- **posthog-conversion-insights** → Funnel and conversion analysis
- **kit-funnel-analytics** → Email engagement signals
- **linkedin-profile-optimizer** → Profile optimization framework

## Reference Files

- [references/data-positioning-map.md](references/data-positioning-map.md) - Detailed mappings from data signals to positioning changes
