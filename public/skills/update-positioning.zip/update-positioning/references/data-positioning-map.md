# Data to Positioning Mappings

Detailed guide for translating marketing data signals into LinkedIn profile positioning changes.

## PostHog Data → Positioning

### Conversion Events

| Event Pattern | What It Tells You | Profile Update |
|--------------|-------------------|----------------|
| High conversion on specific landing page | Value prop/offer that resonates | Mirror this framing in About solution section |
| Conversion from specific UTM source | Channel where your positioning lands | Tailor profile to that audience's language |
| High conversion from specific entry page | Content topic that attracts buyers | Feature this expertise in About |
| Time-to-convert patterns | Speed of trust-building | Address objections earlier in About |

### Funnel Drop-offs

| Drop-off Point | What It Signals | Profile Update |
|----------------|-----------------|----------------|
| Landing → Form start | Value prop not compelling | Strengthen About hook and problem statement |
| Form start → Complete | Too much commitment too soon | Soften CTA, add trust elements to Featured |
| Page view → CTA click | Weak call-to-action | Revise About CTA, Featured section links |
| Call page → Booking | Hesitation about committing | Add social proof, reduce perceived risk in About |

### Breakdown Dimensions

| Breakdown | High Performers | Profile Update |
|-----------|-----------------|----------------|
| By device (mobile converts) | Mobile audience | Ensure headline/hook visible in preview |
| By geography | Regional strength | Mention specific markets in experience |
| By referrer | Source alignment | Optimize for that platform's audience |

## Kit Data → Positioning

### Email Performance

| Metric | What It Tells You | Profile Update |
|--------|-------------------|----------------|
| Subject lines with 40%+ opens | Phrases that grab attention | Use similar hooks in headline/About |
| Click-through topics | Content that drives action | Feature this topic area |
| Unsubscribes after specific emails | Positioning misalignment | Adjust language that turned people off |

### High-Performing Subject Patterns

| Pattern | Profile Application |
|---------|---------------------|
| Question format | Use questions in About hook |
| Number/list format | Quantify outcomes in headline |
| Contrarian take | Lead with contrarian positioning |
| Personal story | Add personal element to About |
| Urgency/scarcity | Create clear CTA urgency |

### Tag Engagement

| Tag Pattern | What It Tells You | Profile Update |
|-------------|-------------------|----------------|
| High engagement tags | Interest areas of buyers | Feature these topics prominently |
| Buyer/customer tags | What actual buyers look like | Refine ICP language to match |
| Disengaged segment tags | What's not working | Remove or reposition these topics |

## LinkedIn Data → Positioning

### Ad Performance

| Metric | What It Tells You | Profile Update |
|--------|-------------------|----------------|
| High CTR headlines | Language that stops the scroll | Test in profile headline |
| High conversion creative | Visual/message combo that works | Apply to banner + headline |
| Audience segments that convert | Who resonates with positioning | Adjust experience language for them |

### Post Engagement

| Pattern | What It Tells You | Profile Update |
|---------|-------------------|----------------|
| Topics with high engagement | Perceived expertise areas | Feature in About, pin in Featured |
| Post formats that work | Communication style preference | Match tone in profile |
| Posts that drive DMs | Conversation starters | Add personal traits related to these |
| Posts that get saves | Reference-worthy content | Pin to Featured |

### Profile Analytics

| Metric | What It Tells You | Profile Update |
|--------|-------------------|----------------|
| Viewer job titles | Who your profile attracts | Verify ICP alignment, adjust if needed |
| Viewer industries | Sector resonance | Emphasize relevant experience |
| Search appearances by keyword | What you're known for | Optimize for desired keywords |
| Connection request patterns | Personal brand appeal | Lean into what's attracting connections |

## Sales/Client Data → Positioning

### Won Deals

| Data Point | What It Tells You | Profile Update |
|------------|-------------------|----------------|
| Why they chose you | Differentiating value | Lead with this in headline/About |
| Words they use | Client-validated language | Replace jargon with their words |
| Outcomes they mention | Results that matter to them | Quantify these in track record |
| Objections they overcame | Trust-building factors | Address proactively in About |

### Lost Deals

| Data Point | What It Tells You | Profile Update |
|------------|-------------------|----------------|
| Common objections | Positioning gaps | Add objection-handling to About/Featured |
| "Not a fit" reasons | ICP mismatch | Clarify who you serve |
| Competitor comparison | Differentiation needed | Strengthen unique positioning |

### Client Conversations

| Pattern | Profile Application |
|---------|---------------------|
| Questions they ask repeatedly | FAQ content for Featured |
| Aha moments in calls | Hook/problem framing |
| Metaphors they respond to | Analogies in About |
| Concerns before buying | Trust elements to add |

## Synthesis Framework

When multiple data sources align, prioritize:

1. **Triangulated signals** (same insight from 3+ sources) → Immediate profile update
2. **Strong single signal** (one source, clear pattern) → Test via content first
3. **Weak signals** (inconsistent or low volume) → Note for future validation

### Priority Matrix

| Signal Strength | Data Volume | Action |
|-----------------|-------------|--------|
| Strong (clear pattern) | High (100+ data points) | Update profile immediately |
| Strong | Low | Test via content, then update |
| Weak (inconsistent) | High | Investigate further |
| Weak | Low | Note for quarterly review |

## Common Positioning Pivots

Based on data patterns:

| Data Pattern | Typical Pivot |
|--------------|---------------|
| Wrong titles viewing profile | Headline identity mismatch |
| High awareness, low conversion | Value prop unclear |
| Engagement but no action | CTA/offer problem |
| Technical audience converting | Simplify or lean into expertise |
| Executive audience converting | Elevate strategic positioning |
| Specific industry over-indexing | Niche down or feature |
