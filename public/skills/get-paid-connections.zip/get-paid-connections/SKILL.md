---
name: get-paid-connections
description: Process LinkedIn connection requests from Slack notifications about the 2026 Fortune 100 Prompt Library. Use when user says "get paid connections", "process prompt library leads", "check slack for new leads", or wants to send LinkedIn connections to Fortune 100 leads. Monitors a specific Slack channel for notifications mentioning "New Lead from 2026 Fortune 100 Prompt Library", processes unhandled ones (those without a checkmark reaction), sends LinkedIn connection requests, and marks them complete.
---

# Get Paid Connections

Process new leads from the 2026 Fortune 100 Prompt Library by monitoring Slack notifications and sending LinkedIn connection requests.

## Workflow

### Step 1: Open Slack Channel

1. Navigate to the Slack channel: `https://app.slack.com/client/T01HJRDHLMD/C0516BAL3NH`
2. Wait for the channel to fully load

### Step 2: Find Unprocessed Notifications

1. Look for messages containing "New Lead from 2026 Fortune 100 Prompt Library"
2. For each matching message, check if it has a ✅ (white_check_mark) reaction emoji
3. Messages WITHOUT the ✅ reaction are unprocessed and need attention
4. Extract the LinkedIn profile URL from each unprocessed message

### Step 3: Process Each Lead

For each unprocessed notification:

1. Open the LinkedIn profile URL in a new tab
2. Check connection status:
   - If already connected: skip sending request
   - If "Pending" invitation: skip sending request
   - If "Connect" button available: click it
3. When the connection modal appears:
   - Look for "Send without a note" option and click it
   - OR if only "Send" button with note field, leave note empty and click Send
4. Return to Slack channel

### Step 4: Mark as Processed

After successfully processing a lead (connection sent or already connected):

1. Hover over the notification message in Slack
2. Click the emoji reaction button (smiley face icon)
3. Search for and select the ✅ checkmark emoji
4. Verify the reaction appears on the message

### Step 5: Repeat

Continue processing all unprocessed notifications until none remain without the ✅ reaction.

## Important Notes

- Only send connection requests WITHOUT a note (no personalized message)
- Skip any profiles where we're already connected or have a pending invitation
- Always add the ✅ reaction after processing, even if already connected
- If LinkedIn rate-limits connection requests, pause and inform the user
